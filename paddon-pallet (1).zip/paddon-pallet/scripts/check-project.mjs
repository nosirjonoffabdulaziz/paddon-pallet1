// npm install / build oldidan loyiha tuzilishini tekshiradi.
// Muhim fayl yo‘q bo‘lsa, "Could not find Prisma Schema" o‘rniga aniq sabab va yechimni ko‘rsatadi.
import { existsSync } from "node:fs";
import path from "node:path";

const root = process.cwd();
const required = [
  "prisma/schema.prisma",
  "src/app/layout.tsx",
  "src/app/[locale]/page.tsx",
  "src/lib/db.ts",
  "next.config.ts",
  "tsconfig.json",
];
const missing = required.filter((file) => !existsSync(path.join(root, file)));

if (missing.length) {
  console.error("\n❌ Loyiha fayllari to‘liq emas. Topilmadi:");
  for (const file of missing) console.error("   - " + file);
  console.error(`
Joriy papka: ${root}

Ehtimoliy sabablar:
 1) GitHub'ga brauzer orqali yuklanganda ba’zi papkalar tushib qolgan
    (GitHub web-yuklash bir martada 100 tadan ortiq faylni qabul qilmaydi).
    → Loyihani "git push" orqali yuklang (README, 4-bo‘lim).
 2) Vercel'da "Root Directory" noto‘g‘ri. package.json va prisma/ papkasi
    turgan papkani tanlang (masalan: paddon-pallet).
`);
  process.exit(1);
}
