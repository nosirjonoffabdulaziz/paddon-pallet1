import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium leading-none",
  {
    variants: {
      variant: {
        default: "bg-sand text-ink",
        wood: "bg-wood/12 text-wood-dark",
        outline: "border border-line bg-card text-muted",
        success: "bg-success/10 text-success",
        warning: "bg-warning/12 text-[#8a6120]",
        danger: "bg-danger/10 text-danger",
        dark: "bg-ink text-white",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

export function Badge({
  className,
  variant,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
