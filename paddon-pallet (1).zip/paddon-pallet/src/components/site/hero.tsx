"use client";

import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Check } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import { Button } from "@/components/ui/button";

type Props = {
  locale: string;
  dict: Pick<Dictionary, "hero" | "meta">;
  image: string;
  /** Standart rasm ishlatilsa, o‘lcham chiziqlari rasm geometriyasiga moslab chiziladi. */
  isDefaultImage: boolean;
};

const ease = [0.22, 1, 0.36, 1] as const;

export function Hero({ locale, dict, image, isDefaultImage }: Props) {
  const reduce = useReducedMotion();
  const fade = (delay: number) => ({
    initial: reduce ? false : { opacity: 0, y: 18 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, delay, ease },
  });

  return (
    <section className="relative overflow-hidden">
      {/* Fondagi xira "PALLET" yozuvi */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-[8%] select-none text-center font-display text-[26vw] font-extrabold leading-none tracking-tighter text-ink/[0.035] lg:top-[4%] lg:text-[21vw]"
      >
        {dict.meta.brand}
      </div>
      <div className="bg-blueprint absolute inset-0 [mask-image:radial-gradient(ellipse_at_70%_45%,black_20%,transparent_70%)]" aria-hidden />

      <div className="container-page relative grid min-h-[calc(100svh-72px)] items-center gap-10 py-12 lg:grid-cols-[1.05fr_1fr] lg:gap-6 lg:py-16">
        <div className="relative z-10 max-w-2xl">
          <motion.span {...fade(0)} className="eyebrow">
            {dict.hero.eyebrow}
          </motion.span>
          <motion.h1
            {...fade(0.08)}
            className="mt-6 font-display text-[40px] font-extrabold leading-[1.02] tracking-tight text-ink sm:text-6xl lg:text-[68px] xl:text-[76px]"
          >
            <span className="block">{dict.hero.titleLine1}</span>
            <span className="block text-wood">{dict.hero.titleLine2}</span>
          </motion.h1>
          <motion.p {...fade(0.16)} className="mt-6 max-w-xl text-lg leading-relaxed text-muted">
            {dict.hero.subtitle}
          </motion.p>
          <motion.div {...fade(0.24)} className="mt-9 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link href={`/${locale}/products`}>
                {dict.hero.ctaProducts} <ArrowRight />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href={`/${locale}/order`}>{dict.hero.ctaOrder}</Link>
            </Button>
          </motion.div>
          <motion.ul {...fade(0.32)} className="mt-10 flex flex-wrap gap-x-6 gap-y-3 text-sm text-ink/80">
            {[dict.hero.point1, dict.hero.point2, dict.hero.point3].map((p) => (
              <li key={p} className="inline-flex items-center gap-2">
                <span className="grid size-5 place-items-center rounded-full bg-wood/15 text-wood-dark">
                  <Check className="size-3" strokeWidth={3} />
                </span>
                {p}
              </li>
            ))}
          </motion.ul>
        </div>

        <motion.div
          initial={reduce ? false : { opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.1, ease }}
          className="relative mx-auto w-full max-w-[640px]"
        >
          {/* Studiya foni */}
          <div className="absolute inset-[6%] rounded-full bg-[radial-gradient(circle_at_50%_45%,#ffffff_0%,#fbfaf6_45%,transparent_72%)]" />
          <div className="relative aspect-square">
            <Image
              src={image}
              alt={dict.hero.dimensionCaption}
              fill
              priority
              sizes="(min-width: 1024px) 640px, 92vw"
              className="object-contain mix-blend-multiply"
            />
            {isDefaultImage && <DimensionOverlay animate={!reduce} />}
          </div>
          <motion.div
            initial={reduce ? false : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5, duration: 0.6 }}
            className="absolute bottom-[8%] left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full border border-line bg-white/80 px-4 py-2 text-xs font-semibold tracking-wide text-ink shadow-soft backdrop-blur-md"
          >
            <span className="mr-2 inline-block size-1.5 -translate-y-px rounded-full bg-wood align-middle" />
            {dict.hero.dimensionCaption}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

/** Standart hero rasmidagi yevropallet qirralari bo‘ylab o‘lcham chiziqlari (800×800 koordinatalar). */
function DimensionOverlay({ animate }: { animate: boolean }) {
  const line = (x1: number, y1: number, x2: number, y2: number, delay: number) => (
    <motion.line
      x1={x1}
      y1={y1}
      x2={x2}
      y2={y2}
      initial={animate ? { pathLength: 0 } : false}
      animate={{ pathLength: 1 }}
      transition={{ duration: 1.2, delay, ease: [0.65, 0, 0.35, 1] }}
    />
  );
  return (
    <svg viewBox="0 0 800 800" className="pointer-events-none absolute inset-0 size-full" aria-hidden>
      <g stroke="#a77948" strokeWidth="1.6" fill="none" strokeLinecap="round">
        {/* 1200 mm — old uzun tomon */}
        {line(226, 582, 760, 410, 0.6)}
        {line(218, 560, 234, 604, 0.6)}
        {line(752, 388, 768, 432, 0.6)}
        {/* 800 mm — chap qisqa tomon */}
        {line(196, 566, 40, 432, 0.9)}
        {line(183, 581, 209, 551, 0.9)}
        {line(27, 447, 53, 417, 0.9)}
        {/* Yordamchi uzilgan chiziqlar */}
        <g strokeDasharray="3 5" strokeOpacity="0.55" strokeWidth="1">
          {line(218, 540, 226, 582, 0.4)}
          {line(742, 372, 760, 410, 0.4)}
          {line(56, 404, 40, 432, 0.4)}
        </g>
      </g>
      <motion.g
        initial={animate ? { opacity: 0 } : false}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 0.6 }}
        style={{ fontFamily: "var(--font-sans)" }}
        fontSize="17"
        fontWeight="600"
        fill="#17211d"
        textAnchor="middle"
      >
        <g transform="translate(508 520) rotate(-17.8)">
          <rect x="-46" y="-15" width="92" height="28" rx="14" fill="#fff" stroke="#e5e0d5" />
          <text y="5">1200 mm</text>
        </g>
        <g transform="translate(104 520) rotate(40.6)">
          <rect x="-40" y="-15" width="80" height="28" rx="14" fill="#fff" stroke="#e5e0d5" />
          <text y="5">800 mm</text>
        </g>
      </motion.g>
    </svg>
  );
}
