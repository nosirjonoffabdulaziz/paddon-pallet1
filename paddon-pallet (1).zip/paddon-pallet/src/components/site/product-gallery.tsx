"use client";

import Image from "next/image";
import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { PalletIso } from "./pallet-iso";

export type GalleryLabels = {
  close: string;
  previous: string;
  next: string;
  visualModel: string;
  photoPending: string;
  mm: string;
};

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  images: { url: string; alt: string }[];
  dims: { length: number; width: number; height: number } | null;
  labels: GalleryLabels;
  startIndex?: number;
};

/** Kengaytirilgan galereya: rasmlar + izometrik model (oxirgi slayd). */
export function ProductGallery({ open, onOpenChange, title, images, dims, labels, startIndex = 0 }: Props) {
  const slides = [
    ...images.map((img) => ({ type: "image" as const, ...img })),
    ...(dims ? [{ type: "model" as const, url: "", alt: labels.visualModel }] : []),
  ];
  const [index, setIndex] = useState(startIndex);
  const count = slides.length;

  useEffect(() => {
    if (open) setIndex(Math.min(startIndex, Math.max(0, count - 1)));
  }, [open, startIndex, count]);

  const go = useCallback((dir: 1 | -1) => setIndex((i) => (i + dir + count) % count), [count]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, go]);

  const slide = slides[index];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl p-3 sm:p-4" closeLabel={labels.close}>
        <DialogTitle className="sr-only">{title}</DialogTitle>
        <DialogDescription className="sr-only">{slide?.alt ?? title}</DialogDescription>
        <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-white">
          {slide?.type === "image" && (
            <Image src={slide.url} alt={slide.alt} fill sizes="(min-width: 1024px) 960px, 100vw" className="object-contain" />
          )}
          {slide?.type === "model" && dims && (
            <div className="bg-blueprint flex size-full flex-col items-center justify-center p-8">
              <PalletIso {...dims} unit={labels.mm} className="max-h-[80%] max-w-[85%]" animateDimensions />
              <span className="mt-2 text-xs text-muted">{labels.visualModel}</span>
            </div>
          )}
          {!slide && (
            <div className="grid size-full place-items-center text-sm text-muted">{labels.photoPending}</div>
          )}
          {count > 1 && (
            <>
              <button
                type="button"
                onClick={() => go(-1)}
                aria-label={labels.previous}
                className="absolute left-3 top-1/2 grid size-11 -translate-y-1/2 place-items-center rounded-full bg-white/90 shadow-soft transition hover:bg-white"
              >
                <ChevronLeft className="size-5" />
              </button>
              <button
                type="button"
                onClick={() => go(1)}
                aria-label={labels.next}
                className="absolute right-3 top-1/2 grid size-11 -translate-y-1/2 place-items-center rounded-full bg-white/90 shadow-soft transition hover:bg-white"
              >
                <ChevronRight className="size-5" />
              </button>
            </>
          )}
        </div>
        {count > 1 && (
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {slides.map((s, i) => (
              <button
                key={`${s.type}-${i}`}
                type="button"
                onClick={() => setIndex(i)}
                aria-label={s.alt}
                className={cn(
                  "relative h-16 w-20 shrink-0 overflow-hidden rounded-xl border-2 bg-white transition",
                  i === index ? "border-wood" : "border-transparent opacity-70 hover:opacity-100",
                )}
              >
                {s.type === "image" ? (
                  <Image src={s.url} alt="" fill sizes="80px" className="object-contain p-1" />
                ) : (
                  dims && <PalletIso {...dims} showDimensions={false} className="p-1.5" />
                )}
              </button>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
