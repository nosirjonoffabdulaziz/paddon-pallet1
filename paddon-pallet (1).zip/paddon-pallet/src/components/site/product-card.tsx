"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { ArrowUpRight, Expand } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import type { ProductDTO } from "@/lib/types";
import { productDims } from "@/lib/product-helpers";
import { cn, formatNumber } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PalletIso } from "./pallet-iso";
import { ProductGallery } from "./product-gallery";

export type CardDict = Pick<Dictionary, "common" | "labels" | "products">;

export function ProductCard({ product, dict, locale }: { product: ProductDTO; dict: CardDict; locale: string }) {
  const [open, setOpen] = useState(false);
  const dims = productDims(product);
  const cover = product.images[0];
  const href = `/${locale}/products/${product.slug}`;
  const c = dict.common;

  return (
    <article className="group flex flex-col overflow-hidden rounded-3xl border border-line bg-card shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift">
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="relative block aspect-[4/3] w-full overflow-hidden bg-white text-left"
        aria-label={`${dict.products.openGallery}: ${product.name}`}
      >
        {cover ? (
          <Image
            src={cover.url}
            alt={cover.alt}
            fill
            sizes="(min-width: 1280px) 380px, (min-width: 768px) 45vw, 100vw"
            className="object-contain p-4 transition-transform duration-500 group-hover:scale-[1.04]"
          />
        ) : dims ? (
          <div className="bg-blueprint flex size-full items-center justify-center p-8">
            <PalletIso {...dims} unit={c.mm} className="max-h-full transition-transform duration-500 group-hover:scale-[1.04]" />
          </div>
        ) : (
          <div className="bg-blueprint flex size-full items-center justify-center p-10">
            <PalletIso length={1200} width={1000} height={144} showDimensions={false} className="max-h-full opacity-60" />
            <span className="absolute font-display text-4xl font-bold text-wood-dark">? × ?</span>
          </div>
        )}
        <div className="absolute left-4 top-4 flex flex-wrap gap-1.5">
          {product.isDemo && <Badge variant="dark">{c.demo}</Badge>}
          <Badge variant="outline">{dict.labels.condition[product.condition]}</Badge>
        </div>
        <span className="absolute right-4 top-4 grid size-9 place-items-center rounded-full bg-white/90 text-ink opacity-0 shadow-soft transition group-hover:opacity-100">
          <Expand className="size-4" />
        </span>
        {!cover && dims && (
          <span className="absolute bottom-3 left-4 text-[11px] font-medium text-muted">{c.visualModel}</span>
        )}
      </button>

      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-display text-xl font-bold leading-snug">
            <Link href={href} className="transition-colors hover:text-wood-dark">
              {product.name}
            </Link>
          </h3>
        </div>
        <p className="mt-1 font-display text-[15px] font-semibold tracking-tight text-wood-dark">
          {dims ? `${dims.length} × ${dims.width} ${c.mm}` : c.individualSize}
        </p>

        <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-3 border-t border-line pt-5 text-sm">
          <div>
            <dt className="text-xs text-muted">{dict.products.material}</dt>
            <dd className="mt-0.5 font-medium">{dict.labels.material[product.material]}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted">{dict.products.loadCapacity}</dt>
            <dd className="mt-0.5 font-medium">
              {product.loadCapacityKg ? `${formatNumber(product.loadCapacityKg)} ${c.kg}` : "—"}
            </dd>
          </div>
          <div className="col-span-2 flex items-center gap-2">
            <span
              className={cn(
                "size-2 rounded-full",
                product.availability === "IN_STOCK" && "bg-success",
                product.availability === "ON_ORDER" && "bg-warning",
                product.availability === "OUT_OF_STOCK" && "bg-danger",
              )}
            />
            <span className="text-sm font-medium">{dict.labels.availability[product.availability]}</span>
          </div>
        </dl>

        <div className="mt-auto flex items-end justify-between gap-3 pt-6">
          <div>
            {product.price ? (
              <p className="font-display text-xl font-bold">
                {formatNumber(product.price)} <span className="text-sm font-semibold text-muted">{c.currency}</span>
              </p>
            ) : (
              <p className="text-sm font-semibold text-wood-dark">{c.requestPrice}</p>
            )}
          </div>
        </div>
        <div className="relative z-10 mt-4 grid grid-cols-2 gap-2">
          <Button asChild variant="outline" size="sm">
            <Link href={href}>
              {c.details} <ArrowUpRight />
            </Link>
          </Button>
          <Button asChild size="sm">
            <Link href={`/${locale}/order?product=${product.slug}`}>{c.order}</Link>
          </Button>
        </div>
      </div>

      <ProductGallery
        open={open}
        onOpenChange={setOpen}
        title={product.name}
        images={product.images}
        dims={dims}
        labels={{
          close: c.close,
          previous: c.previous,
          next: c.next,
          visualModel: c.visualModel,
          photoPending: c.photoPending,
          mm: c.mm,
        }}
      />
    </article>
  );
}
