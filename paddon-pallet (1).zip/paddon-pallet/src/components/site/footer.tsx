import Link from "next/link";
import { Mail, MapPin, Phone, Send } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import type { Locale } from "@/lib/i18n";
import type { ContactInfo } from "@/lib/settings";
import { phoneHref, telegramHref, telegramLabel } from "@/lib/utils";
import { Logo } from "./logo";

export function Footer({ locale, dict, contact }: { locale: Locale; dict: Dictionary; contact: ContactInfo }) {
  const base = `/${locale}`;
  const links = [
    { href: `${base}/products`, label: dict.nav.products },
    { href: `${base}/sizes`, label: dict.nav.sizes },
    { href: `${base}/about`, label: dict.nav.about },
    { href: `${base}/order`, label: dict.nav.order },
    { href: `${base}/contact`, label: dict.nav.contact },
  ];
  const year = new Date().getFullYear();

  return (
    <footer className="relative overflow-hidden bg-ink text-white">
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-10 right-0 select-none font-display text-[22vw] font-extrabold leading-none tracking-tighter text-white/[0.03]"
      >
        {dict.meta.brand}
      </div>
      <div className="container-page relative grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr] md:py-20">
        <div className="max-w-sm">
          <Logo href={base} brand={dict.meta.brand} sub={dict.meta.brandSub} inverted />
          <p className="mt-6 text-sm leading-relaxed text-white/60">{dict.footer.tagline}</p>
        </div>
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-white/40">{dict.footer.navTitle}</h3>
          <ul className="mt-5 space-y-3">
            {links.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="text-sm text-white/75 transition hover:text-white">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-white/40">{dict.footer.contactTitle}</h3>
          <ul className="mt-5 space-y-3 text-sm text-white/75">
            {contact.phone && (
              <li>
                <a href={phoneHref(contact.phone)} className="inline-flex items-center gap-2.5 hover:text-white">
                  <Phone className="size-4 text-wood" /> {contact.phone}
                </a>
              </li>
            )}
            {contact.telegram && (
              <li>
                <a
                  href={telegramHref(contact.telegram)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2.5 hover:text-white"
                >
                  <Send className="size-4 text-wood" /> {telegramLabel(contact.telegram)}
                </a>
              </li>
            )}
            {contact.email && (
              <li>
                <a href={`mailto:${contact.email}`} className="inline-flex items-center gap-2.5 hover:text-white">
                  <Mail className="size-4 text-wood" /> {contact.email}
                </a>
              </li>
            )}
            {contact.address && (
              <li className="flex gap-2.5">
                <MapPin className="mt-0.5 size-4 shrink-0 text-wood" /> {contact.address}
              </li>
            )}
            {!contact.phone && !contact.telegram && !contact.email && !contact.address && (
              <li>
                <Link href={`${base}/contact`} className="hover:text-white">
                  {dict.nav.contact} →
                </Link>
              </li>
            )}
          </ul>
        </div>
      </div>
      <div className="container-page relative flex flex-col gap-2 border-t border-white/10 py-6 text-xs text-white/40 sm:flex-row sm:justify-between">
        <span>
          © {year} {dict.meta.brand}. {dict.footer.rights}
        </span>
        <span>{dict.meta.brandSub} / {dict.meta.brand}</span>
      </div>
    </footer>
  );
}
