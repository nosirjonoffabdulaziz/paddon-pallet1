import { Clock, Mail, MapPin, Phone, Send } from "lucide-react";
import type { ReactNode } from "react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import type { ContactInfo as Info } from "@/lib/settings";
import { phoneHref, telegramHref, telegramLabel } from "@/lib/utils";

export function hasContactInfo(c: Info) {
  return Boolean(c.phone || c.telegram || c.email || c.address || c.hours);
}

export function ContactInfo({ contact, dict }: { contact: Info; dict: Pick<Dictionary, "contact"> }) {
  const t = dict.contact;
  if (!hasContactInfo(contact)) {
    return (
      <div className="rounded-3xl border border-dashed border-line bg-card/60 p-8 text-sm leading-relaxed text-muted">
        {t.notConfigured}
      </div>
    );
  }
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {contact.phone && (
        <Item icon={<Phone />} label={t.phone}>
          <a href={phoneHref(contact.phone)} className="hover:text-wood-dark">
            {contact.phone}
          </a>
          {contact.phone2 && (
            <a href={phoneHref(contact.phone2)} className="block hover:text-wood-dark">
              {contact.phone2}
            </a>
          )}
        </Item>
      )}
      {contact.telegram && (
        <Item icon={<Send />} label={t.telegram}>
          <a
            href={telegramHref(contact.telegram)}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-wood-dark"
          >
            {telegramLabel(contact.telegram)}
          </a>
        </Item>
      )}
      {contact.email && (
        <Item icon={<Mail />} label={t.email}>
          <a href={`mailto:${contact.email}`} className="break-all hover:text-wood-dark">
            {contact.email}
          </a>
        </Item>
      )}
      {contact.hours && (
        <Item icon={<Clock />} label={t.hours}>
          <span className="whitespace-pre-line">{contact.hours}</span>
        </Item>
      )}
      {contact.address && (
        <Item icon={<MapPin />} label={t.address} wide>
          <span className="whitespace-pre-line">{contact.address}</span>
        </Item>
      )}
    </div>
  );
}

function Item({ icon, label, children, wide }: { icon: ReactNode; label: string; children: ReactNode; wide?: boolean }) {
  return (
    <div className={`flex gap-4 rounded-2xl border border-line bg-card p-5 shadow-soft ${wide ? "sm:col-span-2" : ""}`}>
      <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-wood/10 text-wood-dark [&_svg]:size-5">
        {icon}
      </span>
      <div className="min-w-0">
        <p className="text-xs text-muted">{label}</p>
        <div className="mt-1 font-semibold">{children}</div>
      </div>
    </div>
  );
}
