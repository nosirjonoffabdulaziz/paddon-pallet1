"use client";

import Link from "next/link";
import { useState, type ReactNode } from "react";
import { ArrowRight, Info } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import { SIZE_LIMITS } from "@/lib/catalog-options";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { PalletIso } from "./pallet-iso";

export type SizePreset = { length: number; width: number; height: number; standard: boolean };

type Props = {
  locale: string;
  dict: Pick<Dictionary, "sizes" | "common">;
  presets: SizePreset[];
  /** Bosh sahifadagi ixcham variant */
  compact?: boolean;
};

export function SizeExplorer({ locale, dict, presets, compact = false }: Props) {
  const t = dict.sizes;
  const first = presets[0] ?? { length: 1200, width: 800, height: 144, standard: true };
  const [dims, setDims] = useState({ length: first.length, width: first.width, height: first.height });
  const [scaleMode, setScaleMode] = useState<"auto" | "fixed">("fixed");

  const standard = presets.filter((p) => p.standard);
  const custom = presets.filter((p) => !p.standard);
  const isPreset = (p: SizePreset) => p.length === dims.length && p.width === dims.width;
  const area = ((dims.length * dims.width) / 1_000_000).toFixed(2);

  const sliders: { key: keyof typeof dims; label: string; min: number; max: number; step: number }[] = [
    { key: "length", label: t.length, min: SIZE_LIMITS.length.min, max: 2500, step: 10 },
    { key: "width", label: t.width, min: SIZE_LIMITS.width.min, max: 2500, step: 10 },
    { key: "height", label: t.height, min: SIZE_LIMITS.height.min, max: 300, step: 2 },
  ];

  const presetButton = (p: SizePreset) => (
    <button
      key={`${p.length}x${p.width}`}
      type="button"
      onClick={() => setDims({ length: p.length, width: p.width, height: p.height })}
      className={cn(
        "flex items-center justify-between rounded-2xl border px-4 py-3 text-left transition",
        isPreset(p) ? "border-ink bg-ink text-white" : "border-line bg-card hover:border-ink/30",
      )}
    >
      <span className="font-display text-[15px] font-bold tabular-nums">
        {p.length} × {p.width}
      </span>
      <span className={cn("text-xs", isPreset(p) ? "text-white/60" : "text-muted")}>{dict.common.mm}</span>
    </button>
  );

  return (
    <div className={cn("grid gap-8 lg:gap-12", compact ? "lg:grid-cols-[1fr_1.15fr]" : "lg:grid-cols-[380px_1fr]")}>
      <div className="space-y-8">
        {!compact && (
          <>
            <PresetGroup title={t.standardTitle} empty={t.emptyList}>
              {standard.map(presetButton)}
            </PresetGroup>
            {custom.length > 0 && <PresetGroup title={t.customTitle}>{custom.map(presetButton)}</PresetGroup>}
          </>
        )}
        {compact && (
          <div className="flex flex-wrap gap-2">
            {presets.slice(0, 6).map((p) => (
              <button
                key={`${p.length}x${p.width}`}
                type="button"
                onClick={() => setDims({ length: p.length, width: p.width, height: p.height })}
                className={cn(
                  "rounded-full border px-4 py-2 text-sm font-semibold tabular-nums transition",
                  isPreset(p) ? "border-ink bg-ink text-white" : "border-line bg-card hover:border-ink/30",
                )}
              >
                {p.length} × {p.width}
              </button>
            ))}
          </div>
        )}

        <div className="rounded-3xl border border-line bg-card p-6 shadow-soft">
          <h3 className="mb-6 font-display text-base font-bold">{t.yourSize}</h3>
          <div className="space-y-6">
            {sliders.map((s) => (
              <div key={s.key}>
                <div className="mb-3 flex items-center justify-between">
                  <label htmlFor={`size-${s.key}`} className="text-sm font-medium">
                    {s.label}
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      min={s.min}
                      max={s.max}
                      value={dims[s.key]}
                      onChange={(e) => {
                        const n = Number.parseInt(e.target.value, 10);
                        if (Number.isFinite(n)) setDims((d) => ({ ...d, [s.key]: Math.min(s.max, Math.max(0, n)) }));
                      }}
                      onBlur={() => setDims((d) => ({ ...d, [s.key]: Math.min(s.max, Math.max(s.min, d[s.key])) }))}
                      className="h-9 w-24 rounded-lg border border-line bg-bg px-2 text-right text-sm font-semibold tabular-nums outline-none focus:border-wood"
                      aria-label={s.label}
                    />
                    <span className="text-xs text-muted">{dict.common.mm}</span>
                  </div>
                </div>
                <input
                  id={`size-${s.key}`}
                  type="range"
                  className="range"
                  min={s.min}
                  max={s.max}
                  step={s.step}
                  value={Math.max(s.min, dims[s.key])}
                  onChange={(e) => setDims((d) => ({ ...d, [s.key]: Number(e.target.value) }))}
                />
              </div>
            ))}
          </div>
          <div className="mt-6 flex items-center justify-between border-t border-line pt-5 text-sm">
            <span className="text-muted">{t.area}</span>
            <span className="font-display text-lg font-bold tabular-nums">
              {area} {t.areaUnit}
            </span>
          </div>
        </div>
      </div>

      <div className="flex flex-col">
        <div className="bg-blueprint relative flex flex-1 items-center justify-center overflow-hidden rounded-3xl border border-line bg-card p-6 sm:p-10">
          <div className="absolute right-4 top-4 flex rounded-full border border-line bg-white/80 p-1 text-xs font-semibold backdrop-blur">
            {(["fixed", "auto"] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setScaleMode(m)}
                className={cn(
                  "rounded-full px-3 py-1 transition",
                  scaleMode === m ? "bg-ink text-white" : "text-muted hover:text-ink",
                )}
              >
                {m === "fixed" ? "1:1" : "⤢"}
              </button>
            ))}
          </div>
          <PalletIso
            length={Math.max(SIZE_LIMITS.length.min, dims.length)}
            width={Math.max(SIZE_LIMITS.width.min, dims.width)}
            height={Math.max(SIZE_LIMITS.height.min, dims.height)}
            scale={scaleMode}
            unit={dict.common.mm}
            className="max-h-[440px]"
          />
        </div>
        <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="flex max-w-md gap-2 text-xs leading-relaxed text-muted">
            <Info className="mt-0.5 size-3.5 shrink-0 text-wood" />
            {t.disclaimer}
          </p>
          <Button asChild variant="wood" className="shrink-0">
            <Link href={`/${locale}/order?l=${dims.length}&w=${dims.width}&h=${dims.height}`}>
              {t.orderThisSize} <ArrowRight />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}

function PresetGroup({ title, children, empty }: { title: string; children: ReactNode; empty?: string }) {
  const hasChildren = Array.isArray(children) ? children.length > 0 : Boolean(children);
  return (
    <div>
      <h3 className="mb-3 text-xs font-semibold uppercase tracking-[0.14em] text-muted">{title}</h3>
      {hasChildren ? (
        <div className="grid grid-cols-2 gap-2">{children}</div>
      ) : (
        <p className="text-sm text-muted">{empty}</p>
      )}
    </div>
  );
}
