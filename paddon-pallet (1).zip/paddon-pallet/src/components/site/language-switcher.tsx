"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { LOCALE_COOKIE, locales, type Locale } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function LanguageSwitcher({
  current,
  label,
  className,
}: {
  current: Locale;
  label: string;
  className?: string;
}) {
  const pathname = usePathname() ?? `/${current}`;
  const searchParams = useSearchParams();
  const query = searchParams?.toString();

  const hrefFor = (locale: Locale) => {
    const parts = pathname.split("/");
    parts[1] = locale;
    const path = parts.join("/") || `/${locale}`;
    return query ? `${path}?${query}` : path;
  };

  const remember = (locale: Locale) => {
    document.cookie = `${LOCALE_COOKIE}=${locale}; path=/; max-age=31536000; samesite=lax`;
  };

  return (
    <nav aria-label={label} className={cn("flex items-center rounded-full border border-line bg-card p-1", className)}>
      {locales.map((locale) => (
        <Link
          key={locale}
          href={hrefFor(locale)}
          onClick={() => remember(locale)}
          hrefLang={locale}
          aria-current={locale === current ? "true" : undefined}
          className={cn(
            "rounded-full px-2.5 py-1 text-xs font-semibold uppercase tracking-wider transition-colors",
            locale === current ? "bg-ink text-white" : "text-muted hover:text-ink",
          )}
        >
          {locale}
        </Link>
      ))}
    </nav>
  );
}
