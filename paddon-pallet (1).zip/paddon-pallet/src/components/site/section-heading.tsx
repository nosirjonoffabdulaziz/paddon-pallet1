import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function SectionHeading({
  eyebrow,
  title,
  text,
  align = "left",
  action,
  className,
  as: Tag = "h2",
}: {
  eyebrow?: string;
  title: string;
  text?: string;
  align?: "left" | "center";
  action?: ReactNode;
  className?: string;
  as?: "h1" | "h2";
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-6 md:flex-row md:items-end md:justify-between",
        align === "center" && "items-center text-center md:flex-col md:items-center",
        className,
      )}
    >
      <div className={cn("max-w-2xl", align === "center" && "mx-auto")}>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <Tag
          className={cn(
            "mt-4 font-display font-bold text-ink text-balance",
            Tag === "h1" ? "text-4xl md:text-5xl lg:text-[56px] lg:leading-[1.05]" : "text-3xl md:text-[40px] md:leading-tight",
          )}
        >
          {title}
        </Tag>
        {text && <p className="mt-4 text-base leading-relaxed text-muted md:text-lg">{text}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

export function PageHero({ eyebrow, title, text }: { eyebrow: string; title: string; text?: string }) {
  return (
    <section className="relative overflow-hidden border-b border-line">
      <div className="bg-blueprint absolute inset-0 [mask-image:linear-gradient(to_bottom,black,transparent)]" aria-hidden />
      <div className="container-page relative py-14 md:py-20">
        <SectionHeading as="h1" eyebrow={eyebrow} title={title} text={text} />
      </div>
    </section>
  );
}
