"use client";

import Image from "next/image";
import { useState } from "react";
import { Expand } from "lucide-react";
import { cn } from "@/lib/utils";
import { PalletIso } from "./pallet-iso";
import { ProductGallery, type GalleryLabels } from "./product-gallery";

type Props = {
  title: string;
  images: { url: string; alt: string }[];
  dims: { length: number; width: number; height: number } | null;
  labels: GalleryLabels;
};

/** Mahsulot sahifasidagi asosiy rasm + kichik rasmlar. Bosilganda kengaytirilgan galereya ochiladi. */
export function ProductDetailGallery({ title, images, dims, labels }: Props) {
  const [active, setActive] = useState(0);
  const [open, setOpen] = useState(false);
  const total = images.length + (dims ? 1 : 0);
  const showModel = active >= images.length;

  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="group relative block aspect-[4/3] w-full overflow-hidden rounded-[2rem] border border-line bg-white"
        aria-label={title}
      >
        {!showModel && images[active] ? (
          <Image
            src={images[active].url}
            alt={images[active].alt}
            fill
            priority
            sizes="(min-width: 1024px) 55vw, 100vw"
            className="object-contain p-6 transition-transform duration-500 group-hover:scale-[1.03]"
          />
        ) : dims ? (
          <div className="bg-blueprint flex size-full flex-col items-center justify-center p-10">
            <PalletIso {...dims} unit={labels.mm} className="max-h-[85%]" animateDimensions />
            <span className="mt-3 text-xs text-muted">{labels.visualModel}</span>
          </div>
        ) : (
          <div className="bg-blueprint grid size-full place-items-center p-10 text-sm text-muted">
            {labels.photoPending}
          </div>
        )}
        <span className="absolute right-4 top-4 grid size-10 place-items-center rounded-full bg-white/90 shadow-soft">
          <Expand className="size-4" />
        </span>
      </button>

      {total > 1 && (
        <div className="mt-3 flex gap-3 overflow-x-auto pb-1">
          {images.map((img, i) => (
            <button
              key={img.url}
              type="button"
              onClick={() => setActive(i)}
              aria-label={img.alt}
              className={cn(
                "relative h-20 w-24 shrink-0 overflow-hidden rounded-2xl border-2 bg-white transition",
                active === i ? "border-wood" : "border-line opacity-70 hover:opacity-100",
              )}
            >
              <Image src={img.url} alt="" fill sizes="96px" className="object-contain p-1.5" />
            </button>
          ))}
          {dims && (
            <button
              type="button"
              onClick={() => setActive(images.length)}
              aria-label={labels.visualModel}
              className={cn(
                "relative h-20 w-24 shrink-0 overflow-hidden rounded-2xl border-2 bg-white p-2 transition",
                showModel ? "border-wood" : "border-line opacity-70 hover:opacity-100",
              )}
            >
              <PalletIso {...dims} showDimensions={false} />
            </button>
          )}
        </div>
      )}

      <ProductGallery
        open={open}
        onOpenChange={setOpen}
        title={title}
        images={images}
        dims={dims}
        labels={labels}
        startIndex={active}
      />
    </div>
  );
}
