"use client";

import { useId, useMemo } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Izometrik pallet modeli (SVG). O‘lchamlar millimetrda.
 * Faqat vizual namoyish — ishlab chiqarish chizmasi EMAS.
 *
 * Konstruksiya (yevropallet uslubida):
 *   pastki taxtalar (3) → tayanch bloklar (3×3) → ko‘ndalang taxtalar (3) → ustki taxtalar (n)
 */
type Box = { x: number; y: number; z: number; dx: number; dy: number; dz: number; kind: "board" | "block" };
type Pt = [number, number];

const COS = Math.cos(Math.PI / 6);
const SIN = 0.5;
const BOARD = 22;

const project = (x: number, y: number, z: number): Pt => [(x - y) * COS, (x + y) * SIN - z];

function buildPallet(L: number, W: number, H: number): Box[][] {
  const blockH = Math.max(40, H - 3 * BOARD);
  const bx = Math.min(145, L * 0.14);
  const by = Math.min(145, W * 0.18);
  const xs = [0, (L - bx) / 2, L - bx];
  const ys = [0, (W - by) / 2, W - by];

  const bottom: Box[] = ys.map((y) => ({ x: 0, y, z: 0, dx: L, dy: by, dz: BOARD, kind: "board" }));
  const blocks: Box[] = xs.flatMap((x) =>
    ys.map((y) => ({ x, y, z: BOARD, dx: bx, dy: by, dz: blockH, kind: "block" as const })),
  );
  const cross: Box[] = xs.map((x) => ({ x, y: 0, z: BOARD + blockH, dx: bx, dy: W, dz: BOARD, kind: "board" }));

  const n = Math.min(11, Math.max(3, Math.round(W / 165)));
  const bw = Math.min(145, (W / n) * 0.8);
  const top: Box[] = Array.from({ length: n }, (_, i) => ({
    x: 0,
    y: n === 1 ? 0 : (i * (W - bw)) / (n - 1),
    z: 2 * BOARD + blockH,
    dx: L,
    dy: bw,
    dz: BOARD,
    kind: "board",
  }));

  const depth = (b: Box) => b.x + b.dx / 2 + (b.y + b.dy / 2);
  return [bottom, blocks, cross, top].map((layer) => [...layer].sort((a, b) => depth(a) - depth(b)));
}

const pts = (list: Pt[]) => list.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");

function faces(b: Box) {
  const x1 = b.x + b.dx;
  const y1 = b.y + b.dy;
  const z1 = b.z + b.dz;
  return {
    top: [project(b.x, b.y, z1), project(x1, b.y, z1), project(x1, y1, z1), project(b.x, y1, z1)],
    right: [project(x1, b.y, b.z), project(x1, y1, b.z), project(x1, y1, z1), project(x1, b.y, z1)],
    left: [project(b.x, y1, b.z), project(x1, y1, b.z), project(x1, y1, z1), project(b.x, y1, z1)],
  };
}

export type PalletIsoProps = {
  length: number;
  width: number;
  height?: number;
  /** "fixed" — barcha o‘lchamlar bir xil masshtabda (o‘lcham farqi ko‘rinadi) */
  scale?: "auto" | "fixed";
  showDimensions?: boolean;
  animateDimensions?: boolean;
  unit?: string;
  className?: string;
  title?: string;
};

export function PalletIso({
  length,
  width,
  height = 144,
  scale = "auto",
  showDimensions = true,
  animateDimensions = false,
  unit = "mm",
  className,
  title,
}: PalletIsoProps) {
  const uid = useId().replace(/:/g, "");
  const L = Math.max(100, length);
  const W = Math.max(100, width);
  const H = Math.max(80, height);

  const model = useMemo(() => {
    const layers = buildPallet(L, W, H);
    const off = Math.max(L, W) * 0.11;
    // O‘lcham chiziqlari (old tomonlar bo‘ylab)
    const lenA = project(0, W + off, 0);
    const lenB = project(L, W + off, 0);
    const widA = project(L + off, 0, 0);
    const widB = project(L + off, W, 0);
    const hA = project(L, 0, 0);
    const hB = project(L, 0, H);
    const hOff = off * 0.75;

    const all: Pt[] = [project(0, 0, 0), project(L, 0, 0), project(0, W, 0), project(L, W, 0), project(0, 0, H), project(L, 0, H), project(0, W, H), project(L, W, H)];
    const labelFs = Math.max(L, W) * 0.05;
    if (showDimensions) all.push(lenA, lenB, widA, widB, [hB[0] + hOff + labelFs * 4.2, hB[1]]);

    let bounds: { minX: number; minY: number; w: number; h: number };
    if (scale === "fixed") {
      // Barcha o‘lchamlar bir masshtabda (1,8 m gacha) — o‘lchamlar farqi ko‘rinadi
      const R = Math.max(1800, L, W) * 1.15;
      const ref: Pt[] = [project(0, R, 0), project(R, 0, 0), project(0, 0, 400), project(R, R, 0)];
      const xsR = ref.map((p) => p[0]);
      const ysR = ref.map((p) => p[1]);
      bounds = {
        minX: Math.min(...xsR),
        minY: Math.min(...ysR),
        w: Math.max(...xsR) - Math.min(...xsR),
        h: Math.max(...ysR) - Math.min(...ysR),
      };
    } else {
      const xsA = all.map((p) => p[0]);
      const ysA = all.map((p) => p[1]);
      bounds = {
        minX: Math.min(...xsA),
        minY: Math.min(...ysA),
        w: Math.max(...xsA) - Math.min(...xsA),
        h: Math.max(...ysA) - Math.min(...ysA),
      };
    }
    const pad = Math.max(bounds.w, bounds.h) * (scale === "fixed" ? 0.04 : 0.12);
    const fontSize = scale === "fixed" ? Math.max(1800, L, W) * 0.06 : Math.max(bounds.w, bounds.h) * 0.042;

    // Soya — pallet tagidagi izometrik yuza
    const shadow = [project(-20, -20, 0), project(L + 40, -20, 0), project(L + 40, W + 40, 0), project(-20, W + 40, 0)];

    return { layers, lenA, lenB, widA, widB, hA, hB, hOff, bounds, pad, fontSize, shadow };
  }, [L, W, H, scale, showDimensions]);

  const { bounds, pad } = model;
  const viewBox = `${(bounds.minX - pad).toFixed(1)} ${(bounds.minY - pad).toFixed(1)} ${(bounds.w + pad * 2).toFixed(1)} ${(bounds.h + pad * 2).toFixed(1)}`;

  const mid = (a: Pt, b: Pt): Pt => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const lenMid = mid(model.lenA, model.lenB);
  const widMid = mid(model.widA, model.widB);
  const hMid = mid(model.hA, model.hB);
  const fs = model.fontSize;
  const strokeW = fs * 0.07;

  const dimLine = (a: Pt, b: Pt, delay: number) =>
    animateDimensions ? (
      <motion.line
        x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]}
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 1.1, delay, ease: [0.65, 0, 0.35, 1] }}
      />
    ) : (
      <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} />
    );

  const tick = (p: Pt, angle: number) => {
    const s = fs * 0.35;
    const rad = (angle * Math.PI) / 180;
    return (
      <line
        x1={p[0] - Math.cos(rad) * s}
        y1={p[1] - Math.sin(rad) * s}
        x2={p[0] + Math.cos(rad) * s}
        y2={p[1] + Math.sin(rad) * s}
      />
    );
  };

  return (
    <svg
      viewBox={viewBox}
      className={cn("h-auto w-full overflow-visible", className)}
      role="img"
      aria-label={title ?? `${length} × ${width} × ${height} ${unit}`}
    >
      <defs>
        <filter id={`blur-${uid}`} x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation={Math.max(L, W) * 0.02} />
        </filter>
        <linearGradient id={`top-${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ecd8b6" />
          <stop offset="100%" stopColor="#dcc199" />
        </linearGradient>
      </defs>

      <polygon points={pts(model.shadow)} fill="#17211d" opacity={0.13} filter={`url(#blur-${uid})`} />

      <g stroke="#7d5c37" strokeOpacity={0.35} strokeWidth={Math.max(L, W) * 0.0015} strokeLinejoin="round">
        {model.layers.map((layer, li) =>
          layer.map((box, bi) => {
            const f = faces(box);
            const isBlock = box.kind === "block";
            return (
              <g key={`${li}-${bi}`}>
                <polygon points={pts(f.left)} fill={isBlock ? "#b9925f" : "#c49b68"} />
                <polygon points={pts(f.right)} fill={isBlock ? "#cfa874" : "#d6b282"} />
                <polygon points={pts(f.top)} fill={li === 3 ? `url(#top-${uid})` : "#e2c9a2"} />
              </g>
            );
          }),
        )}
      </g>

      {showDimensions && (
        <g fill="none" stroke="#a77948" strokeWidth={strokeW} strokeLinecap="round">
          {dimLine(model.lenA, model.lenB, 0.2)}
          {dimLine(model.widA, model.widB, 0.45)}
          {dimLine([model.hA[0] + model.hOff, model.hA[1]], [model.hB[0] + model.hOff, model.hB[1]], 0.7)}
          {tick(model.lenA, 150)}
          {tick(model.lenB, 150)}
          {tick(model.widA, 30)}
          {tick(model.widB, 30)}
          {tick([model.hA[0] + model.hOff, model.hA[1]], 0)}
          {tick([model.hB[0] + model.hOff, model.hB[1]], 0)}
        </g>
      )}

      {showDimensions && (
        <g
          fill="#17211d"
          fontWeight={600}
          fontSize={fs}
          textAnchor="middle"
          style={{ fontFamily: "var(--font-sans)", fontVariantNumeric: "tabular-nums" }}
        >
          <motion.g
            initial={animateDimensions ? { opacity: 0 } : false}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
          >
            <text x={lenMid[0]} y={lenMid[1]} dy={fs * 1.3} transform={`rotate(30 ${lenMid[0]} ${lenMid[1]})`}>
              {Math.round(length)} {unit}
            </text>
          </motion.g>
          <motion.g
            initial={animateDimensions ? { opacity: 0 } : false}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.1 }}
          >
            <text x={widMid[0]} y={widMid[1]} dy={fs * 1.3} transform={`rotate(-30 ${widMid[0]} ${widMid[1]})`}>
              {Math.round(width)} {unit}
            </text>
          </motion.g>
          <motion.g
            initial={animateDimensions ? { opacity: 0 } : false}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3 }}
          >
            <text
              x={hMid[0] + model.hOff + fs * 0.6}
              y={hMid[1] + fs * 0.35}
              textAnchor="start"
              fontSize={fs * 0.85}
              fill="#67736b"
            >
              {Math.round(height)} {unit}
            </text>
          </motion.g>
        </g>
      )}
    </svg>
  );
}
