"use client";

import Image from "next/image";
import { useMemo, useState, type FormEvent, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, Minus, Plus, X } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import { CONDITIONS, MATERIALS, SIZE_LIMITS, type ConditionValue, type MaterialValue } from "@/lib/catalog-options";
import type { Locale } from "@/lib/i18n";
import type { ErrorCode } from "@/lib/validation";
import { cn, format, formatNumber } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { FieldError, Input, Label, Select, Textarea } from "@/components/ui/input";
import { PalletIso } from "./pallet-iso";
import { Spinner } from "./states";

type Props = {
  locale: Locale;
  dict: Pick<Dictionary, "order" | "labels" | "common" | "errors" | "sizes">;
  initial: {
    length: number;
    width: number;
    height: number;
    product: { slug: string; name: string; image: string | null; isCustomSize: boolean } | null;
    material: MaterialValue;
    condition: ConditionValue;
  };
};

type Fields = {
  lengthMm: string;
  widthMm: string;
  heightMm: string;
  quantity: string;
  woodType: MaterialValue;
  condition: ConditionValue;
  notes: string;
  customerName: string;
  phone: string;
  website: string;
};

const clampNum = (v: string, min: number, max: number, fallback: number) => {
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

export function OrderConfigurator({ locale, dict, initial }: Props) {
  const t = dict.order;
  const [product, setProduct] = useState(initial.product);
  const [fields, setFields] = useState<Fields>({
    lengthMm: String(initial.length),
    widthMm: String(initial.width),
    heightMm: String(initial.height),
    quantity: String(SIZE_LIMITS.quantity.default),
    woodType: initial.material,
    condition: initial.condition,
    notes: "",
    customerName: "",
    phone: "",
    website: "",
  });
  const [errors, setErrors] = useState<Partial<Record<keyof Fields | "form", string>>>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");
  const [orderNumber, setOrderNumber] = useState<number | null>(null);

  const set = <K extends keyof Fields>(key: K, value: Fields[K]) => {
    setFields((f) => ({ ...f, [key]: value }));
    if (errors[key]) setErrors((e) => ({ ...e, [key]: undefined }));
  };

  // Ko‘rinish uchun qiymatlar chegaraga keltiriladi (kiritilgan qiymat o‘zgarmaydi)
  const preview = useMemo(
    () => ({
      length: clampNum(fields.lengthMm, SIZE_LIMITS.length.min, SIZE_LIMITS.length.max, SIZE_LIMITS.length.default),
      width: clampNum(fields.widthMm, SIZE_LIMITS.width.min, SIZE_LIMITS.width.max, SIZE_LIMITS.width.default),
      height: clampNum(fields.heightMm, SIZE_LIMITS.height.min, SIZE_LIMITS.height.max, SIZE_LIMITS.height.default),
    }),
    [fields.lengthMm, fields.widthMm, fields.heightMm],
  );

  const errorText = (code?: string) => (code ? (dict.errors[code as ErrorCode] ?? dict.errors.generic) : undefined);

  const validateClient = (): boolean => {
    const next: typeof errors = {};
    const intCheck = (key: keyof Fields, min: number, max: number) => {
      const raw = String(fields[key]).trim();
      if (!raw) next[key] = "required";
      else if (!/^\d+$/.test(raw)) next[key] = "invalidNumber";
      else if (Number(raw) < min) next[key] = "tooSmall";
      else if (Number(raw) > max) next[key] = "tooLarge";
    };
    intCheck("lengthMm", SIZE_LIMITS.length.min, SIZE_LIMITS.length.max);
    intCheck("widthMm", SIZE_LIMITS.width.min, SIZE_LIMITS.width.max);
    intCheck("heightMm", SIZE_LIMITS.height.min, SIZE_LIMITS.height.max);
    intCheck("quantity", SIZE_LIMITS.quantity.min, SIZE_LIMITS.quantity.max);
    if (fields.customerName.trim().length < 2) next.customerName = fields.customerName.trim() ? "tooShort" : "required";
    const digits = fields.phone.replace(/\D/g, "");
    if (!fields.phone.trim()) next.phone = "required";
    else if (digits.length < 7 || digits.length > 15 || !/^\+?[\d\s()-]+$/.test(fields.phone.trim())) next.phone = "invalidPhone";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (status === "submitting") return;
    if (!validateClient()) {
      setErrors((prev) => ({ ...prev, form: dict.errors.validation }));
      return;
    }
    setStatus("submitting");
    setErrors({});
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...fields, productSlug: product?.slug ?? "", locale }),
      });
      const data = (await res.json().catch(() => null)) as
        | { ok: true; number: number }
        | { ok: false; error: string; fields?: Record<string, string> }
        | null;
      if (data && data.ok) {
        setOrderNumber(data.number);
        setStatus("success");
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
      setStatus("idle");
      if (data && !data.ok) {
        setErrors({
          ...(data.fields ?? {}),
          form:
            data.error === "rateLimited"
              ? dict.errors.rateLimited
              : data.error === "validation"
                ? dict.errors.validation
                : dict.errors.generic,
        });
      } else setErrors({ form: dict.errors.generic });
    } catch {
      setStatus("idle");
      setErrors({ form: dict.errors.network });
    }
  }

  const reset = () => {
    setFields((f) => ({ ...f, notes: "", quantity: String(SIZE_LIMITS.quantity.default) }));
    setOrderNumber(null);
    setStatus("idle");
  };

  if (status === "success") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-auto max-w-xl rounded-3xl border border-line bg-card p-10 text-center shadow-soft"
      >
        <CheckCircle2 className="mx-auto size-14 text-success" strokeWidth={1.5} />
        <h2 className="mt-5 font-display text-2xl font-bold">{t.successTitle}</h2>
        <p className="mt-3 text-muted">{format(t.successText, { number: orderNumber ?? "" })}</p>
        <Button className="mt-8" onClick={reset}>
          {t.newOrder}
        </Button>
      </motion.div>
    );
  }

  const area = ((preview.length * preview.width) / 1_000_000).toFixed(2);

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-8 lg:grid-cols-[1fr_440px] lg:gap-10">
      <div className="space-y-6">
        {product && (
          <div className="flex items-center gap-4 rounded-2xl border border-wood/30 bg-wood/5 p-4">
            {product.image && (
              <div className="relative size-16 shrink-0 overflow-hidden rounded-xl bg-white">
                <Image src={product.image} alt="" fill sizes="64px" className="object-contain p-1" />
              </div>
            )}
            <div className="min-w-0 flex-1">
              <p className="text-xs text-muted">{t.selectedProduct}</p>
              <p className="truncate font-semibold">{product.name}</p>
            </div>
            <Button type="button" variant="ghost" size="sm" onClick={() => setProduct(null)}>
              <X /> {t.removeProduct}
            </Button>
          </div>
        )}

        <Card title={t.sectionSize}>
          <div className="grid gap-5 sm:grid-cols-3">
            <NumberField
              id="lengthMm"
              label={t.length}
              value={fields.lengthMm}
              onChange={(v) => set("lengthMm", v)}
              error={errorText(errors.lengthMm)}
              min={SIZE_LIMITS.length.min}
              max={SIZE_LIMITS.length.max}
              step={50}
            />
            <NumberField
              id="widthMm"
              label={t.width}
              value={fields.widthMm}
              onChange={(v) => set("widthMm", v)}
              error={errorText(errors.widthMm)}
              min={SIZE_LIMITS.width.min}
              max={SIZE_LIMITS.width.max}
              step={50}
            />
            <NumberField
              id="heightMm"
              label={t.height}
              value={fields.heightMm}
              onChange={(v) => set("heightMm", v)}
              error={errorText(errors.heightMm)}
              min={SIZE_LIMITS.height.min}
              max={SIZE_LIMITS.height.max}
              step={5}
            />
          </div>
          <p className="mt-4 text-xs text-muted">
            {SIZE_LIMITS.length.min}–{SIZE_LIMITS.length.max} {dict.common.mm} · {dict.sizes.area}: {area} {dict.sizes.areaUnit}
          </p>
        </Card>

        <Card title={t.sectionDetails}>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <Label htmlFor="quantity">{t.quantity}</Label>
              <Stepper
                id="quantity"
                value={fields.quantity}
                onChange={(v) => set("quantity", v)}
                min={SIZE_LIMITS.quantity.min}
                max={SIZE_LIMITS.quantity.max}
                invalid={Boolean(errors.quantity)}
              />
              <FieldError message={errorText(errors.quantity)} />
            </div>
            <div>
              <Label htmlFor="woodType">{t.woodType}</Label>
              <Select
                id="woodType"
                value={fields.woodType}
                onChange={(e) => set("woodType", e.target.value as MaterialValue)}
              >
                {MATERIALS.map((m) => (
                  <option key={m} value={m}>
                    {dict.labels.material[m]}
                  </option>
                ))}
              </Select>
            </div>
            <div className="sm:col-span-2">
              <span className="mb-2 block text-sm font-medium">{t.condition}</span>
              <div className="grid grid-cols-2 gap-3">
                {CONDITIONS.map((c) => (
                  <label
                    key={c}
                    className={cn(
                      "flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3.5 text-sm font-medium transition",
                      fields.condition === c ? "border-wood bg-wood/5 ring-4 ring-wood/10" : "border-line bg-card hover:border-ink/25",
                    )}
                  >
                    <input
                      type="radio"
                      name="condition"
                      value={c}
                      checked={fields.condition === c}
                      onChange={() => set("condition", c)}
                      className="accent-[#a77948]"
                    />
                    {dict.labels.condition[c]}
                  </label>
                ))}
              </div>
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="notes">{t.notes}</Label>
              <Textarea
                id="notes"
                value={fields.notes}
                onChange={(e) => set("notes", e.target.value)}
                placeholder={t.notesPlaceholder}
                maxLength={1500}
                aria-invalid={Boolean(errors.notes)}
              />
              <FieldError message={errorText(errors.notes)} />
            </div>
          </div>
        </Card>

        <Card title={t.sectionContact}>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <Label htmlFor="customerName">{t.name}</Label>
              <Input
                id="customerName"
                autoComplete="name"
                value={fields.customerName}
                onChange={(e) => set("customerName", e.target.value)}
                placeholder={t.namePlaceholder}
                maxLength={80}
                aria-invalid={Boolean(errors.customerName)}
              />
              <FieldError message={errorText(errors.customerName)} />
            </div>
            <div>
              <Label htmlFor="phone">{t.phone}</Label>
              <Input
                id="phone"
                type="tel"
                autoComplete="tel"
                inputMode="tel"
                value={fields.phone}
                onChange={(e) => set("phone", e.target.value)}
                placeholder={t.phonePlaceholder}
                maxLength={25}
                aria-invalid={Boolean(errors.phone)}
              />
              <FieldError message={errorText(errors.phone)} />
            </div>
          </div>
          {/* Honeypot — foydalanuvchiga ko‘rinmaydi */}
          <input
            type="text"
            name="website"
            tabIndex={-1}
            autoComplete="off"
            value={fields.website}
            onChange={(e) => set("website", e.target.value)}
            className="absolute -left-[9999px] h-0 w-0 opacity-0"
            aria-hidden
          />
        </Card>
      </div>

      <aside className="lg:sticky lg:top-24 lg:self-start">
        <div className="overflow-hidden rounded-3xl border border-line bg-card shadow-soft">
          <div className="border-b border-line px-6 py-4">
            <h2 className="font-display text-lg font-bold">{t.preview}</h2>
          </div>
          <div className="bg-blueprint relative px-6 py-8">
            <PalletIso {...preview} unit={dict.common.mm} className="mx-auto max-h-72" />
            <p className="mt-3 text-center text-[11px] text-muted">{t.previewNote}</p>
          </div>
          <div className="space-y-3 border-t border-line px-6 py-5 text-sm">
            <h3 className="font-semibold">{t.summary}</h3>
            <Row label={dict.sizes.length} value={`${preview.length} ${dict.common.mm}`} />
            <Row label={dict.sizes.width} value={`${preview.width} ${dict.common.mm}`} />
            <Row label={dict.sizes.height} value={`${preview.height} ${dict.common.mm}`} />
            <Row label={t.woodType} value={dict.labels.material[fields.woodType]} />
            <Row label={t.condition} value={dict.labels.condition[fields.condition]} />
            <Row
              label={t.quantity}
              value={`${formatNumber(Number(fields.quantity) || 0)} ${dict.common.pcs}`}
            />
          </div>
          <div className="border-t border-line p-6">
            <AnimatePresence>
              {errors.form && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  role="alert"
                  className="mb-4 rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger"
                >
                  {errors.form}
                </motion.p>
              )}
            </AnimatePresence>
            <Button type="submit" variant="wood" size="lg" className="w-full" disabled={status === "submitting"}>
              {status === "submitting" ? (
                <>
                  <Spinner /> {t.submitting}
                </>
              ) : (
                t.submit
              )}
            </Button>
            <p className="mt-3 text-center text-xs text-muted">{t.privacy}</p>
          </div>
        </div>
      </aside>
    </form>
  );
}

function Card({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="relative rounded-3xl border border-line bg-card p-6 shadow-soft sm:p-8">
      <h2 className="mb-6 font-display text-lg font-bold">{title}</h2>
      {children}
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-muted">{label}</span>
      <span className="text-right font-medium tabular-nums">{value}</span>
    </div>
  );
}

function NumberField({
  id,
  label,
  value,
  onChange,
  error,
  min,
  max,
  step,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  min: number;
  max: number;
  step: number;
}) {
  const num = Number.parseInt(value, 10);
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        type="number"
        inputMode="numeric"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(e.target.value.replace(/[^\d]/g, ""))}
        aria-invalid={Boolean(error)}
        className="font-semibold tabular-nums"
      />
      <input
        type="range"
        className="range mt-4"
        min={min}
        max={max}
        step={step}
        value={Number.isFinite(num) ? Math.min(max, Math.max(min, num)) : min}
        onChange={(e) => onChange(e.target.value)}
        aria-label={label}
      />
      <FieldError message={error} />
    </div>
  );
}

function Stepper({
  id,
  value,
  onChange,
  min,
  max,
  invalid,
}: {
  id: string;
  value: string;
  onChange: (v: string) => void;
  min: number;
  max: number;
  invalid: boolean;
}) {
  const n = Number.parseInt(value, 10) || 0;
  const step = n >= 100 ? 10 : 1;
  return (
    <div className="flex items-center gap-2">
      <Button
        type="button"
        variant="outline"
        size="icon"
        className="size-12 shrink-0 rounded-xl"
        onClick={() => onChange(String(Math.max(min, n - step)))}
        aria-label="−"
      >
        <Minus />
      </Button>
      <Input
        id={id}
        inputMode="numeric"
        value={value}
        onChange={(e) => onChange(e.target.value.replace(/[^\d]/g, ""))}
        aria-invalid={invalid}
        className="text-center font-semibold tabular-nums"
      />
      <Button
        type="button"
        variant="outline"
        size="icon"
        className="size-12 shrink-0 rounded-xl"
        onClick={() => onChange(String(Math.min(max, n + step)))}
        aria-label="+"
      >
        <Plus />
      </Button>
    </div>
  );
}
