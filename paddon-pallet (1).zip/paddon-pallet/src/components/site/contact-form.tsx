"use client";

import { useState, type FormEvent } from "react";
import { CheckCircle2, Send } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import type { Locale } from "@/lib/i18n";
import type { ErrorCode } from "@/lib/validation";
import { Button } from "@/components/ui/button";
import { FieldError, Input, Label, Textarea } from "@/components/ui/input";
import { Spinner } from "./states";

type Props = { locale: Locale; dict: Pick<Dictionary, "contact" | "errors" | "order"> };

export function ContactForm({ locale, dict }: Props) {
  const t = dict.contact;
  const [values, setValues] = useState({ name: "", phone: "", message: "", website: "" });
  const [errors, setErrors] = useState<Record<string, string | undefined>>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");

  const set = (key: keyof typeof values, value: string) => {
    setValues((v) => ({ ...v, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };
  const msg = (code?: string) => (code ? (dict.errors[code as ErrorCode] ?? dict.errors.generic) : undefined);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (values.name.trim().length < 2) next.name = values.name.trim() ? "tooShort" : "required";
    const digits = values.phone.replace(/\D/g, "");
    if (!values.phone.trim()) next.phone = "required";
    else if (digits.length < 7 || digits.length > 15) next.phone = "invalidPhone";
    if (values.message.trim().length < 5) next.message = values.message.trim() ? "tooShort" : "required";
    if (Object.keys(next).length) {
      setErrors(next);
      return;
    }

    setStatus("submitting");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...values, locale }),
      });
      const data = (await res.json().catch(() => null)) as
        | { ok: boolean; error?: string; fields?: Record<string, string> }
        | null;
      if (data?.ok) {
        setStatus("success");
        setValues({ name: "", phone: "", message: "", website: "" });
        return;
      }
      setStatus("idle");
      setErrors({
        ...(data?.fields ?? {}),
        form: data?.error === "rateLimited" ? dict.errors.rateLimited : dict.errors.generic,
      });
    } catch {
      setStatus("idle");
      setErrors({ form: dict.errors.network });
    }
  }

  if (status === "success") {
    return (
      <div className="flex flex-col items-center rounded-3xl border border-line bg-card p-10 text-center shadow-soft">
        <CheckCircle2 className="size-12 text-success" strokeWidth={1.5} />
        <p className="mt-4 max-w-sm font-medium">{t.success}</p>
        <Button variant="outline" className="mt-6" onClick={() => setStatus("idle")}>
          {t.formTitle}
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="relative rounded-3xl border border-line bg-card p-6 shadow-soft sm:p-8">
      <h2 className="font-display text-xl font-bold">{t.formTitle}</h2>
      <div className="mt-6 grid gap-5 sm:grid-cols-2">
        <div>
          <Label htmlFor="c-name">{t.name}</Label>
          <Input
            id="c-name"
            autoComplete="name"
            value={values.name}
            onChange={(e) => set("name", e.target.value)}
            maxLength={80}
            aria-invalid={Boolean(errors.name)}
          />
          <FieldError message={msg(errors.name)} />
        </div>
        <div>
          <Label htmlFor="c-phone">{t.phoneField}</Label>
          <Input
            id="c-phone"
            type="tel"
            autoComplete="tel"
            value={values.phone}
            onChange={(e) => set("phone", e.target.value)}
            placeholder={dict.order.phonePlaceholder}
            maxLength={25}
            aria-invalid={Boolean(errors.phone)}
          />
          <FieldError message={msg(errors.phone)} />
        </div>
        <div className="sm:col-span-2">
          <Label htmlFor="c-message">{t.message}</Label>
          <Textarea
            id="c-message"
            value={values.message}
            onChange={(e) => set("message", e.target.value)}
            placeholder={t.messagePlaceholder}
            maxLength={2000}
            aria-invalid={Boolean(errors.message)}
          />
          <FieldError message={msg(errors.message)} />
        </div>
      </div>
      <input
        type="text"
        tabIndex={-1}
        autoComplete="off"
        value={values.website}
        onChange={(e) => set("website", e.target.value)}
        className="absolute -left-[9999px] h-0 w-0 opacity-0"
        aria-hidden
      />
      {errors.form && (
        <p role="alert" className="mt-5 rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger">
          {errors.form}
        </p>
      )}
      <Button type="submit" className="mt-6 w-full sm:w-auto" disabled={status === "submitting"}>
        {status === "submitting" ? (
          <>
            <Spinner /> {t.submitting}
          </>
        ) : (
          <>
            <Send /> {t.submit}
          </>
        )}
      </Button>
    </form>
  );
}
