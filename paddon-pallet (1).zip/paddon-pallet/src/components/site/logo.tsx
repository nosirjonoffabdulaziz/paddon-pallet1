import Link from "next/link";
import { cn } from "@/lib/utils";

/** PALLET logotipi: yuqoridan ko‘rilgan pallet taxtalari belgisi + so‘z belgisi. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("size-9", className)} aria-hidden>
      <rect width="40" height="40" rx="11" fill="#17211d" />
      <g fill="#a77948">
        <rect x="9" y="10" width="22" height="3.6" rx="1" />
        <rect x="9" y="16" width="22" height="3.6" rx="1" />
        <rect x="9" y="22" width="22" height="3.6" rx="1" />
      </g>
      <g fill="#e9dcc8">
        <rect x="9" y="27.5" width="5" height="3.5" rx="0.8" />
        <rect x="17.5" y="27.5" width="5" height="3.5" rx="0.8" />
        <rect x="26" y="27.5" width="5" height="3.5" rx="0.8" />
      </g>
    </svg>
  );
}

export function Logo({
  href,
  brand,
  sub,
  className,
  inverted = false,
}: {
  href: string;
  brand: string;
  sub: string;
  className?: string;
  inverted?: boolean;
}) {
  return (
    <Link href={href} className={cn("group inline-flex items-center gap-3", className)} aria-label={brand}>
      <LogoMark className="transition-transform duration-300 group-hover:-rotate-6" />
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-display text-[19px] font-extrabold tracking-[0.18em]",
            inverted ? "text-white" : "text-ink",
          )}
        >
          {brand}
        </span>
        <span
          className={cn(
            "mt-1 text-[10px] font-semibold tracking-[0.32em]",
            inverted ? "text-white/50" : "text-muted",
          )}
        >
          {sub}
        </span>
      </span>
    </Link>
  );
}
