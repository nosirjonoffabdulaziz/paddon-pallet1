"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, Phone, X } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import type { Locale } from "@/lib/i18n";
import { cn, phoneHref } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { LanguageSwitcher } from "./language-switcher";
import { Logo } from "./logo";

type Props = {
  locale: Locale;
  dict: Pick<Dictionary, "nav" | "header" | "meta">;
  phone: string;
};

export function Header({ locale, dict, phone }: Props) {
  const pathname = usePathname() ?? "";
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const base = `/${locale}`;
  const links = [
    { href: base, label: dict.nav.home },
    { href: `${base}/products`, label: dict.nav.products },
    { href: `${base}/sizes`, label: dict.nav.sizes },
    { href: `${base}/about`, label: dict.nav.about },
    { href: `${base}/order`, label: dict.nav.order },
    { href: `${base}/contact`, label: dict.nav.contact },
  ];
  const isActive = (href: string) => (href === base ? pathname === base : pathname.startsWith(href));
  const callHref = phone ? phoneHref(phone) : `${base}/contact`;

  return (
    <header
      className={cn(
        "sticky top-0 z-40 transition-all duration-300",
        scrolled || open
          ? "border-b border-line/80 bg-bg/85 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <div className="container-page flex h-[72px] items-center justify-between gap-6">
        <Logo href={base} brand={dict.meta.brand} sub={dict.meta.brandSub} />

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "relative rounded-full px-3.5 py-2 text-sm font-medium transition-colors",
                isActive(link.href) ? "text-ink" : "text-muted hover:text-ink",
              )}
            >
              {link.label}
              {isActive(link.href) && (
                <motion.span
                  layoutId="nav-active"
                  className="absolute inset-x-3.5 -bottom-0.5 h-px bg-wood"
                  transition={{ type: "spring", stiffness: 400, damping: 34 }}
                />
              )}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Suspense fallback={null}>
            <LanguageSwitcher current={locale} label={dict.header.language} className="hidden sm:flex" />
          </Suspense>
          <a
            href={callHref}
            className="hidden size-10 place-items-center rounded-full border border-line bg-card text-ink transition hover:border-wood hover:text-wood-dark md:grid xl:hidden"
            aria-label={dict.header.call}
          >
            <Phone className="size-4" />
          </a>
          {phone && (
            <a
              href={callHref}
              className="hidden items-center gap-2 px-2 text-sm font-semibold text-ink transition hover:text-wood-dark xl:inline-flex"
            >
              <Phone className="size-4 text-wood" />
              {phone}
            </a>
          )}
          <Button asChild size="sm" className="hidden md:inline-flex">
            <Link href={`${base}/order`}>{dict.header.orderCta}</Link>
          </Button>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="grid size-10 place-items-center rounded-full border border-line bg-card lg:hidden"
            aria-label={open ? dict.nav.closeMenu : dict.nav.openMenu}
            aria-expanded={open}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden border-t border-line lg:hidden"
          >
            <div className="container-page flex max-h-[calc(100dvh-72px)] flex-col gap-1 overflow-y-auto py-6">
              {links.map((link, i) => (
                <motion.div
                  key={link.href}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.03 * i }}
                >
                  <Link
                    href={link.href}
                    className={cn(
                      "flex items-center justify-between rounded-2xl px-4 py-3.5 font-display text-lg font-semibold",
                      isActive(link.href) ? "bg-card text-ink shadow-soft" : "text-ink/80",
                    )}
                  >
                    {link.label}
                    <span className="text-xs text-muted">0{i + 1}</span>
                  </Link>
                </motion.div>
              ))}
              <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-line pt-5">
                <Suspense fallback={null}>
                  <LanguageSwitcher current={locale} label={dict.header.language} />
                </Suspense>
                <Button asChild variant="outline" size="sm">
                  <a href={callHref}>
                    <Phone /> {phone || dict.header.call}
                  </a>
                </Button>
                <Button asChild size="sm" className="flex-1 sm:flex-none">
                  <Link href={`${base}/order`}>{dict.header.orderCta}</Link>
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
