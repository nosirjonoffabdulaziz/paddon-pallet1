"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState, useTransition, type ReactNode } from "react";
import { Search, SlidersHorizontal, X } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries/uz";
import {
  AVAILABILITIES,
  CAPACITY_STEPS,
  CONDITIONS,
  type MaterialValue,
} from "@/lib/catalog-options";
import { cn, format, formatNumber } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input, Select } from "@/components/ui/input";
import { Spinner } from "./states";

export type Facets = {
  sizes: { key: string; label: string }[];
  hasCustom: boolean;
  materials: MaterialValue[];
  hasCapacity: boolean;
  priceRange: { min: number; max: number } | null;
};

type Props = {
  dict: Pick<Dictionary, "products" | "labels" | "common">;
  facets: Facets;
  count: number;
  children: ReactNode;
};

const FILTER_KEYS = ["q", "size", "type", "condition", "material", "capacity", "min", "max", "availability", "sort"];

export function CatalogShell({ dict, facets, count, children }: Props) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [pending, startTransition] = useTransition();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [q, setQ] = useState(params.get("q") ?? "");
  const t = dict.products;

  const update = (changes: Record<string, string | null>) => {
    const next = new URLSearchParams(params.toString());
    for (const [key, value] of Object.entries(changes)) {
      if (value === null || value === "") next.delete(key);
      else next.set(key, value);
    }
    const qs = next.toString();
    if (qs === params.toString()) return;
    startTransition(() => router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false }));
  };

  // Qidiruv — yozib bo‘lgandan 350 ms keyin
  useEffect(() => {
    const current = params.get("q") ?? "";
    if (q === current) return;
    const id = setTimeout(() => update({ q: q.trim() || null }), 350);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const materials = (params.get("material") ?? "").split(",").filter(Boolean);
  const toggleMaterial = (m: string) => {
    const set = new Set(materials);
    if (set.has(m)) set.delete(m);
    else set.add(m);
    update({ material: [...set].join(",") || null });
  };

  const activeCount = FILTER_KEYS.filter((k) => k !== "sort" && k !== "q" && params.get(k)).length;
  const reset = () => {
    setQ("");
    startTransition(() => router.replace(pathname, { scroll: false }));
  };

  const chip = (active: boolean) =>
    cn(
      "rounded-full border px-3.5 py-2 text-sm font-medium transition-colors",
      active ? "border-ink bg-ink text-white" : "border-line bg-card text-ink hover:border-ink/30",
    );

  const filters = (
    <div className="space-y-7">
      <FilterGroup title={t.size}>
        <div className="flex flex-wrap gap-2">
          <button type="button" className={chip(!params.get("size"))} onClick={() => update({ size: null })}>
            {t.allSizes}
          </button>
          {facets.sizes.map((s) => (
            <button
              key={s.key}
              type="button"
              className={chip(params.get("size") === s.key)}
              onClick={() => update({ size: params.get("size") === s.key ? null : s.key })}
            >
              {s.label}
            </button>
          ))}
          {facets.hasCustom && (
            <button
              type="button"
              className={chip(params.get("size") === "custom")}
              onClick={() => update({ size: params.get("size") === "custom" ? null : "custom" })}
            >
              {dict.common.individualSize}
            </button>
          )}
        </div>
      </FilterGroup>

      <FilterGroup title={t.sizeType}>
        <Segmented
          value={params.get("type") ?? ""}
          onChange={(v) => update({ type: v || null })}
          options={[
            { value: "", label: t.any },
            { value: "standard", label: dict.common.standard },
            { value: "custom", label: dict.common.custom },
          ]}
        />
      </FilterGroup>

      <FilterGroup title={t.condition}>
        <Segmented
          value={params.get("condition") ?? ""}
          onChange={(v) => update({ condition: v || null })}
          options={[
            { value: "", label: t.any },
            ...CONDITIONS.map((c) => ({ value: c, label: dict.labels.condition[c] })),
          ]}
        />
      </FilterGroup>

      {facets.materials.length > 0 && (
        <FilterGroup title={t.material}>
          <div className="space-y-2">
            {facets.materials.map((m) => (
              <label key={m} className="flex cursor-pointer items-center gap-3 text-sm">
                <input
                  type="checkbox"
                  checked={materials.includes(m)}
                  onChange={() => toggleMaterial(m)}
                  className="size-4 rounded accent-[#a77948]"
                />
                {dict.labels.material[m]}
              </label>
            ))}
          </div>
        </FilterGroup>
      )}

      {facets.hasCapacity && (
        <FilterGroup title={t.capacity}>
          <Select value={params.get("capacity") ?? ""} onChange={(e) => update({ capacity: e.target.value || null })}>
            <option value="">{t.any}</option>
            {CAPACITY_STEPS.map((kg) => (
              <option key={kg} value={kg}>
                {format(t.capacityFrom, { kg: formatNumber(kg) })}
              </option>
            ))}
          </Select>
        </FilterGroup>
      )}

      {facets.priceRange && (
        <FilterGroup title={t.price}>
          <PriceRange
            key={`${params.get("min")}-${params.get("max")}`}
            min={params.get("min") ?? ""}
            max={params.get("max") ?? ""}
            placeholderMin={`${t.priceFrom} ${formatNumber(facets.priceRange.min)}`}
            placeholderMax={`${t.priceTo} ${formatNumber(facets.priceRange.max)}`}
            onApply={(min, max) => update({ min: min || null, max: max || null })}
          />
        </FilterGroup>
      )}

      <FilterGroup title={t.availability}>
        <Select
          value={params.get("availability") ?? ""}
          onChange={(e) => update({ availability: e.target.value || null })}
        >
          <option value="">{t.any}</option>
          {AVAILABILITIES.map((a) => (
            <option key={a} value={a}>
              {dict.labels.availability[a]}
            </option>
          ))}
        </Select>
      </FilterGroup>

      {activeCount > 0 && (
        <Button variant="ghost" size="sm" onClick={reset} className="w-full">
          <X /> {t.reset}
        </Button>
      )}
    </div>
  );

  return (
    <div className="grid gap-8 lg:grid-cols-[280px_1fr] lg:gap-10">
      {/* Desktop filtrlar */}
      <aside className="hidden lg:block">
        <div className="sticky top-24 rounded-3xl border border-line bg-card p-6 shadow-soft">
          <h2 className="mb-6 flex items-center gap-2 font-display text-lg font-bold">
            <SlidersHorizontal className="size-4 text-wood" /> {t.filters}
          </h2>
          {filters}
        </div>
      </aside>

      <div className="min-w-0">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted" />
            <Input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="pl-11"
              aria-label={t.searchPlaceholder}
              maxLength={80}
            />
          </div>
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              className="h-12 flex-1 lg:hidden"
              onClick={() => setMobileOpen((v) => !v)}
              aria-expanded={mobileOpen}
            >
              <SlidersHorizontal /> {mobileOpen ? t.hideFilters : t.showFilters}
              {activeCount > 0 && (
                <span className="grid size-5 place-items-center rounded-full bg-wood text-[11px] text-white">
                  {activeCount}
                </span>
              )}
            </Button>
            <Select
              value={params.get("sort") ?? "default"}
              onChange={(e) => update({ sort: e.target.value === "default" ? null : e.target.value })}
              aria-label={t.sort}
              className="sm:w-56"
            >
              <option value="default">{t.sortDefault}</option>
              <option value="price_asc">{t.sortPriceAsc}</option>
              <option value="price_desc">{t.sortPriceDesc}</option>
              <option value="size_asc">{t.sortSizeAsc}</option>
              <option value="size_desc">{t.sortSizeDesc}</option>
            </Select>
          </div>
        </div>

        {mobileOpen && (
          <div className="mt-4 rounded-3xl border border-line bg-card p-5 shadow-soft lg:hidden">{filters}</div>
        )}

        <div className="mt-6 flex items-center justify-between text-sm text-muted">
          <span aria-live="polite">{format(t.found, { count })}</span>
          {pending && (
            <span className="inline-flex items-center gap-2 text-wood-dark">
              <Spinner /> {dict.common.loading}
            </span>
          )}
        </div>

        <div
          className={cn("mt-5 transition-opacity duration-200", pending && "pointer-events-none opacity-50")}
          aria-busy={pending}
        >
          {children}
        </div>
      </div>
    </div>
  );
}

function FilterGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <fieldset>
      <legend className="mb-3 text-xs font-semibold uppercase tracking-[0.12em] text-muted">{title}</legend>
      {children}
    </fieldset>
  );
}

function Segmented({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="flex rounded-full border border-line bg-sand/60 p-1">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "flex-1 rounded-full px-2 py-1.5 text-xs font-semibold transition",
            value === o.value ? "bg-card text-ink shadow-soft" : "text-muted hover:text-ink",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function PriceRange({
  min,
  max,
  placeholderMin,
  placeholderMax,
  onApply,
}: {
  min: string;
  max: string;
  placeholderMin: string;
  placeholderMax: string;
  onApply: (min: string, max: string) => void;
}) {
  const [lo, setLo] = useState(min);
  const [hi, setHi] = useState(max);
  const clean = (v: string) => v.replace(/\D/g, "");
  return (
    <form
      className="grid grid-cols-2 gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        onApply(clean(lo), clean(hi));
      }}
    >
      <Input
        inputMode="numeric"
        value={lo}
        onChange={(e) => setLo(clean(e.target.value))}
        onBlur={() => onApply(clean(lo), clean(hi))}
        placeholder={placeholderMin}
        className="h-11 px-3 text-sm"
      />
      <Input
        inputMode="numeric"
        value={hi}
        onChange={(e) => setHi(clean(e.target.value))}
        onBlur={() => onApply(clean(lo), clean(hi))}
        placeholder={placeholderMax}
        className="h-11 px-3 text-sm"
      />
    </form>
  );
}
