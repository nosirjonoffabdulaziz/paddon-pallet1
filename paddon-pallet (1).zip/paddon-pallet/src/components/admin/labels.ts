import type { OrderStatusValue } from "@/lib/catalog-options";
import uz from "@/i18n/dictionaries/uz";

export const ORDER_STATUS_LABELS: Record<OrderStatusValue, string> = {
  NEW: "Yangi",
  CONFIRMED: "Tasdiqlangan",
  IN_PRODUCTION: "Ishlab chiqarishda",
  DELIVERED: "Yetkazildi",
  CANCELLED: "Bekor qilindi",
};

export function orderStatusVariant(status: OrderStatusValue) {
  switch (status) {
    case "NEW":
      return "wood" as const;
    case "CONFIRMED":
      return "warning" as const;
    case "IN_PRODUCTION":
      return "default" as const;
    case "DELIVERED":
      return "success" as const;
    default:
      return "danger" as const;
  }
}

export const MATERIAL_LABELS = uz.labels.material;
export const CONDITION_LABELS = uz.labels.condition;
export const AVAILABILITY_LABELS = uz.labels.availability;

export function formatDate(date: Date) {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Tashkent",
  }).format(date);
}
