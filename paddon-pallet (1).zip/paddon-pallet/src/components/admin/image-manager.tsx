"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useRef, useState, useTransition } from "react";
import { ArrowDown, ArrowUp, ImagePlus, Loader2 } from "lucide-react";
import { deleteProductImageAction, moveProductImageAction } from "@/actions/admin";
import { Button } from "@/components/ui/button";
import { ConfirmButton } from "./ui";

const MAX_BYTES = 4 * 1024 * 1024;
const TYPES = ["image/jpeg", "image/png", "image/webp", "image/avif"];

export function ImageManager({
  productId,
  images,
}: {
  productId: string;
  images: { id: string; url: string; alt: string }[];
}) {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setError(null);
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        if (!TYPES.includes(file.type)) throw new Error(`${file.name}: faqat JPG, PNG, WEBP yoki AVIF.`);
        if (file.size > MAX_BYTES) throw new Error(`${file.name}: hajmi 4 MB dan katta.`);
        const body = new FormData();
        body.set("file", file);
        body.set("target", "product");
        body.set("productId", productId);
        const res = await fetch("/api/admin/upload", { method: "POST", body });
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        if (!res.ok) throw new Error(data.error ?? "Yuklashda xatolik.");
      }
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Yuklashda xatolik.");
    } finally {
      setUploading(false);
      if (input.current) input.current.value = "";
    }
  }

  return (
    <div>
      {images.length === 0 ? (
        <p className="rounded-xl border border-dashed border-line px-4 py-8 text-center text-sm text-muted">
          Rasm yo‘q. Saytda shu mahsulot uchun o‘lchamga mos vizual model ko‘rsatiladi.
        </p>
      ) : (
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {images.map((img, i) => (
            <li key={img.id} className="overflow-hidden rounded-xl border border-line bg-white">
              <div className="relative aspect-[4/3]">
                <Image src={img.url} alt={img.alt} fill sizes="200px" className="object-contain p-2" />
                {i === 0 && (
                  <span className="absolute left-2 top-2 rounded-full bg-ink px-2 py-0.5 text-[10px] font-semibold text-white">
                    Asosiy
                  </span>
                )}
              </div>
              <div className="flex items-center justify-between border-t border-line px-1.5 py-1">
                <div className="flex">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    disabled={i === 0 || pending}
                    onClick={() => start(() => moveProductImageAction(img.id, "up"))}
                    title="Oldinga"
                  >
                    <ArrowUp />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    disabled={i === images.length - 1 || pending}
                    onClick={() => start(() => moveProductImageAction(img.id, "down"))}
                    title="Orqaga"
                  >
                    <ArrowDown />
                  </Button>
                </div>
                <ConfirmButton
                  action={() => deleteProductImageAction(img.id)}
                  confirmText="Rasmni o‘chirasizmi?"
                  size="icon"
                  className="size-8"
                  title="O‘chirish"
                />
              </div>
            </li>
          ))}
        </ul>
      )}

      <input
        ref={input}
        type="file"
        accept={TYPES.join(",")}
        multiple
        className="hidden"
        onChange={(e) => upload(e.target.files)}
      />
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <Button type="button" variant="outline" onClick={() => input.current?.click()} disabled={uploading}>
          {uploading ? <Loader2 className="animate-spin" /> : <ImagePlus />}
          {uploading ? "Yuklanmoqda…" : "Rasm yuklash"}
        </Button>
        <span className="text-xs text-muted">JPG, PNG, WEBP · 4 MB gacha · oq fonli studiya rasmlari tavsiya etiladi</span>
      </div>
      {error && <p className="mt-3 rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger">{error}</p>}
    </div>
  );
}
