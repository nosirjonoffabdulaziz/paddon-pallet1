"use client";

import { useState, useTransition } from "react";
import { Check, Loader2 } from "lucide-react";
import { updateOrderNoteAction, updateOrderStatusAction } from "@/actions/admin";
import { ORDER_STATUSES, type OrderStatusValue } from "@/lib/catalog-options";
import { Button } from "@/components/ui/button";
import { ORDER_STATUS_LABELS } from "./labels";

export function OrderStatusSelect({ id, status }: { id: string; status: OrderStatusValue }) {
  const [pending, start] = useTransition();
  const [value, setValue] = useState(status);
  return (
    <div className="relative">
      <select
        value={value}
        disabled={pending}
        onChange={(e) => {
          const next = e.target.value as OrderStatusValue;
          setValue(next);
          start(() => updateOrderStatusAction(id, next));
        }}
        className="h-9 cursor-pointer appearance-none rounded-full border border-line bg-card pl-3.5 pr-9 text-sm font-medium outline-none focus:border-wood"
        aria-label="Status"
      >
        {ORDER_STATUSES.map((s) => (
          <option key={s} value={s}>
            {ORDER_STATUS_LABELS[s]}
          </option>
        ))}
      </select>
      <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted">
        {pending ? <Loader2 className="size-3.5 animate-spin" /> : "▾"}
      </span>
    </div>
  );
}

export function OrderNote({ id, note }: { id: string; note: string }) {
  const [value, setValue] = useState(note);
  const [saved, setSaved] = useState(false);
  const [pending, start] = useTransition();
  const dirty = value !== note;
  return (
    <div className="mt-3 flex gap-2">
      <input
        value={value}
        onChange={(e) => {
          setValue(e.target.value);
          setSaved(false);
        }}
        placeholder="Admin izohi (faqat sizga ko‘rinadi)…"
        maxLength={2000}
        className="h-9 flex-1 rounded-full border border-line bg-bg px-4 text-sm outline-none focus:border-wood"
      />
      {(dirty || saved) && (
        <Button
          type="button"
          size="sm"
          variant={saved ? "ghost" : "default"}
          disabled={pending || saved}
          onClick={() =>
            start(async () => {
              await updateOrderNoteAction(id, value);
              setSaved(true);
            })
          }
        >
          {pending ? <Loader2 className="animate-spin" /> : saved ? <Check /> : "Saqlash"}
        </Button>
      )}
    </div>
  );
}
