"use client";

import { useFormStatus } from "react-dom";
import { startTransition, useActionState, useTransition, type FormEvent, type ReactNode } from "react";
import { Loader2, Trash2 } from "lucide-react";
import { Button, type ButtonProps } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { ActionState } from "@/actions/admin";

/**
 * Server action'ni formaga ulaydi. React 19 formani avtomatik tozalamasligi uchun
 * onSubmit orqali chaqiriladi — xatolik bo‘lsa, kiritilgan qiymatlar saqlanib qoladi.
 */
export function useFormAction(fn: (prev: ActionState, formData: FormData) => Promise<ActionState>) {
  const [state, dispatch, pending] = useActionState<ActionState, FormData>(fn, {});
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    startTransition(() => dispatch(data));
  };
  return { state, pending, onSubmit };
}

export function SubmitButton({
  children,
  pendingText = "Saqlanmoqda…",
  pending: pendingProp,
  ...props
}: ButtonProps & { pendingText?: string; pending?: boolean }) {
  const status = useFormStatus();
  const pending = pendingProp ?? status.pending;
  return (
    <Button type="submit" {...props} disabled={pending || props.disabled}>
      {pending ? (
        <>
          <Loader2 className="animate-spin" /> {pendingText}
        </>
      ) : (
        children
      )}
    </Button>
  );
}

export function FormMessage({ state }: { state: ActionState }) {
  if (state.error)
    return (
      <p role="alert" className="rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger">
        {state.error}
      </p>
    );
  if (state.ok && state.message)
    return (
      <p role="status" className="rounded-xl bg-success/10 px-4 py-3 text-sm text-success">
        {state.message}
      </p>
    );
  return null;
}

/** Tasdiqlash so‘raydigan amal tugmasi (o‘chirish va h.k.) */
export function ConfirmButton({
  action,
  confirmText = "Haqiqatan ham o‘chirmoqchimisiz?",
  children,
  className,
  variant = "ghost",
  size = "sm",
  title,
}: {
  action: () => Promise<unknown>;
  confirmText?: string;
  children?: ReactNode;
  className?: string;
  variant?: ButtonProps["variant"];
  size?: ButtonProps["size"];
  title?: string;
}) {
  const [pending, start] = useTransition();
  return (
    <Button
      type="button"
      variant={variant}
      size={size}
      title={title}
      disabled={pending}
      className={cn(variant === "ghost" && "text-danger hover:bg-danger/10", className)}
      onClick={() => {
        if (confirmText && !window.confirm(confirmText)) return;
        start(async () => {
          await action();
        });
      }}
    >
      {pending ? <Loader2 className="animate-spin" /> : (children ?? <Trash2 />)}
    </Button>
  );
}

export function AdminCard({ title, description, children, className, actions }: {
  title?: string;
  description?: string;
  children: ReactNode;
  className?: string;
  actions?: ReactNode;
}) {
  return (
    <section className={cn("rounded-2xl border border-line bg-card p-5 shadow-soft sm:p-6", className)}>
      {(title || actions) && (
        <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
          <div>
            {title && <h2 className="font-display text-lg font-bold">{title}</h2>}
            {description && <p className="mt-1 text-sm text-muted">{description}</p>}
          </div>
          {actions}
        </div>
      )}
      {children}
    </section>
  );
}
