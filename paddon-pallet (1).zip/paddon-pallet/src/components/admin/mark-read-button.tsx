"use client";

import { useTransition } from "react";
import { Loader2, MailCheck, MailOpen } from "lucide-react";
import { toggleMessageReadAction } from "@/actions/admin";
import { Button } from "@/components/ui/button";

export function MarkReadButton({ id, isRead }: { id: string; isRead: boolean }) {
  const [pending, start] = useTransition();
  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      disabled={pending}
      onClick={() => start(() => toggleMessageReadAction(id, !isRead))}
    >
      {pending ? <Loader2 className="animate-spin" /> : isRead ? <MailOpen /> : <MailCheck />}
      {isRead ? "O‘qilmagan" : "O‘qildi"}
    </Button>
  );
}
