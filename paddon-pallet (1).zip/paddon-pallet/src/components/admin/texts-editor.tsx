"use client";

import { useMemo, useState } from "react";
import { RotateCcw, Save, Search } from "lucide-react";
import { resetTextAction, saveTextsAction } from "@/actions/admin";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ConfirmButton, FormMessage, SubmitButton, useFormAction } from "./ui";

type Lang = "uz" | "ru" | "en";
export type TextItem = {
  key: string;
  defaults: Record<Lang, string>;
  values: Record<Lang, string>;
  overridden: boolean;
};
export type TextGroup = { id: string; label: string; items: TextItem[] };

const LANGS: { code: Lang; label: string }[] = [
  { code: "uz", label: "UZ" },
  { code: "ru", label: "RU" },
  { code: "en", label: "EN" },
];

export function TextsEditor({ groups }: { groups: TextGroup[] }) {
  const [active, setActive] = useState(groups.find((g) => g.id === "hero")?.id ?? groups[0]?.id ?? "");
  const [query, setQuery] = useState("");
  const { state, pending, onSubmit } = useFormAction(saveTextsAction);

  const q = query.trim().toLowerCase();
  const visible = useMemo(() => {
    if (!q) return groups.filter((g) => g.id === active);
    return groups
      .map((g) => ({
        ...g,
        items: g.items.filter(
          (i) => i.key.toLowerCase().includes(q) || Object.values(i.values).some((v) => v.toLowerCase().includes(q)),
        ),
      }))
      .filter((g) => g.items.length > 0);
  }, [groups, active, q]);

  return (
    <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
      <aside className="lg:sticky lg:top-6 lg:self-start">
        <div className="relative mb-3">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Matn qidirish…"
            className="h-10 pl-9 text-sm"
          />
        </div>
        <nav className="flex gap-1 overflow-x-auto pb-1 lg:flex-col">
          {groups.map((g) => {
            const changed = g.items.filter((i) => i.overridden).length;
            return (
              <button
                key={g.id}
                type="button"
                onClick={() => {
                  setActive(g.id);
                  setQuery("");
                }}
                className={cn(
                  "flex shrink-0 items-center justify-between gap-2 rounded-xl px-3 py-2 text-left text-sm transition",
                  active === g.id && !q ? "bg-ink text-white" : "hover:bg-sand",
                )}
              >
                <span className="whitespace-nowrap">{g.label}</span>
                {changed > 0 && (
                  <span className={cn("text-[10px] font-bold", active === g.id && !q ? "text-white/70" : "text-wood-dark")}>
                    {changed}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </aside>

      <form onSubmit={onSubmit} key={visible.map((g) => g.id).join(",") + q}>
        {visible.length === 0 && <p className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">Hech narsa topilmadi.</p>}
        <div className="space-y-6">
          {visible.map((group) => (
            <section key={group.id} className="rounded-2xl border border-line bg-card shadow-soft">
              <h2 className="border-b border-line px-5 py-4 font-display font-bold">{group.label}</h2>
              <div className="divide-y divide-line">
                {group.items.map((item) => (
                  <TextRow key={item.key} item={item} />
                ))}
              </div>
            </section>
          ))}
        </div>
        {visible.length > 0 && (
          <div className="sticky bottom-4 mt-6 flex flex-wrap items-center gap-3 rounded-2xl border border-line bg-card/95 p-3 shadow-lift backdrop-blur">
            <SubmitButton pending={pending}>
              <Save /> O‘zgarishlarni saqlash
            </SubmitButton>
            <div className="min-w-0 flex-1">
              <FormMessage state={state} />
            </div>
          </div>
        )}
      </form>
    </div>
  );
}

function TextRow({ item }: { item: TextItem }) {
  const long = Math.max(...Object.values(item.defaults).map((v) => v.length)) > 70;
  return (
    <div className="px-5 py-4">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <code className="rounded bg-sand px-1.5 py-0.5 text-[11px] text-muted">{item.key}</code>
        {item.overridden && (
          <>
            <Badge variant="wood">O‘zgartirilgan</Badge>
            <ConfirmButton
              action={() => resetTextAction(item.key)}
              confirmText="Standart matnga qaytarilsinmi?"
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-xs text-muted hover:bg-sand"
              title="Standartga qaytarish"
            >
              <RotateCcw className="size-3.5" /> Standart
            </ConfirmButton>
          </>
        )}
      </div>
      <div className="grid gap-2 md:grid-cols-3">
        {LANGS.map(({ code, label }) => (
          <label key={code} className="block">
            <span className="mb-1 block text-[11px] font-semibold text-muted">{label}</span>
            {long ? (
              <textarea
                name={`t|${item.key}|${code}`}
                defaultValue={item.values[code]}
                rows={3}
                maxLength={3000}
                className="w-full rounded-lg border border-line bg-bg px-3 py-2 text-sm leading-relaxed outline-none focus:border-wood focus:bg-white"
              />
            ) : (
              <input
                name={`t|${item.key}|${code}`}
                defaultValue={item.values[code]}
                maxLength={3000}
                className="h-10 w-full rounded-lg border border-line bg-bg px-3 text-sm outline-none focus:border-wood focus:bg-white"
              />
            )}
          </label>
        ))}
      </div>
    </div>
  );
}
