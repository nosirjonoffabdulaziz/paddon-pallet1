"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ExternalLink,
  LayoutDashboard,
  LogOut,
  Mail,
  Package,
  Settings,
  ShoppingCart,
  Type,
} from "lucide-react";
import { logoutAction } from "@/actions/admin";
import { cn } from "@/lib/utils";
import { LogoMark } from "@/components/site/logo";

const items = [
  { href: "/admin", label: "Boshqaruv", icon: LayoutDashboard },
  { href: "/admin/products", label: "Mahsulotlar", icon: Package },
  { href: "/admin/orders", label: "Buyurtmalar", icon: ShoppingCart, badge: "orders" as const },
  { href: "/admin/messages", label: "Xabarlar", icon: Mail, badge: "messages" as const },
  { href: "/admin/texts", label: "Sayt matnlari", icon: Type },
  { href: "/admin/settings", label: "Sozlamalar", icon: Settings },
];

export function AdminSidebar({ email, counts }: { email: string; counts: { orders: number; messages: number } }) {
  const pathname = usePathname() ?? "";
  const active = (href: string) => (href === "/admin" ? pathname === "/admin" : pathname.startsWith(href));

  return (
    <aside className="border-b border-line bg-card lg:fixed lg:inset-y-0 lg:left-0 lg:w-64 lg:border-b-0 lg:border-r">
      <div className="flex h-full flex-col">
        <div className="flex items-center justify-between gap-3 px-5 py-4 lg:py-6">
          <Link href="/admin" className="flex items-center gap-3">
            <LogoMark />
            <span className="leading-tight">
              <span className="block font-display text-sm font-extrabold tracking-[0.16em]">PALLET</span>
              <span className="block text-[11px] text-muted">Admin panel</span>
            </span>
          </Link>
          <Link
            href="/uz"
            target="_blank"
            className="inline-flex items-center gap-1 text-xs font-medium text-muted hover:text-ink lg:hidden"
          >
            Sayt <ExternalLink className="size-3" />
          </Link>
        </div>

        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-1 lg:flex-col lg:overflow-visible lg:pb-0">
          {items.map((item) => {
            const Icon = item.icon;
            const count = item.badge ? counts[item.badge] : 0;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex shrink-0 items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
                  active(item.href) ? "bg-ink text-white" : "text-ink/75 hover:bg-sand hover:text-ink",
                )}
              >
                <Icon className="size-4" />
                <span className="whitespace-nowrap">{item.label}</span>
                {count > 0 && (
                  <span
                    className={cn(
                      "ml-auto rounded-full px-1.5 py-0.5 text-[10px] font-bold",
                      active(item.href) ? "bg-white/20" : "bg-wood text-white",
                    )}
                  >
                    {count}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="hidden border-t border-line p-4 lg:block">
          <Link
            href="/uz"
            target="_blank"
            className="mb-3 flex items-center gap-2 rounded-xl px-3 py-2 text-sm text-muted hover:bg-sand hover:text-ink"
          >
            <ExternalLink className="size-4" /> Saytni ochish
          </Link>
          <p className="truncate px-3 text-xs text-muted" title={email}>
            {email}
          </p>
          <form action={logoutAction}>
            <button
              type="submit"
              className="mt-2 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-danger hover:bg-danger/10"
            >
              <LogOut className="size-4" /> Chiqish
            </button>
          </form>
        </div>
      </div>
    </aside>
  );
}
