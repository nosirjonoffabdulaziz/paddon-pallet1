"use client";

import { useActionState } from "react";
import { LogIn } from "lucide-react";
import { loginAction, type ActionState } from "@/actions/admin";
import { Input, Label } from "@/components/ui/input";
import { FormMessage, SubmitButton } from "./ui";

export function LoginForm() {
  const [state, action] = useActionState<ActionState, FormData>(loginAction, {});
  return (
    <form action={action} className="space-y-5 rounded-3xl border border-line bg-card p-7 shadow-lift">
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" name="email" type="email" autoComplete="username" required autoFocus />
      </div>
      <div>
        <Label htmlFor="password">Parol</Label>
        <Input id="password" name="password" type="password" autoComplete="current-password" required />
      </div>
      <FormMessage state={state} />
      <SubmitButton className="w-full" pendingText="Tekshirilmoqda…">
        <LogIn /> Kirish
      </SubmitButton>
    </form>
  );
}
