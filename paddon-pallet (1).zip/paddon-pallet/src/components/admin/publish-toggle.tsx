"use client";

import { useOptimistic, useTransition } from "react";
import { toggleProductPublishedAction } from "@/actions/admin";
import { cn } from "@/lib/utils";

export function PublishToggle({ id, published }: { id: string; published: boolean }) {
  const [pending, start] = useTransition();
  const [value, setValue] = useOptimistic(published);
  return (
    <button
      type="button"
      role="switch"
      aria-checked={value}
      disabled={pending}
      title={value ? "Saytda ko‘rinadi" : "Saytda yashirin"}
      onClick={() =>
        start(async () => {
          setValue(!value);
          await toggleProductPublishedAction(id, !value);
        })
      }
      className={cn(
        "relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-60",
        value ? "bg-success" : "bg-line",
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 size-5 rounded-full bg-white shadow transition-all",
          value ? "left-[22px]" : "left-0.5",
        )}
      />
      <span className="sr-only">{value ? "Saytda ko‘rinadi" : "Saytda yashirin"}</span>
    </button>
  );
}
