"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useRef, useState, useTransition } from "react";
import { ImagePlus, KeyRound, Loader2, RotateCcw, Save, Send } from "lucide-react";
import {
  changePasswordAction,
  resetSiteImageAction,
  saveSettingsAction,
  sendTestTelegramAction,
  type ActionState,
} from "@/actions/admin";
import type { Settings } from "@/lib/settings";
import { Button } from "@/components/ui/button";
import { FieldError, Input, Label, Textarea } from "@/components/ui/input";
import { AdminCard, ConfirmButton, FormMessage, SubmitButton, useFormAction } from "./ui";

export function ContactSettingsForm({ initial }: { initial: Settings }) {
  const { state, pending, onSubmit } = useFormAction(saveSettingsAction);
  const err = (k: string) => state.fields?.[k];

  const field = (name: keyof Settings, label: string, placeholder = "", hint?: string) => (
    <div>
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} defaultValue={initial[name]} placeholder={placeholder} aria-invalid={Boolean(err(name))} />
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
      <FieldError message={err(name)} />
    </div>
  );
  const textarea = (name: keyof Settings, label: string, placeholder = "") => (
    <div>
      <Label htmlFor={name}>{label}</Label>
      <Textarea id={name} name={name} defaultValue={initial[name]} placeholder={placeholder} rows={2} className="min-h-0" />
    </div>
  );

  return (
    <form onSubmit={onSubmit}>
      <AdminCard title="Kontakt ma’lumotlari" description="Saytning header, footer va “Bog‘lanish” sahifasida ko‘rinadi.">
        <div className="grid gap-5 sm:grid-cols-2">
          {field("phone", "Asosiy telefon", "+998 __ ___ __ __")}
          {field("phone2", "Qo‘shimcha telefon", "ixtiyoriy")}
          {field("telegram", "Telegram", "@username yoki https://t.me/username")}
          {field("email", "Email", "ixtiyoriy")}
        </div>

        <h3 className="mb-3 mt-8 text-sm font-semibold">Manzil</h3>
        <div className="grid gap-5 md:grid-cols-3">
          {textarea("address_uz", "O‘zbekcha", "Shahar, tuman, ko‘cha, uy")}
          {textarea("address_ru", "Русский", "Город, район, улица, дом")}
          {textarea("address_en", "English", "City, district, street")}
        </div>

        <h3 className="mb-3 mt-8 text-sm font-semibold">Ish vaqti</h3>
        <div className="grid gap-5 md:grid-cols-3">
          {textarea("hours_uz", "O‘zbekcha", "Du–Sha: 09:00–18:00")}
          {textarea("hours_ru", "Русский", "Пн–Сб: 09:00–18:00")}
          {textarea("hours_en", "English", "Mon–Sat: 9:00–18:00")}
        </div>

        <div className="mt-8">
          {field(
            "mapEmbedUrl",
            "Google Maps (embed havola)",
            "https://www.google.com/maps/embed?pb=...",
            "Google Maps → Ulashish → Xaritani joylashtirish → HTML kodini nusxalab shu yerga qo‘ying. Bo‘sh qolsa, manzil bo‘yicha xarita ko‘rsatiladi.",
          )}
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-3">
          <SubmitButton pending={pending}>
            <Save /> Saqlash
          </SubmitButton>
          <div className="min-w-0 flex-1">
            <FormMessage state={state} />
          </div>
        </div>
      </AdminCard>
    </form>
  );
}

export function SiteImageField({
  settingKey,
  label,
  url,
  isCustom,
}: {
  settingKey: string;
  label: string;
  url: string;
  isCustom: boolean;
}) {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function upload(file: File | undefined) {
    if (!file) return;
    setError(null);
    if (file.size > 4 * 1024 * 1024) return setError("Rasm hajmi 4 MB dan oshmasin.");
    setUploading(true);
    try {
      const body = new FormData();
      body.set("file", file);
      body.set("target", "setting");
      body.set("key", settingKey);
      const res = await fetch("/api/admin/upload", { method: "POST", body });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error ?? "Yuklashda xatolik.");
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Yuklashda xatolik.");
    } finally {
      setUploading(false);
      if (input.current) input.current.value = "";
    }
  }

  return (
    <div className="overflow-hidden rounded-xl border border-line">
      <div className="relative aspect-[16/9] bg-white">
        <Image src={url} alt={label} fill sizes="400px" className="object-contain" />
      </div>
      <div className="space-y-3 border-t border-line p-4">
        <p className="text-sm font-medium">{label}</p>
        <input
          ref={input}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/avif"
          className="hidden"
          onChange={(e) => upload(e.target.files?.[0])}
        />
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="outline" size="sm" disabled={uploading} onClick={() => input.current?.click()}>
            {uploading ? <Loader2 className="animate-spin" /> : <ImagePlus />} Almashtirish
          </Button>
          {isCustom && (
            <ConfirmButton
              action={() => resetSiteImageAction(settingKey)}
              confirmText="Standart rasm tiklansinmi?"
              variant="ghost"
              className="text-muted hover:bg-sand"
            >
              <RotateCcw /> Standartga qaytarish
            </ConfirmButton>
          )}
        </div>
        {error && <p className="text-sm text-danger">{error}</p>}
      </div>
    </div>
  );
}

export function TelegramTest() {
  const [pending, start] = useTransition();
  const [result, setResult] = useState<ActionState>({});
  return (
    <div className="flex flex-col items-end gap-2">
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={pending}
        onClick={() =>
          start(async () => {
            setResult(await sendTestTelegramAction());
          })
        }
      >
        {pending ? <Loader2 className="animate-spin" /> : <Send />} Test xabar
      </Button>
      <FormMessage state={result} />
    </div>
  );
}

export function PasswordForm() {
  const { state, pending, onSubmit } = useFormAction(changePasswordAction);
  return (
    <form onSubmit={onSubmit}>
      <AdminCard title="Parolni o‘zgartirish" description="Kamida 10 belgi. Harf, raqam va belgilardan foydalaning.">
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <Label htmlFor="current">Joriy parol</Label>
            <Input id="current" name="current" type="password" autoComplete="current-password" required />
          </div>
          <div>
            <Label htmlFor="next">Yangi parol</Label>
            <Input id="next" name="next" type="password" autoComplete="new-password" minLength={10} required />
          </div>
          <div>
            <Label htmlFor="confirm">Yangi parolni takrorlang</Label>
            <Input id="confirm" name="confirm" type="password" autoComplete="new-password" minLength={10} required />
          </div>
        </div>
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <SubmitButton pending={pending} variant="outline">
            <KeyRound /> Parolni yangilash
          </SubmitButton>
          <div className="min-w-0 flex-1">
            <FormMessage state={state} />
          </div>
        </div>
      </AdminCard>
    </form>
  );
}
