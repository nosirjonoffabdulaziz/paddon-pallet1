"use client";

import { useState } from "react";
import { Save } from "lucide-react";
import { saveProductAction } from "@/actions/admin";
import { AVAILABILITIES, CONDITIONS, MATERIALS } from "@/lib/catalog-options";
import { cn } from "@/lib/utils";
import { FieldError, Input, Label, Select, Textarea } from "@/components/ui/input";
import { PalletIso } from "@/components/site/pallet-iso";
import { AVAILABILITY_LABELS, CONDITION_LABELS, MATERIAL_LABELS } from "./labels";
import { AdminCard, FormMessage, SubmitButton, useFormAction } from "./ui";

export type ProductFormValues = {
  id?: string;
  slug: string;
  nameUz: string;
  nameRu: string;
  nameEn: string;
  descriptionUz: string;
  descriptionRu: string;
  descriptionEn: string;
  lengthMm: number | null;
  widthMm: number | null;
  heightMm: number | null;
  isStandard: boolean;
  isCustomSize: boolean;
  material: (typeof MATERIALS)[number];
  condition: (typeof CONDITIONS)[number];
  availability: (typeof AVAILABILITIES)[number];
  loadCapacityKg: number | null;
  price: number | null;
  isDemo: boolean;
  published: boolean;
  featured: boolean;
  sortOrder: number;
};

export const EMPTY_PRODUCT: ProductFormValues = {
  slug: "",
  nameUz: "",
  nameRu: "",
  nameEn: "",
  descriptionUz: "",
  descriptionRu: "",
  descriptionEn: "",
  lengthMm: 1200,
  widthMm: 800,
  heightMm: 144,
  isStandard: true,
  isCustomSize: false,
  material: "PINE",
  condition: "NEW",
  availability: "IN_STOCK",
  loadCapacityKg: null,
  price: null,
  isDemo: false,
  published: true,
  featured: false,
  sortOrder: 0,
};

const LANGS = [
  { code: "Uz", label: "O‘zbekcha" },
  { code: "Ru", label: "Русский" },
  { code: "En", label: "English" },
] as const;

export function ProductForm({ initial }: { initial: ProductFormValues }) {
  const { state, pending, onSubmit } = useFormAction(saveProductAction);
  const [lang, setLang] = useState<(typeof LANGS)[number]["code"]>("Uz");
  const [custom, setCustom] = useState(initial.isCustomSize);
  const [dims, setDims] = useState({
    l: initial.lengthMm ?? 1200,
    w: initial.widthMm ?? 800,
    h: initial.heightMm ?? 144,
  });
  const err = (k: string) => state.fields?.[k];

  return (
    <form onSubmit={onSubmit} className="grid gap-6 xl:grid-cols-[1fr_320px]">
      {initial.id && <input type="hidden" name="id" value={initial.id} />}
      <div className="space-y-6">
        <AdminCard title="Nomi va tavsifi" description="O‘zbekcha nom majburiy. Boshqa tillar bo‘sh qolsa, o‘zbekchasi ko‘rsatiladi.">
          <div className="mb-5 flex gap-1 rounded-full border border-line bg-sand/50 p-1 text-sm">
            {LANGS.map((l) => (
              <button
                key={l.code}
                type="button"
                onClick={() => setLang(l.code)}
                className={cn(
                  "flex-1 rounded-full px-3 py-1.5 font-medium transition",
                  lang === l.code ? "bg-card shadow-soft" : "text-muted",
                )}
              >
                {l.label}
              </button>
            ))}
          </div>
          {LANGS.map((l) => (
            <div key={l.code} className={cn("space-y-4", lang !== l.code && "hidden")}>
              <div>
                <Label htmlFor={`name${l.code}`}>Nomi ({l.label})</Label>
                <Input
                  id={`name${l.code}`}
                  name={`name${l.code}`}
                  defaultValue={initial[`name${l.code}`]}
                  maxLength={120}
                  aria-invalid={Boolean(err(`name${l.code}`))}
                />
                <FieldError message={err(`name${l.code}`)} />
              </div>
              <div>
                <Label htmlFor={`description${l.code}`}>Tavsif ({l.label})</Label>
                <Textarea
                  id={`description${l.code}`}
                  name={`description${l.code}`}
                  defaultValue={initial[`description${l.code}`]}
                  maxLength={3000}
                  rows={5}
                />
              </div>
            </div>
          ))}
          <div className="mt-5">
            <Label htmlFor="slug">Havola nomi (slug)</Label>
            <Input id="slug" name="slug" defaultValue={initial.slug} placeholder="avtomatik yaratiladi" maxLength={120} />
            <p className="mt-1 text-xs text-muted">Sayt manzilida ko‘rinadi: /products/<b>slug</b>. Bo‘sh qoldirsangiz, nomdan yaratiladi.</p>
            <FieldError message={err("slug")} />
          </div>
        </AdminCard>

        <AdminCard title="O‘lchamlar (mm)">
          <label className="mb-5 flex cursor-pointer items-center gap-3 text-sm">
            <input
              type="checkbox"
              name="isCustomSize"
              checked={custom}
              onChange={(e) => setCustom(e.target.checked)}
              className="size-4 accent-[#a77948]"
            />
            Individual o‘lcham (mijoz o‘zi kiritadi — uzunlik/kenglik ko‘rsatilmaydi)
          </label>
          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <Label htmlFor="lengthMm">Uzunlik</Label>
              <Input
                id="lengthMm"
                name="lengthMm"
                inputMode="numeric"
                defaultValue={initial.lengthMm ?? ""}
                disabled={custom}
                onChange={(e) => setDims((d) => ({ ...d, l: Number(e.target.value) || d.l }))}
                aria-invalid={Boolean(err("lengthMm"))}
              />
              <FieldError message={err("lengthMm")} />
            </div>
            <div>
              <Label htmlFor="widthMm">Kenglik</Label>
              <Input
                id="widthMm"
                name="widthMm"
                inputMode="numeric"
                defaultValue={initial.widthMm ?? ""}
                disabled={custom}
                onChange={(e) => setDims((d) => ({ ...d, w: Number(e.target.value) || d.w }))}
                aria-invalid={Boolean(err("widthMm"))}
              />
              <FieldError message={err("widthMm")} />
            </div>
            <div>
              <Label htmlFor="heightMm">Balandlik</Label>
              <Input
                id="heightMm"
                name="heightMm"
                inputMode="numeric"
                defaultValue={initial.heightMm ?? ""}
                onChange={(e) => setDims((d) => ({ ...d, h: Number(e.target.value) || d.h }))}
                aria-invalid={Boolean(err("heightMm"))}
              />
              <FieldError message={err("heightMm")} />
            </div>
          </div>
          <label className="mt-5 flex cursor-pointer items-center gap-3 text-sm">
            <input type="checkbox" name="isStandard" defaultChecked={initial.isStandard} className="size-4 accent-[#a77948]" />
            Standart o‘lcham (“O‘lchamlar” bo‘limida standartlar ro‘yxatida chiqadi)
          </label>
        </AdminCard>

        <AdminCard title="Texnik ma’lumotlar va narx">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="material">Material</Label>
              <Select id="material" name="material" defaultValue={initial.material}>
                {MATERIALS.map((m) => (
                  <option key={m} value={m}>
                    {MATERIAL_LABELS[m]}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="condition">Holati</Label>
              <Select id="condition" name="condition" defaultValue={initial.condition}>
                {CONDITIONS.map((c) => (
                  <option key={c} value={c}>
                    {CONDITION_LABELS[c]}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="availability">Mavjudligi</Label>
              <Select id="availability" name="availability" defaultValue={initial.availability}>
                {AVAILABILITIES.map((a) => (
                  <option key={a} value={a}>
                    {AVAILABILITY_LABELS[a]}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="loadCapacityKg">Yuk ko‘tarish quvvati (kg)</Label>
              <Input
                id="loadCapacityKg"
                name="loadCapacityKg"
                inputMode="numeric"
                defaultValue={initial.loadCapacityKg ?? ""}
                placeholder="Faqat tasdiqlangan qiymat"
              />
              <FieldError message={err("loadCapacityKg")} />
            </div>
            <div>
              <Label htmlFor="price">Narx (so‘m)</Label>
              <Input
                id="price"
                name="price"
                inputMode="numeric"
                defaultValue={initial.price ?? ""}
                placeholder="Bo‘sh — “Narxni so‘rash”"
              />
              <FieldError message={err("price")} />
            </div>
            <div>
              <Label htmlFor="sortOrder">Tartib raqami</Label>
              <Input id="sortOrder" name="sortOrder" inputMode="numeric" defaultValue={initial.sortOrder} />
              <p className="mt-1 text-xs text-muted">Kichik raqam — ro‘yxatda yuqorida.</p>
            </div>
          </div>
        </AdminCard>
      </div>

      <div className="space-y-6 xl:sticky xl:top-6 xl:self-start">
        <AdminCard title="Holat">
          <div className="space-y-3 text-sm">
            <label className="flex cursor-pointer items-center gap-3">
              <input type="checkbox" name="published" defaultChecked={initial.published} className="size-4 accent-[#a77948]" />
              Saytda ko‘rsatish
            </label>
            <label className="flex cursor-pointer items-center gap-3">
              <input type="checkbox" name="featured" defaultChecked={initial.featured} className="size-4 accent-[#a77948]" />
              Bosh sahifada ko‘rsatish
            </label>
            <label className="flex cursor-pointer items-start gap-3">
              <input type="checkbox" name="isDemo" defaultChecked={initial.isDemo} className="mt-0.5 size-4 accent-[#a77948]" />
              <span>
                Demo ma’lumot
                <span className="block text-xs text-muted">Haqiqiy ma’lumot kiritilgach, belgini olib tashlang.</span>
              </span>
            </label>
          </div>
          <div className="mt-6 space-y-3">
            <FormMessage state={state} />
            <SubmitButton className="w-full" pending={pending}>
              <Save /> Saqlash
            </SubmitButton>
          </div>
        </AdminCard>
        {!custom && (
          <div className="bg-blueprint rounded-2xl border border-line bg-card p-5">
            <p className="mb-2 text-xs font-medium text-muted">Vizual model</p>
            <PalletIso length={dims.l} width={dims.w} height={dims.h} />
          </div>
        )}
      </div>
    </form>
  );
}
