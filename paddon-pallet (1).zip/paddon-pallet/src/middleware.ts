import { NextResponse, type NextRequest } from "next/server";
import { defaultLocale, isLocale, LOCALE_COOKIE } from "@/lib/i18n";
import { SESSION_COOKIE, verifySession } from "@/lib/session";

export const config = {
  // api, statik fayllar va rasmlar middleware'dan o‘tmaydi
  matcher: ["/((?!api|_next|media|images|.*\\..*).*)"],
};

function withLocaleHeader(request: NextRequest, locale: string) {
  const headers = new Headers(request.headers);
  headers.set("x-locale", locale);
  return NextResponse.next({ request: { headers } });
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // --- Admin panel himoyasi ---
  if (pathname === "/admin" || pathname.startsWith("/admin/")) {
    if (pathname === "/admin/login") return withLocaleHeader(request, "uz");
    const session = await verifySession(request.cookies.get(SESSION_COOKIE)?.value);
    if (!session) {
      const url = request.nextUrl.clone();
      url.pathname = "/admin/login";
      url.search = "";
      return NextResponse.redirect(url);
    }
    return withLocaleHeader(request, "uz");
  }

  // --- Til prefiksi: /uz, /ru, /en ---
  const first = pathname.split("/")[1];
  if (isLocale(first)) return withLocaleHeader(request, first);

  const cookieLocale = request.cookies.get(LOCALE_COOKIE)?.value;
  const locale = isLocale(cookieLocale) ? cookieLocale : defaultLocale;
  const url = request.nextUrl.clone();
  url.pathname = `/${locale}${pathname === "/" ? "" : pathname}`;
  return NextResponse.redirect(url);
}
