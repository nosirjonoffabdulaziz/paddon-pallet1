"use server";

import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { clearSessionCookie, createSessionCookie, requireAdmin } from "@/lib/auth";
import {
  AVAILABILITIES,
  CONDITIONS,
  MATERIALS,
  ORDER_STATUSES,
} from "@/lib/catalog-options";
import { getClientIp, rateLimit } from "@/lib/rate-limit";
import { isAuthConfigured } from "@/lib/session";
import { IMAGE_SETTING_KEYS, SETTING_KEYS, isSettingKey } from "@/lib/settings";
import { deleteImage } from "@/lib/storage";
import { isTelegramConfigured, sendTelegramMessage } from "@/lib/telegram";
import { slugify } from "@/lib/utils";
import { flatten } from "@/i18n/flatten";
import uz from "@/i18n/dictionaries/uz";
import { baseDictionaries } from "@/i18n/get-dictionary";

export type ActionState = { ok?: boolean; error?: string; message?: string; fields?: Record<string, string> };

const refreshSite = () => revalidatePath("/", "layout");

// Mavjud bo‘lmagan foydalanuvchi uchun ham bcrypt hisoblanadi (vaqt bo‘yicha hujumdan himoya)
const DUMMY_HASH = "$2a$12$C6UzMDM.H6dfI/f/IKcEeOL5qCoGiTLUZy6P1d3qx9vRk7RHkdQ1y";

// ------------------------------------------------------------------
// Kirish / chiqish
// ------------------------------------------------------------------
export async function loginAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (!isAuthConfigured()) {
    return { error: "AUTH_SECRET sozlanmagan (kamida 32 belgi). .env faylini tekshiring." };
  }
  const ip = await getClientIp();
  if (!rateLimit(`login:${ip}`, 8, 15 * 60 * 1000).ok) {
    return { error: "Urinishlar juda ko‘p. 15 daqiqadan so‘ng qayta urinib ko‘ring." };
  }
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  if (!email || !password || password.length > 200) return { error: "Email va parolni kiriting." };

  let user: { id: string; email: string; passwordHash: string } | null = null;
  try {
    user = await prisma.adminUser.findUnique({ where: { email } });
  } catch (error) {
    console.error(error);
    return { error: "Ma’lumotlar bazasiga ulanib bo‘lmadi. DATABASE_URL ni tekshiring." };
  }
  // Foydalanuvchi bo‘lmasa ham hash solishtiriladi — javob vaqti bir xil bo‘lishi uchun
  const valid = await bcrypt.compare(password, user?.passwordHash ?? DUMMY_HASH);
  if (!user || !valid) return { error: "Email yoki parol noto‘g‘ri." };

  await createSessionCookie(user);
  redirect("/admin");
}

export async function logoutAction() {
  await clearSessionCookie();
  redirect("/admin/login");
}

export async function changePasswordAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const current = String(formData.get("current") ?? "");
  const next = String(formData.get("next") ?? "");
  const confirm = String(formData.get("confirm") ?? "");
  if (next.length < 10) return { error: "Yangi parol kamida 10 belgidan iborat bo‘lsin." };
  if (next !== confirm) return { error: "Yangi parollar mos kelmadi." };
  const user = await prisma.adminUser.findUnique({ where: { id: admin.id } });
  if (!user || !(await bcrypt.compare(current, user.passwordHash))) return { error: "Joriy parol noto‘g‘ri." };
  await prisma.adminUser.update({ where: { id: admin.id }, data: { passwordHash: await bcrypt.hash(next, 12) } });
  return { ok: true, message: "Parol yangilandi." };
}

// ------------------------------------------------------------------
// Mahsulotlar
// ------------------------------------------------------------------
const optionalInt = (max: number) =>
  z.preprocess(
    (v) => (v === "" || v === null || v === undefined ? null : v),
    z.coerce.number().int("Butun son kiriting").min(0, "Manfiy bo‘lmasin").max(max, "Juda katta qiymat").nullable(),
  );

const productSchema = z.object({
  id: z.string().optional(),
  slug: z.string().trim().max(120).optional(),
  nameUz: z.string().trim().min(2, "O‘zbekcha nom kiritilishi shart").max(120),
  nameRu: z.string().trim().max(120),
  nameEn: z.string().trim().max(120),
  descriptionUz: z.string().trim().max(3000),
  descriptionRu: z.string().trim().max(3000),
  descriptionEn: z.string().trim().max(3000),
  lengthMm: optionalInt(10000),
  widthMm: optionalInt(10000),
  heightMm: optionalInt(2000),
  material: z.enum(MATERIALS),
  condition: z.enum(CONDITIONS),
  availability: z.enum(AVAILABILITIES),
  loadCapacityKg: optionalInt(100000),
  price: optionalInt(2_000_000_000),
  sortOrder: z.coerce.number().int().min(0).max(10000).default(0),
});

const bool = (formData: FormData, key: string) => formData.get(key) === "on";

export async function saveProductAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin();
  const parsed = productSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) {
    const fields: Record<string, string> = {};
    for (const issue of parsed.error.issues) fields[String(issue.path[0])] ??= issue.message;
    return { error: "Formadagi xatolarni tuzating.", fields };
  }
  const { id, slug: rawSlug, ...data } = parsed.data;
  const isCustomSize = bool(formData, "isCustomSize");
  if (!isCustomSize && (!data.lengthMm || !data.widthMm)) {
    return {
      error: "Uzunlik va kenglikni kiriting yoki “Individual o‘lcham” belgisini qo‘ying.",
      fields: { lengthMm: "Majburiy", widthMm: "Majburiy" },
    };
  }

  const slug = slugify(rawSlug || `${data.nameUz}${data.lengthMm && data.widthMm ? `-${data.lengthMm}x${data.widthMm}` : ""}`);
  if (!slug) return { error: "Slug (havola nomi) noto‘g‘ri.", fields: { slug: "Lotin harflari va raqamlar" } };

  const clash = await prisma.product.findFirst({ where: { slug, NOT: id ? { id } : undefined } });
  if (clash) return { error: "Bu havola nomi (slug) band. Boshqasini kiriting.", fields: { slug: "Band" } };

  const payload = {
    ...data,
    slug,
    nameRu: data.nameRu || data.nameUz,
    nameEn: data.nameEn || data.nameUz,
    lengthMm: isCustomSize ? null : data.lengthMm,
    widthMm: isCustomSize ? null : data.widthMm,
    heightMm: data.heightMm,
    isCustomSize,
    isStandard: bool(formData, "isStandard"),
    isDemo: bool(formData, "isDemo"),
    published: bool(formData, "published"),
    featured: bool(formData, "featured"),
  };

  let savedId = id;
  try {
    if (id) await prisma.product.update({ where: { id }, data: payload });
    else savedId = (await prisma.product.create({ data: payload })).id;
  } catch (error) {
    console.error(error);
    return { error: "Saqlashda xatolik yuz berdi." };
  }
  refreshSite();
  if (!id) redirect(`/admin/products/${savedId}?created=1`);
  return { ok: true, message: "Saqlandi." };
}

export async function deleteProductAction(id: string) {
  await requireAdmin();
  const product = await prisma.product.findUnique({ where: { id }, include: { images: true } });
  if (!product) return;
  await prisma.product.delete({ where: { id } });
  await Promise.all(product.images.map((img) => deleteImage(img.url)));
  refreshSite();
  redirect("/admin/products");
}

export async function toggleProductPublishedAction(id: string, published: boolean) {
  await requireAdmin();
  await prisma.product.update({ where: { id }, data: { published } });
  refreshSite();
  revalidatePath("/admin/products");
}

export async function deleteProductImageAction(imageId: string) {
  await requireAdmin();
  const img = await prisma.productImage.findUnique({ where: { id: imageId } });
  if (!img) return;
  await prisma.productImage.delete({ where: { id: imageId } });
  await deleteImage(img.url);
  refreshSite();
  revalidatePath(`/admin/products/${img.productId}`);
}

export async function moveProductImageAction(imageId: string, direction: "up" | "down") {
  await requireAdmin();
  const img = await prisma.productImage.findUnique({ where: { id: imageId } });
  if (!img) return;
  const siblings = await prisma.productImage.findMany({
    where: { productId: img.productId },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
  });
  const index = siblings.findIndex((s) => s.id === imageId);
  const target = direction === "up" ? index - 1 : index + 1;
  if (target < 0 || target >= siblings.length) return;
  [siblings[index], siblings[target]] = [siblings[target]!, siblings[index]!];
  await prisma.$transaction(
    siblings.map((s, i) => prisma.productImage.update({ where: { id: s.id }, data: { sortOrder: i } })),
  );
  refreshSite();
  revalidatePath(`/admin/products/${img.productId}`);
}

// ------------------------------------------------------------------
// Buyurtmalar va xabarlar
// ------------------------------------------------------------------
export async function updateOrderStatusAction(id: string, status: string) {
  await requireAdmin();
  const parsed = z.enum(ORDER_STATUSES).safeParse(status);
  if (!parsed.success) return;
  await prisma.order.update({ where: { id }, data: { status: parsed.data } });
  revalidatePath("/admin/orders");
  revalidatePath("/admin");
}

export async function updateOrderNoteAction(id: string, note: string) {
  await requireAdmin();
  await prisma.order.update({ where: { id }, data: { adminNote: note.slice(0, 2000) } });
  revalidatePath("/admin/orders");
}

export async function deleteOrderAction(id: string) {
  await requireAdmin();
  await prisma.order.delete({ where: { id } });
  revalidatePath("/admin/orders");
  revalidatePath("/admin");
}

export async function toggleMessageReadAction(id: string, isRead: boolean) {
  await requireAdmin();
  await prisma.contactMessage.update({ where: { id }, data: { isRead } });
  revalidatePath("/admin/messages");
  revalidatePath("/admin");
}

export async function deleteMessageAction(id: string) {
  await requireAdmin();
  await prisma.contactMessage.delete({ where: { id } });
  revalidatePath("/admin/messages");
}

// ------------------------------------------------------------------
// Sayt matnlari (lug‘at ustidan yoziladi)
// ------------------------------------------------------------------
const TEXT_KEYS = new Set(Object.keys(flatten(uz)));

export async function saveTextsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin();
  const entries = new Map<string, { uz?: string; ru?: string; en?: string }>();
  for (const [name, value] of formData.entries()) {
    const match = /^t\|(.+)\|(uz|ru|en)$/.exec(name);
    if (!match || typeof value !== "string") continue;
    const [, key, lang] = match as unknown as [string, string, "uz" | "ru" | "en"];
    if (!TEXT_KEYS.has(key)) continue;
    const row = entries.get(key) ?? {};
    row[lang] = value.trim().slice(0, 3000);
    entries.set(key, row);
  }
  if (!entries.size) return { error: "O‘zgartirish topilmadi." };

  // Faqat standartdan farq qiladigan qiymatlar saqlanadi; qolganlari o‘chiriladi.
  const defaults = {
    uz: flatten(baseDictionaries.uz),
    ru: flatten(baseDictionaries.ru),
    en: flatten(baseDictionaries.en),
  };
  const ops = [];
  for (const [key, row] of entries) {
    const value = (lang: "uz" | "ru" | "en") => {
      const v = row[lang];
      return v && v !== defaults[lang][key] ? v : null;
    };
    const data = { uz: value("uz"), ru: value("ru"), en: value("en") };
    if (!data.uz && !data.ru && !data.en) ops.push(prisma.siteText.deleteMany({ where: { key } }));
    else ops.push(prisma.siteText.upsert({ where: { key }, create: { key, ...data }, update: data }));
  }
  await prisma.$transaction(ops);
  refreshSite();
  revalidatePath("/admin/texts");
  return { ok: true, message: `Saqlandi (${entries.size} ta matn tekshirildi).` };
}

export async function resetTextAction(key: string) {
  await requireAdmin();
  await prisma.siteText.deleteMany({ where: { key } });
  refreshSite();
  revalidatePath("/admin/texts");
}

// ------------------------------------------------------------------
// Sozlamalar (kontaktlar, xarita)
// ------------------------------------------------------------------
const TEXT_SETTING_KEYS = SETTING_KEYS.filter(
  (k) => !(IMAGE_SETTING_KEYS as readonly string[]).includes(k),
);

export async function saveSettingsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin();
  const fields: Record<string, string> = {};
  const values: Record<string, string> = {};
  for (const key of TEXT_SETTING_KEYS) {
    const raw = formData.get(key);
    if (typeof raw !== "string") continue;
    let v = raw.trim().slice(0, 1000);
    if (key === "mapEmbedUrl" && v) {
      // <iframe src="..."> kodini to‘liq qo‘yishsa ham, src qismini ajratib olamiz
      const src = /src="([^"]+)"/.exec(v)?.[1];
      if (src) v = src;
      if (!/^https:\/\/(www\.)?google\.[a-z.]+\/maps/.test(v)) fields[key] = "Google Maps havolasi bo‘lishi kerak";
    }
    if ((key === "phone" || key === "phone2") && v && !/^\+?[\d\s()-]{7,25}$/.test(v)) fields[key] = "Telefon formati noto‘g‘ri";
    if (key === "email" && v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) fields[key] = "Email formati noto‘g‘ri";
    values[key] = v;
  }
  if (Object.keys(fields).length) return { error: "Formadagi xatolarni tuzating.", fields };

  await prisma.$transaction(
    Object.entries(values).map(([key, value]) =>
      value
        ? prisma.setting.upsert({ where: { key }, create: { key, value }, update: { value } })
        : prisma.setting.deleteMany({ where: { key } }),
    ),
  );
  refreshSite();
  revalidatePath("/admin/settings");
  return { ok: true, message: "Sozlamalar saqlandi." };
}

export async function resetSiteImageAction(key: string) {
  await requireAdmin();
  if (!isSettingKey(key) || !(IMAGE_SETTING_KEYS as readonly string[]).includes(key)) return;
  const current = await prisma.setting.findUnique({ where: { key } });
  if (current) {
    await prisma.setting.delete({ where: { key } });
    await deleteImage(current.value);
  }
  refreshSite();
  revalidatePath("/admin/settings");
}

export async function sendTestTelegramAction(): Promise<ActionState> {
  await requireAdmin();
  if (!isTelegramConfigured()) return { error: "TELEGRAM_BOT_TOKEN va TELEGRAM_CHAT_ID sozlanmagan." };
  const ok = await sendTelegramMessage("✅ <b>Test xabar</b>\nSayt Telegram bilan muvaffaqiyatli ulandi.");
  return ok ? { ok: true, message: "Test xabar yuborildi." } : { error: "Yuborib bo‘lmadi. Token va chat ID ni tekshiring." };
}
