import type { Metadata } from "next";
import { getDictionary } from "@/i18n/get-dictionary";
import { getSizePresets } from "@/lib/products";
import { pageMetadata, resolveLocale, type LocaleParams } from "@/lib/page";
import { PageHero } from "@/components/site/section-heading";
import { SizeExplorer, type SizePreset } from "@/components/site/size-explorer";

export async function generateMetadata({ params }: LocaleParams): Promise<Metadata> {
  const locale = await resolveLocale(params);
  const dict = await getDictionary(locale);
  return pageMetadata(locale, "/sizes", dict.sizes.title, dict.sizes.subtitle);
}

export default async function SizesPage({ params }: LocaleParams) {
  const locale = await resolveLocale(params);
  const dict = await getDictionary(locale);
  let presets: SizePreset[] = [];
  try {
    presets = await getSizePresets();
  } catch (error) {
    console.error("Size presets failed:", error);
  }

  return (
    <>
      <PageHero eyebrow={dict.sizes.eyebrow} title={dict.sizes.title} text={dict.sizes.subtitle} />
      <section className="container-page py-10 md:py-16">
        <SizeExplorer locale={locale} dict={{ sizes: dict.sizes, common: dict.common }} presets={presets} />
      </section>
    </>
  );
}
