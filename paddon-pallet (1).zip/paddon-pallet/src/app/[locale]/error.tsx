"use client";

import { useEffect } from "react";
import { useParams } from "next/navigation";
import { AlertTriangle } from "lucide-react";
import { isLocale } from "@/lib/i18n";
import { Button } from "@/components/ui/button";

// Xato sahifasi serverga murojaat qilmaydi, shuning uchun matnlar shu yerda.
const texts = {
  uz: { title: "Nimadir noto‘g‘ri ketdi", text: "Sahifani yuklashda xatolik yuz berdi.", retry: "Qayta urinish", home: "Bosh sahifa" },
  ru: { title: "Что-то пошло не так", text: "При загрузке страницы произошла ошибка.", retry: "Повторить", home: "На главную" },
  en: { title: "Something went wrong", text: "An error occurred while loading the page.", retry: "Try again", home: "Home" },
};

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const params = useParams<{ locale: string }>();
  const raw = params?.locale;
  const locale = isLocale(raw) ? raw : "uz";
  const t = texts[locale];

  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <section className="container-page flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
      <span className="grid size-16 place-items-center rounded-2xl bg-danger/10 text-danger">
        <AlertTriangle className="size-7" />
      </span>
      <h1 className="mt-6 font-display text-3xl font-bold">{t.title}</h1>
      <p className="mt-3 max-w-md text-muted">{t.text}</p>
      <div className="mt-8 flex gap-3">
        <Button onClick={reset}>{t.retry}</Button>
        <Button asChild variant="outline">
          <a href={`/${locale}`}>{t.home}</a>
        </Button>
      </div>
    </section>
  );
}
