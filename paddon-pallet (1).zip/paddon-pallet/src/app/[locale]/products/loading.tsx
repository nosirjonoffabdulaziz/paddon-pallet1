export default function Loading() {
  return (
    <div className="container-page py-14" aria-busy="true">
      <div className="h-4 w-28 animate-pulse rounded-full bg-line" />
      <div className="mt-5 h-10 w-80 max-w-full animate-pulse rounded-xl bg-line" />
      <div className="mt-12 grid gap-8 lg:grid-cols-[280px_1fr]">
        <div className="hidden h-[520px] animate-pulse rounded-3xl bg-card lg:block" />
        <div>
          <div className="h-12 animate-pulse rounded-xl bg-card" />
          <div className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="overflow-hidden rounded-3xl border border-line bg-card">
                <div className="aspect-[4/3] animate-pulse bg-sand" />
                <div className="space-y-3 p-6">
                  <div className="h-5 w-2/3 animate-pulse rounded bg-line" />
                  <div className="h-4 w-1/3 animate-pulse rounded bg-line" />
                  <div className="h-10 animate-pulse rounded-full bg-sand" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
