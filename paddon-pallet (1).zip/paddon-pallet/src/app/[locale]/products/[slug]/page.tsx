import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { getDictionary } from "@/i18n/get-dictionary";
import { getProductBySlug, getRelatedProducts } from "@/lib/products";
import { pageMetadata, resolveLocale } from "@/lib/page";
import { formatNumber } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/site/product-card";
import { availabilityVariant, productDims } from "@/lib/product-helpers";
import { ProductDetailGallery } from "@/components/site/product-detail-gallery";
import { Reveal } from "@/components/site/reveal";

type Props = { params: Promise<{ locale: string; slug: string }> };

async function load(params: Props["params"]) {
  const { slug } = await params;
  const locale = await resolveLocale(params);
  const [dict, product] = await Promise.all([getDictionary(locale), getProductBySlug(slug, locale)]);
  if (!product) notFound();
  return { locale, dict, product };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, product } = await load(params);
  const meta = pageMetadata(locale, `/products/${product.slug}`, product.name, product.description || undefined);
  if (product.images[0]) meta.openGraph = { ...meta.openGraph, images: [product.images[0].url] };
  return meta;
}

export default async function ProductPage({ params }: Props) {
  const { locale, dict, product } = await load(params);
  const related = await getRelatedProducts(product.id, locale, 3).catch(() => []);
  const dims = productDims(product);
  const c = dict.common;
  const p = dict.products;

  const specs: [string, string][] = [
    [p.lengthLabel, product.lengthMm ? `${product.lengthMm} ${c.mm}` : c.individualSize],
    [p.widthLabel, product.widthMm ? `${product.widthMm} ${c.mm}` : "—"],
    [p.heightLabel, product.heightMm ? `${product.heightMm} ${c.mm}` : "—"],
    [p.sizeTypeLabel, product.isStandard ? c.standard : c.custom],
    [p.material, dict.labels.material[product.material]],
    [p.condition, dict.labels.condition[product.condition]],
    [p.loadCapacity, product.loadCapacityKg ? `${formatNumber(product.loadCapacityKg)} ${c.kg}` : "—"],
    [p.availability, dict.labels.availability[product.availability]],
  ];

  return (
    <>
      <div className="container-page pt-8">
        <Link
          href={`/${locale}/products`}
          className="inline-flex items-center gap-2 text-sm font-medium text-muted transition hover:text-ink"
        >
          <ArrowLeft className="size-4" /> {dict.nav.products}
        </Link>
      </div>

      <section className="container-page grid gap-10 py-8 lg:grid-cols-[1.15fr_1fr] lg:gap-14 lg:py-12">
        <ProductDetailGallery
          title={product.name}
          images={product.images}
          dims={dims}
          labels={{
            close: c.close,
            previous: c.previous,
            next: c.next,
            visualModel: c.visualModel,
            photoPending: c.photoPending,
            mm: c.mm,
          }}
        />

        <div>
          <div className="flex flex-wrap gap-2">
            {product.isDemo && <Badge variant="dark">{c.demo}</Badge>}
            <Badge variant={availabilityVariant(product.availability)}>
              {dict.labels.availability[product.availability]}
            </Badge>
            <Badge variant="outline">{dict.labels.condition[product.condition]}</Badge>
          </div>
          <h1 className="mt-5 font-display text-4xl font-bold md:text-5xl">{product.name}</h1>
          <p className="mt-3 font-display text-xl font-semibold text-wood-dark">
            {dims ? `${dims.length} × ${dims.width} × ${dims.height} ${c.mm}` : c.individualSize}
          </p>

          <div className="mt-8 rounded-2xl border border-line bg-card p-5">
            <p className="text-xs text-muted">{p.priceLabel}</p>
            {product.price ? (
              <p className="mt-1 font-display text-3xl font-bold">
                {formatNumber(product.price)} <span className="text-base text-muted">{c.currency}</span>
              </p>
            ) : (
              <p className="mt-1 font-display text-xl font-bold text-wood-dark">{c.requestPrice}</p>
            )}
            <div className="mt-5 grid gap-2 sm:grid-cols-2">
              <Button asChild variant="wood" size="lg">
                <Link href={`/${locale}/order?product=${product.slug}`}>
                  {p.orderThis} <ArrowRight />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href={`/${locale}/contact`}>{c.requestPrice}</Link>
              </Button>
            </div>
          </div>

          {product.description && (
            <div className="mt-10">
              <h2 className="font-display text-lg font-bold">{p.description}</h2>
              <p className="mt-3 whitespace-pre-line leading-relaxed text-muted">{product.description}</p>
            </div>
          )}

          <div className="mt-10">
            <h2 className="font-display text-lg font-bold">{p.specs}</h2>
            <dl className="mt-4 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-card">
              {specs.map(([label, value]) => (
                <div key={label} className="flex items-center justify-between gap-4 px-5 py-3.5 text-sm">
                  <dt className="text-muted">{label}</dt>
                  <dd className="text-right font-medium">{value}</dd>
                </div>
              ))}
            </dl>
          </div>
          {product.isDemo && <p className="mt-4 text-xs text-muted">* {c.demoNote}</p>}
        </div>
      </section>

      {related.length > 0 && (
        <section className="border-t border-line bg-card/40 py-16 md:py-20">
          <div className="container-page">
            <h2 className="font-display text-3xl font-bold">{p.related}</h2>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((r, i) => (
                <Reveal key={r.id} delay={i * 0.05}>
                  <ProductCard
                    product={r}
                    locale={locale}
                    dict={{ common: dict.common, labels: dict.labels, products: dict.products }}
                  />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
