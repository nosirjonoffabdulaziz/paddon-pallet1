import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { getDictionary } from "@/i18n/get-dictionary";
import { getCatalog, getCatalogFacets, parseCatalogFilters } from "@/lib/products";
import { pageMetadata, resolveLocale } from "@/lib/page";
import type { ProductDTO } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { CatalogShell, type Facets } from "@/components/site/catalog-shell";
import { ProductCard } from "@/components/site/product-card";
import { PageHero } from "@/components/site/section-heading";
import { EmptyState, ErrorState } from "@/components/site/states";

type Props = {
  params: Promise<{ locale: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const locale = await resolveLocale(params);
  const dict = await getDictionary(locale);
  return pageMetadata(locale, "/products", dict.products.title, dict.products.subtitle);
}

export default async function ProductsPage({ params, searchParams }: Props) {
  const locale = await resolveLocale(params);
  const dict = await getDictionary(locale);
  const filters = parseCatalogFilters(await searchParams);

  let products: ProductDTO[] = [];
  let facets: Facets = { sizes: [], hasCustom: false, materials: [], hasCapacity: false, priceRange: null };
  let failed = false;
  try {
    [products, facets] = await Promise.all([getCatalog(filters, locale), getCatalogFacets()]);
  } catch (error) {
    console.error("Catalog failed:", error);
    failed = true;
  }

  const cardDict = { common: dict.common, labels: dict.labels, products: dict.products };

  return (
    <>
      <PageHero eyebrow={dict.products.eyebrow} title={dict.products.title} text={dict.products.subtitle} />
      <section className="container-page py-10 md:py-14">
        {failed ? (
          <ErrorState
            title={dict.products.errorTitle}
            text={dict.products.errorText}
            action={
              <Button asChild variant="outline">
                <Link href={`/${locale}/products`}>{dict.errors.tryAgain}</Link>
              </Button>
            }
          />
        ) : (
          <Suspense fallback={null}>
            <CatalogShell
              dict={{ products: dict.products, labels: dict.labels, common: dict.common }}
              facets={facets}
              count={products.length}
            >
              {products.length === 0 ? (
                <EmptyState
                  title={dict.products.emptyTitle}
                  text={dict.products.emptyText}
                  action={
                    <div className="flex flex-wrap justify-center gap-3">
                      <Button asChild variant="outline">
                        <Link href={`/${locale}/products`}>{dict.products.reset}</Link>
                      </Button>
                      <Button asChild>
                        <Link href={`/${locale}/order`}>{dict.common.order}</Link>
                      </Button>
                    </div>
                  }
                />
              ) : (
                <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                  {products.map((p) => (
                    <ProductCard key={p.id} product={p} dict={cardDict} locale={locale} />
                  ))}
                </div>
              )}
            </CatalogShell>
          </Suspense>
        )}
        {!failed && products.some((p) => p.isDemo) && (
          <p className="mt-10 text-center text-xs text-muted">* {dict.common.demoNote}</p>
        )}
      </section>
    </>
  );
}
