import type { Metadata } from "next";
import { ExternalLink } from "lucide-react";
import { getDictionary } from "@/i18n/get-dictionary";
import { getContactInfo, getSettings } from "@/lib/settings";
import { pageMetadata, resolveLocale, type LocaleParams } from "@/lib/page";
import { ContactForm } from "@/components/site/contact-form";
import { ContactInfo } from "@/components/site/contact-info";
import { PageHero } from "@/components/site/section-heading";

export async function generateMetadata({ params }: LocaleParams): Promise<Metadata> {
  const locale = await resolveLocale(params);
  const dict = await getDictionary(locale);
  return pageMetadata(locale, "/contact", dict.contact.title, dict.contact.subtitle);
}

export default async function ContactPage({ params }: LocaleParams) {
  const locale = await resolveLocale(params);
  const [dict, settings] = await Promise.all([getDictionary(locale), getSettings()]);
  const contact = getContactInfo(settings, locale);
  const mapOk = /^https:\/\/(www\.)?google\.[a-z.]+\/maps/.test(contact.mapEmbedUrl);

  return (
    <>
      <PageHero eyebrow={dict.contact.eyebrow} title={dict.contact.title} text={dict.contact.subtitle} />
      <section className="container-page grid gap-8 py-10 md:py-16 lg:grid-cols-[1fr_1.1fr]">
        <div className="space-y-6">
          <ContactInfo contact={contact} dict={dict} />
          {mapOk && (
            <div className="overflow-hidden rounded-3xl border border-line bg-card shadow-soft">
              <div className="flex items-center justify-between border-b border-line px-5 py-3">
                <span className="text-sm font-semibold">{dict.contact.map}</span>
                {contact.address && (
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(contact.address)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-wood-dark hover:underline"
                  >
                    {dict.contact.openMap} <ExternalLink className="size-3.5" />
                  </a>
                )}
              </div>
              <iframe
                src={contact.mapEmbedUrl}
                title={dict.contact.map}
                className="aspect-[4/3] w-full grayscale-[0.3]"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          )}
        </div>
        <ContactForm locale={locale} dict={{ contact: dict.contact, errors: dict.errors, order: dict.order }} />
      </section>
    </>
  );
}
