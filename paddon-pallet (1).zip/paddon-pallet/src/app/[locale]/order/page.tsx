import type { Metadata } from "next";
import { getDictionary } from "@/i18n/get-dictionary";
import { prisma } from "@/lib/db";
import { SIZE_LIMITS, type ConditionValue, type MaterialValue } from "@/lib/catalog-options";
import { localizedField } from "@/lib/i18n";
import { pageMetadata, resolveLocale } from "@/lib/page";
import { OrderConfigurator } from "@/components/site/order-configurator";
import { PageHero } from "@/components/site/section-heading";

type Props = {
  params: Promise<{ locale: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const locale = await resolveLocale(params);
  const dict = await getDictionary(locale);
  return pageMetadata(locale, "/order", dict.order.title, dict.order.subtitle);
}

const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
const intParam = (v: string | undefined, min: number, max: number) => {
  const n = Number.parseInt(v ?? "", 10);
  return Number.isFinite(n) && n >= min && n <= max ? n : null;
};

export default async function OrderPage({ params, searchParams }: Props) {
  const locale = await resolveLocale(params);
  const sp = await searchParams;
  const dict = await getDictionary(locale);

  // ?product=slug — katalogdagi "Buyurtma berish" tugmasidan
  // ?l=1200&w=800&h=144 — o‘lchamlar bo‘limidan
  let product: { slug: string; name: string; image: string | null; isCustomSize: boolean } | null = null;
  let material: MaterialValue = "PINE";
  let condition: ConditionValue = "NEW";
  let length = intParam(one(sp.l), SIZE_LIMITS.length.min, SIZE_LIMITS.length.max);
  let width = intParam(one(sp.w), SIZE_LIMITS.width.min, SIZE_LIMITS.width.max);
  let height = intParam(one(sp.h), SIZE_LIMITS.height.min, SIZE_LIMITS.height.max);

  const slug = one(sp.product);
  if (slug && /^[a-z0-9-]{1,120}$/.test(slug)) {
    try {
      const p = await prisma.product.findFirst({
        where: { slug, published: true },
        include: { images: { orderBy: { sortOrder: "asc" }, take: 1 } },
      });
      if (p) {
        product = {
          slug: p.slug,
          name: localizedField(p, "name", locale),
          image: p.images[0]?.url ?? null,
          isCustomSize: p.isCustomSize,
        };
        material = p.material;
        condition = p.condition;
        length ??= p.lengthMm;
        width ??= p.widthMm;
        height ??= p.heightMm;
      }
    } catch (error) {
      console.error("Order product lookup failed:", error);
    }
  }

  return (
    <>
      <PageHero eyebrow={dict.order.eyebrow} title={dict.order.title} text={dict.order.subtitle} />
      <section className="container-page py-10 md:py-14">
        <OrderConfigurator
          locale={locale}
          dict={{ order: dict.order, labels: dict.labels, common: dict.common, errors: dict.errors, sizes: dict.sizes }}
          initial={{
            length: length ?? SIZE_LIMITS.length.default,
            width: width ?? SIZE_LIMITS.width.default,
            height: height ?? SIZE_LIMITS.height.default,
            product,
            material,
            condition,
          }}
        />
      </section>
    </>
  );
}
