import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Ruler, ShieldCheck, Truck } from "lucide-react";
import { getDictionary } from "@/i18n/get-dictionary";
import { getSettings, siteImage } from "@/lib/settings";
import { pageMetadata, resolveLocale, type LocaleParams } from "@/lib/page";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/site/reveal";
import { PageHero } from "@/components/site/section-heading";

export async function generateMetadata({ params }: LocaleParams): Promise<Metadata> {
  const locale = await resolveLocale(params);
  const dict = await getDictionary(locale);
  return pageMetadata(locale, "/about", dict.about.title, dict.about.intro);
}

export default async function AboutPage({ params }: LocaleParams) {
  const locale = await resolveLocale(params);
  const [dict, settings] = await Promise.all([getDictionary(locale), getSettings()]);
  const a = dict.about;

  const steps = [
    [a.process1Title, a.process1Text],
    [a.process2Title, a.process2Text],
    [a.process3Title, a.process3Text],
    [a.process4Title, a.process4Text],
  ];
  const pillars = [
    { icon: ShieldCheck, title: a.qualityTitle, text: a.qualityText },
    { icon: Ruler, title: a.customTitle, text: a.customText },
    { icon: Truck, title: a.deliveryTitle, text: a.deliveryText },
  ];
  const gallery = [
    { src: siteImage(settings, "aboutImage1"), alt: a.imageAlt1 },
    { src: siteImage(settings, "aboutImage2"), alt: a.imageAlt2 },
    { src: siteImage(settings, "aboutImage3"), alt: a.imageAlt3 },
  ];

  return (
    <>
      <PageHero eyebrow={a.eyebrow} title={a.title} text={a.intro} />

      <section className="container-page grid gap-12 py-16 md:py-24 lg:grid-cols-2 lg:items-center">
        <Reveal className="relative aspect-[4/3] overflow-hidden rounded-[2rem]">
          <Image src={gallery[0]!.src} alt={gallery[0]!.alt} fill sizes="(min-width: 1024px) 50vw, 100vw" className="object-cover" priority />
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="font-display text-3xl font-bold md:text-4xl">{a.companyTitle}</h2>
          <p className="mt-5 text-lg leading-relaxed text-muted">{a.companyText}</p>
        </Reveal>
      </section>

      <section className="border-y border-line bg-card/50 py-16 md:py-24">
        <div className="container-page">
          <h2 className="font-display text-3xl font-bold md:text-4xl">{a.processTitle}</h2>
          <ol className="mt-12 grid gap-px overflow-hidden rounded-3xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {steps.map(([title, text], i) => (
              <Reveal key={title} delay={i * 0.06} className="h-full">
                <li className="flex h-full flex-col bg-card p-7">
                  <span className="font-display text-sm font-bold text-wood">0{i + 1}</span>
                  <h3 className="mt-6 font-display text-lg font-bold">{title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{text}</p>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="container-page grid gap-5 py-16 md:grid-cols-3 md:py-24">
        {pillars.map(({ icon: Icon, title, text }, i) => (
          <Reveal key={title} delay={i * 0.06}>
            <div className="h-full rounded-3xl border border-line bg-card p-8 shadow-soft">
              <span className="grid size-12 place-items-center rounded-2xl bg-wood/10 text-wood-dark">
                <Icon className="size-5" />
              </span>
              <h3 className="mt-6 font-display text-xl font-bold">{title}</h3>
              <p className="mt-3 leading-relaxed text-muted">{text}</p>
            </div>
          </Reveal>
        ))}
      </section>

      <section className="container-page pb-20 md:pb-28">
        <h2 className="font-display text-3xl font-bold">{a.galleryTitle}</h2>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {gallery.map((img, i) => (
            <Reveal key={`${img.src}-${i}`} delay={i * 0.06}>
              <figure className="overflow-hidden rounded-3xl border border-line bg-white">
                <div className="relative aspect-[4/3]">
                  <Image
                    src={img.src}
                    alt={img.alt}
                    fill
                    sizes="(min-width: 768px) 33vw, 100vw"
                    className={i === 0 ? "object-cover" : "object-contain p-6"}
                  />
                </div>
                <figcaption className="border-t border-line px-5 py-3 text-sm text-muted">{img.alt}</figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
        <div className="mt-14 flex justify-center">
          <Button asChild size="lg">
            <Link href={`/${locale}/order`}>
              {a.cta} <ArrowRight />
            </Link>
          </Button>
        </div>
      </section>
    </>
  );
}
