import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Phone, Send } from "lucide-react";
import { getDictionary } from "@/i18n/get-dictionary";
import { getFeaturedProducts, getSizePresets } from "@/lib/products";
import { DEFAULT_SITE_IMAGES, getContactInfo, getSettings, siteImage } from "@/lib/settings";
import { resolveLocale, type LocaleParams } from "@/lib/page";
import { phoneHref, telegramHref } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Hero } from "@/components/site/hero";
import { ProductCard } from "@/components/site/product-card";
import { Reveal } from "@/components/site/reveal";
import { SectionHeading } from "@/components/site/section-heading";
import { SizeExplorer } from "@/components/site/size-explorer";
import { EmptyState, ErrorState } from "@/components/site/states";
import type { ProductDTO } from "@/lib/types";

export default async function HomePage({ params }: LocaleParams) {
  const locale = await resolveLocale(params);
  const [dict, settings] = await Promise.all([getDictionary(locale), getSettings()]);
  const contact = getContactInfo(settings, locale);

  let products: ProductDTO[] = [];
  let presets: Awaited<ReturnType<typeof getSizePresets>> = [];
  let failed = false;
  try {
    [products, presets] = await Promise.all([getFeaturedProducts(locale, 4), getSizePresets()]);
  } catch (error) {
    console.error(error);
    failed = true;
  }

  const heroImage = siteImage(settings, "heroImage");
  const cardDict = { common: dict.common, labels: dict.labels, products: dict.products };

  return (
    <>
      <Hero
        locale={locale}
        dict={{ hero: dict.hero, meta: dict.meta }}
        image={heroImage}
        isDefaultImage={heroImage === DEFAULT_SITE_IMAGES.heroImage}
      />

      {/* Mahsulotlar */}
      <section className="border-t border-line bg-card/40 py-20 md:py-28">
        <div className="container-page">
          <Reveal>
            <SectionHeading
              eyebrow={dict.home.productsEyebrow}
              title={dict.home.productsTitle}
              text={dict.home.productsText}
              action={
                <Button asChild variant="outline">
                  <Link href={`/${locale}/products`}>
                    {dict.common.viewAll} <ArrowRight />
                  </Link>
                </Button>
              }
            />
          </Reveal>
          <div className="mt-12">
            {failed ? (
              <ErrorState title={dict.products.errorTitle} text={dict.products.errorText} />
            ) : products.length === 0 ? (
              <EmptyState title={dict.products.emptyTitle} text={dict.products.emptyText} />
            ) : (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                {products.map((p, i) => (
                  <Reveal key={p.id} delay={i * 0.06}>
                    <ProductCard product={p} dict={cardDict} locale={locale} />
                  </Reveal>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* O‘lchamlar */}
      <section className="py-20 md:py-28">
        <div className="container-page">
          <Reveal>
            <SectionHeading
              eyebrow={dict.home.sizesEyebrow}
              title={dict.home.sizesTitle}
              text={dict.home.sizesText}
              action={
                <Button asChild variant="outline">
                  <Link href={`/${locale}/sizes`}>
                    {dict.home.sizesCta} <ArrowRight />
                  </Link>
                </Button>
              }
            />
          </Reveal>
          <Reveal className="mt-12">
            <SizeExplorer locale={locale} dict={{ sizes: dict.sizes, common: dict.common }} presets={presets} compact />
          </Reveal>
        </div>
      </section>

      {/* Maxsus buyurtma */}
      <section className="py-6 md:py-10">
        <div className="container-page">
          <Reveal>
            <div className="relative overflow-hidden rounded-[2rem] bg-ink px-6 py-14 text-white sm:px-12 md:py-20">
              <div
                aria-hidden
                className="absolute inset-0 opacity-[0.07] [background-image:linear-gradient(to_right,#fff_1px,transparent_1px),linear-gradient(to_bottom,#fff_1px,transparent_1px)] [background-size:48px_48px]"
              />
              <div className="relative grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-center">
                <div>
                  <span className="eyebrow text-wood-light">{dict.home.configEyebrow}</span>
                  <h2 className="mt-4 font-display text-3xl font-bold md:text-[44px] md:leading-tight">
                    {dict.home.configTitle}
                  </h2>
                  <p className="mt-5 max-w-xl text-lg leading-relaxed text-white/65">{dict.home.configText}</p>
                  <Button asChild variant="wood" size="lg" className="mt-9">
                    <Link href={`/${locale}/order`}>
                      {dict.home.configCta} <ArrowRight />
                    </Link>
                  </Button>
                </div>
                <ol className="grid gap-3">
                  {[dict.home.step1, dict.home.step2, dict.home.step3].map((step, i) => (
                    <li
                      key={step}
                      className="flex items-center gap-5 rounded-2xl border border-white/10 bg-white/[0.04] px-6 py-5 backdrop-blur"
                    >
                      <span className="font-display text-3xl font-extrabold text-wood">0{i + 1}</span>
                      <span className="text-[15px] font-medium text-white/85">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Biz haqimizda */}
      <section className="py-20 md:py-28">
        <div className="container-page grid gap-12 lg:grid-cols-2 lg:items-center">
          <Reveal className="relative aspect-[4/3] overflow-hidden rounded-[2rem]">
            <Image
              src={siteImage(settings, "aboutImage1")}
              alt={dict.about.imageAlt1}
              fill
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
            />
          </Reveal>
          <Reveal delay={0.1}>
            <SectionHeading eyebrow={dict.home.aboutEyebrow} title={dict.home.aboutTitle} text={dict.home.aboutText} />
            <Button asChild variant="outline" className="mt-8">
              <Link href={`/${locale}/about`}>
                {dict.home.aboutCta} <ArrowRight />
              </Link>
            </Button>
          </Reveal>
        </div>
      </section>

      {/* Aloqa */}
      <section className="border-t border-line bg-sand/60 py-16 md:py-20">
        <div className="container-page flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="font-display text-3xl font-bold">{dict.home.contactTitle}</h2>
            <p className="mt-3 max-w-lg text-muted">{dict.home.contactText}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            {contact.phone && (
              <Button asChild size="lg">
                <a href={phoneHref(contact.phone)}>
                  <Phone /> {contact.phone}
                </a>
              </Button>
            )}
            {contact.telegram && (
              <Button asChild size="lg" variant="outline">
                <a href={telegramHref(contact.telegram)} target="_blank" rel="noopener noreferrer">
                  <Send /> {dict.contact.writeTelegram}
                </a>
              </Button>
            )}
            {!contact.phone && !contact.telegram && (
              <Button asChild size="lg">
                <Link href={`/${locale}/contact`}>
                  {dict.nav.contact} <ArrowRight />
                </Link>
              </Button>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
