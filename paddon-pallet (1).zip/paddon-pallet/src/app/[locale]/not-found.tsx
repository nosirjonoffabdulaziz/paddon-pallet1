import Link from "next/link";
import { headers } from "next/headers";
import { getDictionary } from "@/i18n/get-dictionary";
import { defaultLocale, isLocale } from "@/lib/i18n";
import { Button } from "@/components/ui/button";

export default async function NotFound() {
  const h = await headers();
  const raw = h.get("x-locale");
  const locale = isLocale(raw) ? raw : defaultLocale;
  const dict = await getDictionary(locale);
  return (
    <section className="container-page flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
      <p className="font-display text-[120px] font-extrabold leading-none tracking-tighter text-wood/25">404</p>
      <h1 className="mt-4 font-display text-3xl font-bold">{dict.errors.notFoundTitle}</h1>
      <p className="mt-3 max-w-md text-muted">{dict.errors.notFoundText}</p>
      <Button asChild className="mt-8">
        <Link href={`/${locale}`}>{dict.errors.goHome}</Link>
      </Button>
    </section>
  );
}
