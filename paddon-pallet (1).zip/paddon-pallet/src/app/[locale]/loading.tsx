export default function Loading() {
  return (
    <div className="container-page flex min-h-[50vh] items-center justify-center" aria-busy="true">
      <div className="flex flex-col items-center gap-4">
        <div className="relative h-10 w-16">
          <span className="absolute inset-x-0 top-0 h-2 animate-pulse rounded-sm bg-wood/70" />
          <span className="absolute inset-x-0 top-3.5 h-2 animate-pulse rounded-sm bg-wood/50 [animation-delay:150ms]" />
          <span className="absolute inset-x-0 top-7 h-2 animate-pulse rounded-sm bg-wood/30 [animation-delay:300ms]" />
        </div>
      </div>
    </div>
  );
}
