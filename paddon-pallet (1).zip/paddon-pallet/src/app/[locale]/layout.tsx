import type { Metadata } from "next";
import type { ReactNode } from "react";
import { getDictionary } from "@/i18n/get-dictionary";
import { getContactInfo, getSettings } from "@/lib/settings";
import { resolveLocale, type LocaleParams } from "@/lib/page";
import { Header } from "@/components/site/header";
import { Footer } from "@/components/site/footer";

// Sahifalar har so‘rovda yangilanadi — admin paneldagi o‘zgarishlar darhol ko‘rinadi.
export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: LocaleParams): Promise<Metadata> {
  const locale = await resolveLocale(params);
  const dict = await getDictionary(locale);
  return {
    title: { default: dict.meta.title, template: `%s — ${dict.meta.brand}` },
    description: dict.meta.description,
    applicationName: dict.meta.brand,
    openGraph: {
      siteName: dict.meta.brand,
      title: dict.meta.title,
      description: dict.meta.description,
      images: ["/images/site/warehouse.webp"],
      locale,
      type: "website",
    },
  };
}

export default async function LocaleLayout({ children, params }: LocaleParams & { children: ReactNode }) {
  const locale = await resolveLocale(params);
  const [dict, settings] = await Promise.all([getDictionary(locale), getSettings()]);
  const contact = getContactInfo(settings, locale);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-ink focus:px-4 focus:py-2 focus:text-white"
      >
        {dict.nav.home}
      </a>
      <Header locale={locale} dict={{ nav: dict.nav, header: dict.header, meta: dict.meta }} phone={contact.phone} />
      <main id="main">{children}</main>
      <Footer locale={locale} dict={dict} contact={contact} />
    </>
  );
}
