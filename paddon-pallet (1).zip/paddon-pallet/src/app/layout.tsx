import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { headers } from "next/headers";
import "@fontsource-variable/manrope";
import "@fontsource-variable/inter";
import "./globals.css";
import { defaultLocale, isLocale } from "@/lib/i18n";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  icons: { icon: "/icon.svg" },
};

export const viewport: Viewport = {
  themeColor: "#f7f5f0",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const h = await headers();
  const locale = h.get("x-locale");
  return (
    <html lang={isLocale(locale) ? locale : defaultLocale}>
      <body className="min-h-dvh">{children}</body>
    </html>
  );
}
