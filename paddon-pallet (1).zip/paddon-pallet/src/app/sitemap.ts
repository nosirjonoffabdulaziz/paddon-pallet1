import type { MetadataRoute } from "next";
import { prisma } from "@/lib/db";
import { locales } from "@/lib/i18n";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, "");
  const pages = ["", "/products", "/sizes", "/about", "/order", "/contact"];
  let slugs: { slug: string; updatedAt: Date }[] = [];
  try {
    slugs = await prisma.product.findMany({ where: { published: true }, select: { slug: true, updatedAt: true } });
  } catch {
    // Baza ishlamasa ham asosiy sahifalar sitemap'da qoladi
  }
  return locales.flatMap((locale) => [
    ...pages.map((p) => ({ url: `${base}/${locale}${p}`, changeFrequency: "weekly" as const, priority: p ? 0.7 : 1 })),
    ...slugs.map((s) => ({ url: `${base}/${locale}/products/${s.slug}`, lastModified: s.updatedAt, priority: 0.6 })),
  ]);
}
