import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { getAdminSession } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { IMAGE_SETTING_KEYS, type ImageSettingKey } from "@/lib/settings";
import { deleteImage, saveImage, StorageError } from "@/lib/storage";

export const dynamic = "force-dynamic";

const ERRORS: Record<StorageError["code"], string> = {
  type: "Faqat JPG, PNG, WEBP yoki AVIF rasm yuklash mumkin.",
  size: "Rasm hajmi 4 MB dan oshmasin.",
  not_configured: "Vercel Blob ulanmagan: BLOB_READ_WRITE_TOKEN ni sozlang (README'ga qarang).",
  failed: "Rasmni saqlab bo‘lmadi. Qayta urinib ko‘ring.",
};

/**
 * Admin rasm yuklash.
 *  target=product  & productId=...  → mahsulot galereyasiga qo‘shadi
 *  target=setting  & key=heroImage  → sayt rasmini almashtiradi
 */
export async function POST(request: Request) {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "Avtorizatsiya talab qilinadi." }, { status: 401 });

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Fayl topilmadi." }, { status: 400 });
  }
  const file = form.get("file");
  const target = form.get("target");
  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: "Fayl tanlanmagan." }, { status: 400 });
  }

  try {
    if (target === "product") {
      const productId = String(form.get("productId") ?? "");
      const product = await prisma.product.findUnique({
        where: { id: productId },
        select: { id: true, nameUz: true, _count: { select: { images: true } } },
      });
      if (!product) return NextResponse.json({ error: "Mahsulot topilmadi." }, { status: 404 });
      if (product._count.images >= 12) {
        return NextResponse.json({ error: "Bitta mahsulotga ko‘pi bilan 12 ta rasm." }, { status: 400 });
      }
      const url = await saveImage(file, "products");
      const image = await prisma.productImage.create({
        data: { productId, url, alt: product.nameUz, sortOrder: product._count.images },
      });
      revalidatePath("/", "layout");
      return NextResponse.json({ ok: true, image });
    }

    if (target === "setting") {
      const key = String(form.get("key") ?? "");
      if (!(IMAGE_SETTING_KEYS as readonly string[]).includes(key)) {
        return NextResponse.json({ error: "Noma’lum sozlama." }, { status: 400 });
      }
      const url = await saveImage(file, "site");
      const previous = await prisma.setting.findUnique({ where: { key: key as ImageSettingKey } });
      await prisma.setting.upsert({ where: { key }, create: { key, value: url }, update: { value: url } });
      if (previous) await deleteImage(previous.value);
      revalidatePath("/", "layout");
      return NextResponse.json({ ok: true, url });
    }

    return NextResponse.json({ error: "Noto‘g‘ri so‘rov." }, { status: 400 });
  } catch (error) {
    if (error instanceof StorageError) {
      return NextResponse.json({ error: ERRORS[error.code] }, { status: 400 });
    }
    console.error("Upload failed:", error);
    return NextResponse.json({ error: ERRORS.failed }, { status: 500 });
  }
}
