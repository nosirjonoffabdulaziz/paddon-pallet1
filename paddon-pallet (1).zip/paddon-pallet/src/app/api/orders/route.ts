import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getClientIp, rateLimit } from "@/lib/rate-limit";
import { escapeHtml, sendTelegramMessage } from "@/lib/telegram";
import { fieldErrors, orderSchema } from "@/lib/validation";
import uz from "@/i18n/dictionaries/uz";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const ip = await getClientIp();
  if (!rateLimit(`order:${ip}`, 5, 10 * 60 * 1000).ok) {
    return NextResponse.json({ ok: false, error: "rateLimited" }, { status: 429 });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "validation" }, { status: 400 });
  }

  const parsed = orderSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: "validation", fields: fieldErrors(parsed.error) },
      { status: 422 },
    );
  }
  const data = parsed.data;

  // Botlar yashirin "website" maydonini to‘ldiradi — ularga muvaffaqiyat ko‘rsatamiz, lekin saqlamaymiz.
  if (data.website) return NextResponse.json({ ok: true, number: 0 });

  try {
    const product = data.productSlug
      ? await prisma.product.findUnique({ where: { slug: data.productSlug }, select: { id: true, nameUz: true } })
      : null;

    const order = await prisma.order.create({
      data: {
        source: product ? "PRODUCT" : "CONFIGURATOR",
        productId: product?.id,
        productName: product?.nameUz,
        lengthMm: data.lengthMm,
        widthMm: data.widthMm,
        heightMm: data.heightMm,
        quantity: data.quantity,
        woodType: data.woodType,
        condition: data.condition,
        notes: data.notes,
        customerName: data.customerName,
        phone: data.phone,
        locale: data.locale,
      },
    });

    const lines = [
      `🪵 <b>Yangi buyurtma #${order.number}</b>`,
      product ? `Mahsulot: ${escapeHtml(product.nameUz)}` : "Turi: maxsus o‘lcham (konfigurator)",
      `O‘lcham: ${data.lengthMm} × ${data.widthMm} × ${data.heightMm} mm`,
      `Soni: ${data.quantity} dona`,
      `Yog‘och: ${uz.labels.material[data.woodType]}`,
      `Holati: ${uz.labels.condition[data.condition]}`,
      data.notes ? `Izoh: ${escapeHtml(data.notes)}` : null,
      "",
      `👤 ${escapeHtml(data.customerName)}`,
      `📞 ${escapeHtml(data.phone)}`,
      `🌐 Til: ${data.locale.toUpperCase()}`,
    ].filter((l): l is string => l !== null);

    const sent = await sendTelegramMessage(lines.join("\n"));
    if (sent) await prisma.order.update({ where: { id: order.id }, data: { telegramSent: true } });

    return NextResponse.json({ ok: true, number: order.number });
  } catch (error) {
    console.error("Order create failed:", error);
    return NextResponse.json({ ok: false, error: "generic" }, { status: 500 });
  }
}
