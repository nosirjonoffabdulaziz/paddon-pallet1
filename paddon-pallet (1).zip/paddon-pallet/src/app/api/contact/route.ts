import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getClientIp, rateLimit } from "@/lib/rate-limit";
import { escapeHtml, sendTelegramMessage } from "@/lib/telegram";
import { contactSchema, fieldErrors } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const ip = await getClientIp();
  if (!rateLimit(`contact:${ip}`, 5, 10 * 60 * 1000).ok) {
    return NextResponse.json({ ok: false, error: "rateLimited" }, { status: 429 });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "validation" }, { status: 400 });
  }

  const parsed = contactSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: "validation", fields: fieldErrors(parsed.error) },
      { status: 422 },
    );
  }
  const data = parsed.data;
  if (data.website) return NextResponse.json({ ok: true });

  try {
    await prisma.contactMessage.create({
      data: { name: data.name, phone: data.phone, message: data.message, locale: data.locale },
    });
    await sendTelegramMessage(
      [
        "✉️ <b>Saytdan yangi xabar</b>",
        `👤 ${escapeHtml(data.name)}`,
        `📞 ${escapeHtml(data.phone)}`,
        "",
        escapeHtml(data.message),
      ].join("\n"),
    );
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Contact message failed:", error);
    return NextResponse.json({ ok: false, error: "generic" }, { status: 500 });
  }
}
