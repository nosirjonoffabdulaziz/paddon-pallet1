import { getSettings, DEFAULT_SITE_IMAGES, IMAGE_SETTING_KEYS } from "@/lib/settings";
import { isBlobConfigured } from "@/lib/storage";
import { isTelegramConfigured } from "@/lib/telegram";
import { AdminPageHeader } from "@/components/admin/page-header";
import { ContactSettingsForm, PasswordForm, SiteImageField, TelegramTest } from "@/components/admin/settings-forms";
import { AdminCard } from "@/components/admin/ui";

export const metadata = { title: "Sozlamalar" };

const IMAGE_LABELS: Record<(typeof IMAGE_SETTING_KEYS)[number], string> = {
  heroImage: "Bosh ekran rasmi (oq fonli pallet rasmi tavsiya etiladi)",
  aboutImage1: "“Biz haqimizda” — 1-rasm (ombor / ishlab chiqarish)",
  aboutImage2: "“Biz haqimizda” — 2-rasm (tayyor pallet)",
  aboutImage3: "“Biz haqimizda” — 3-rasm (logistika)",
};

export default async function SettingsPage() {
  const settings = await getSettings();
  const telegram = isTelegramConfigured();
  const blob = isBlobConfigured();

  return (
    <>
      <AdminPageHeader
        title="Sozlamalar"
        description="Kontaktlar, xarita, sayt rasmlari va xavfsizlik. Bo‘sh qoldirilgan maydonlar saytda ko‘rsatilmaydi."
      />
      <div className="space-y-6">
        <ContactSettingsForm initial={settings} />

        <AdminCard
          title="Sayt rasmlari"
          description={
            blob || !process.env.VERCEL
              ? "Yangi rasm yuklasangiz, standart rasm almashtiriladi. “Standartga qaytarish” — asl rasmni tiklaydi."
              : "Diqqat: Vercel Blob ulanmagan — rasm yuklash ishlamaydi. README'dagi ko‘rsatmaga qarang."
          }
        >
          <div className="grid gap-5 sm:grid-cols-2">
            {IMAGE_SETTING_KEYS.map((key) => (
              <SiteImageField
                key={key}
                settingKey={key}
                label={IMAGE_LABELS[key]}
                url={settings[key] || DEFAULT_SITE_IMAGES[key]}
                isCustom={Boolean(settings[key])}
              />
            ))}
          </div>
        </AdminCard>

        <AdminCard title="Integratsiyalar holati">
          <ul className="space-y-3 text-sm">
            <li className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line p-4">
              <div>
                <p className="font-semibold">Telegram xabarnomalar</p>
                <p className="text-muted">
                  {telegram
                    ? "Ulangan. Har bir buyurtma va xabar Telegram'ga yuboriladi."
                    : "Ulanmagan. .env faylida TELEGRAM_BOT_TOKEN va TELEGRAM_CHAT_ID ni kiriting."}
                </p>
              </div>
              {telegram && <TelegramTest />}
            </li>
            <li className="rounded-xl border border-line p-4">
              <p className="font-semibold">Rasm saqlash (Vercel Blob)</p>
              <p className="text-muted">
                {blob
                  ? "Ulangan. Rasmlar Vercel Blob'da doimiy saqlanadi."
                  : process.env.VERCEL
                    ? "Ulanmagan! Vercel → Storage → Blob yarating, BLOB_READ_WRITE_TOKEN avtomatik qo‘shiladi."
                    : "Lokal rejim: rasmlar loyiha ichidagi ./uploads papkasiga saqlanadi."}
              </p>
            </li>
          </ul>
        </AdminCard>

        <PasswordForm />
      </div>
    </>
  );
}
