import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { deleteProductAction } from "@/actions/admin";
import { prisma } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { ImageManager } from "@/components/admin/image-manager";
import { AdminPageHeader } from "@/components/admin/page-header";
import { ProductForm } from "@/components/admin/product-form";
import { AdminCard, ConfirmButton } from "@/components/admin/ui";

export const metadata = { title: "Mahsulotni tahrirlash" };

type Props = {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function EditProductPage({ params, searchParams }: Props) {
  const { id } = await params;
  const { created } = await searchParams;
  const product = await prisma.product.findUnique({
    where: { id },
    include: { images: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] } },
  });
  if (!product) notFound();

  const deleteThis = deleteProductAction.bind(null, product.id);

  return (
    <>
      <Link href="/admin/products" className="mb-4 inline-flex items-center gap-2 text-sm text-muted hover:text-ink">
        <ArrowLeft className="size-4" /> Mahsulotlar
      </Link>
      <AdminPageHeader
        title={product.nameUz}
        description={created ? "Mahsulot yaratildi. Endi rasmlarni yuklang." : "Ma’lumotlarni tahrirlang va saqlang."}
        actions={
          <div className="flex gap-2">
            {product.published && (
              <Button asChild variant="outline" size="sm">
                <Link href={`/uz/products/${product.slug}`} target="_blank">
                  <ExternalLink /> Saytda ko‘rish
                </Link>
              </Button>
            )}
            <ConfirmButton
              action={deleteThis}
              confirmText="Mahsulot va uning rasmlari butunlay o‘chiriladi. Davom etasizmi?"
              variant="danger"
            >
              O‘chirish
            </ConfirmButton>
          </div>
        }
      />

      <AdminCard
        title="Rasmlar"
        description="Birinchi rasm katalogda asosiy rasm sifatida chiqadi. Barcha rasmlar bir xil nisbatda (masalan, 4:3, oq fon) bo‘lsa, katalog chiroyli ko‘rinadi."
        className="mb-6"
      >
        <ImageManager
          productId={product.id}
          images={product.images.map((i) => ({ id: i.id, url: i.url, alt: i.alt }))}
        />
      </AdminCard>

      <ProductForm
        initial={{
          id: product.id,
          slug: product.slug,
          nameUz: product.nameUz,
          nameRu: product.nameRu,
          nameEn: product.nameEn,
          descriptionUz: product.descriptionUz,
          descriptionRu: product.descriptionRu,
          descriptionEn: product.descriptionEn,
          lengthMm: product.lengthMm,
          widthMm: product.widthMm,
          heightMm: product.heightMm,
          isStandard: product.isStandard,
          isCustomSize: product.isCustomSize,
          material: product.material,
          condition: product.condition,
          availability: product.availability,
          loadCapacityKg: product.loadCapacityKg,
          price: product.price,
          isDemo: product.isDemo,
          published: product.published,
          featured: product.featured,
          sortOrder: product.sortOrder,
        }}
      />
    </>
  );
}
