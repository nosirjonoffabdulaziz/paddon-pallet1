import Image from "next/image";
import Link from "next/link";
import { Pencil, Plus } from "lucide-react";
import { prisma } from "@/lib/db";
import { formatDimensions, formatNumber } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AdminPageHeader } from "@/components/admin/page-header";
import { AVAILABILITY_LABELS, CONDITION_LABELS, MATERIAL_LABELS } from "@/components/admin/labels";
import { PublishToggle } from "@/components/admin/publish-toggle";

export const metadata = { title: "Mahsulotlar" };

export default async function AdminProductsPage() {
  const products = await prisma.product.findMany({
    orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
    include: { images: { orderBy: { sortOrder: "asc" }, take: 1 }, _count: { select: { orders: true } } },
  });

  return (
    <>
      <AdminPageHeader
        title="Mahsulotlar"
        description="Katalogdagi palletlar. Nomi, o‘lchami, narxi va rasmlarini tahrirlang."
        actions={
          <Button asChild>
            <Link href="/admin/products/new">
              <Plus /> Yangi mahsulot
            </Link>
          </Button>
        }
      />

      {products.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line bg-card p-12 text-center">
          <p className="font-semibold">Hozircha mahsulot yo‘q</p>
          <p className="mt-1 text-sm text-muted">Birinchi mahsulotni qo‘shing yoki `npm run db:seed` bilan demo ma’lumot yuklang.</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-line bg-card shadow-soft">
          <ul className="divide-y divide-line">
            {products.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center gap-4 px-4 py-4 sm:flex-nowrap sm:px-5">
                <div className="relative size-16 shrink-0 overflow-hidden rounded-xl border border-line bg-white">
                  {p.images[0] ? (
                    <Image src={p.images[0].url} alt="" fill sizes="64px" className="object-contain p-1" />
                  ) : (
                    <span className="grid size-full place-items-center text-[10px] text-muted">Rasm yo‘q</span>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link href={`/admin/products/${p.id}`} className="font-semibold hover:text-wood-dark">
                      {p.nameUz}
                    </Link>
                    {p.isDemo && <Badge variant="dark">Demo</Badge>}
                    {p.featured && <Badge variant="wood">Bosh sahifada</Badge>}
                    {!p.published && <Badge variant="outline">Yashirin</Badge>}
                  </div>
                  <p className="mt-1 text-xs text-muted">
                    {p.isCustomSize ? "Individual o‘lcham" : `${formatDimensions(p.lengthMm, p.widthMm, p.heightMm)} mm`} ·{" "}
                    {MATERIAL_LABELS[p.material]} · {CONDITION_LABELS[p.condition]} · {AVAILABILITY_LABELS[p.availability]} ·{" "}
                    {p.price ? `${formatNumber(p.price)} so‘m` : "Narx so‘raladi"}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <PublishToggle id={p.id} published={p.published} />
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/admin/products/${p.id}`}>
                      <Pencil /> Tahrirlash
                    </Link>
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </>
  );
}
