import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { AdminPageHeader } from "@/components/admin/page-header";
import { EMPTY_PRODUCT, ProductForm } from "@/components/admin/product-form";

export const metadata = { title: "Yangi mahsulot" };

export default function NewProductPage() {
  return (
    <>
      <Link href="/admin/products" className="mb-4 inline-flex items-center gap-2 text-sm text-muted hover:text-ink">
        <ArrowLeft className="size-4" /> Mahsulotlar
      </Link>
      <AdminPageHeader
        title="Yangi mahsulot"
        description="Saqlangandan so‘ng rasmlarni yuklash bo‘limi ochiladi."
      />
      <ProductForm initial={EMPTY_PRODUCT} />
    </>
  );
}
