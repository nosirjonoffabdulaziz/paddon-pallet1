import type { Metadata } from "next";
import type { ReactNode } from "react";
import { LogOut } from "lucide-react";
import { logoutAction } from "@/actions/admin";
import { requireAdmin } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { AdminSidebar } from "@/components/admin/sidebar";

export const metadata: Metadata = {
  title: { default: "Admin panel", template: "%s — Admin" },
  robots: { index: false, follow: false },
};
export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const admin = await requireAdmin();
  const [orders, messages] = await Promise.all([
    prisma.order.count({ where: { status: "NEW" } }),
    prisma.contactMessage.count({ where: { isRead: false } }),
  ]);

  return (
    <div className="min-h-dvh bg-bg">
      <AdminSidebar email={admin.email} counts={{ orders, messages }} />
      <div className="lg:pl-64">
        <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-10 lg:py-10">{children}</div>
        <form action={logoutAction} className="px-4 pb-8 lg:hidden">
          <button type="submit" className="inline-flex items-center gap-2 text-sm text-danger">
            <LogOut className="size-4" /> Chiqish ({admin.email})
          </button>
        </form>
      </div>
    </div>
  );
}
