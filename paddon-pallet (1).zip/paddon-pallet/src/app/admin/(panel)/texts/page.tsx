import { prisma } from "@/lib/db";
import { flatten } from "@/i18n/flatten";
import { baseDictionaries } from "@/i18n/get-dictionary";
import { AdminPageHeader } from "@/components/admin/page-header";
import { TextsEditor, type TextGroup } from "@/components/admin/texts-editor";

export const metadata = { title: "Sayt matnlari" };

const GROUP_LABELS: Record<string, string> = {
  meta: "Brend va SEO",
  nav: "Menyu",
  header: "Sarlavha (header)",
  common: "Umumiy so‘zlar",
  hero: "Bosh ekran (hero)",
  home: "Bosh sahifa bo‘limlari",
  products: "Katalog",
  labels: "Material, holat, mavjudlik nomlari",
  sizes: "O‘lchamlar bo‘limi",
  order: "Buyurtma konfiguratori",
  about: "Biz haqimizda",
  contact: "Bog‘lanish",
  errors: "Xatolik xabarlari",
  footer: "Pastki qism (footer)",
};

export default async function TextsPage() {
  const overrides = await prisma.siteText.findMany();
  const byKey = new Map(overrides.map((o) => [o.key, o]));
  const uz = flatten(baseDictionaries.uz);
  const ru = flatten(baseDictionaries.ru);
  const en = flatten(baseDictionaries.en);

  const groups: TextGroup[] = Object.keys(baseDictionaries.uz).map((id) => ({
    id,
    label: GROUP_LABELS[id] ?? id,
    items: Object.keys(uz)
      .filter((key) => key.split(".")[0] === id)
      .map((key) => {
        const o = byKey.get(key);
        return {
          key,
          defaults: { uz: uz[key] ?? "", ru: ru[key] ?? "", en: en[key] ?? "" },
          values: {
            uz: o?.uz || uz[key] || "",
            ru: o?.ru || ru[key] || "",
            en: o?.en || en[key] || "",
          },
          overridden: Boolean(o && (o.uz || o.ru || o.en)),
        };
      }),
  }));

  return (
    <>
      <AdminPageHeader
        title="Sayt matnlari"
        description="Saytdagi barcha yozuvlarni uch tilda o‘zgartiring. Saqlangan matn darhol saytda ko‘rinadi. {count} kabi qavsdagi so‘zlarni o‘chirmang — ular avtomatik to‘ldiriladi."
      />
      <TextsEditor groups={groups} />
    </>
  );
}
