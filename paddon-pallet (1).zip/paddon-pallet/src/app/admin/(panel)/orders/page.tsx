import Link from "next/link";
import { Phone } from "lucide-react";
import { deleteOrderAction } from "@/actions/admin";
import { prisma } from "@/lib/db";
import { ORDER_STATUSES, type OrderStatusValue } from "@/lib/catalog-options";
import { cn, formatDimensions, phoneHref } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { AdminPageHeader } from "@/components/admin/page-header";
import {
  CONDITION_LABELS,
  MATERIAL_LABELS,
  ORDER_STATUS_LABELS,
  formatDate,
  orderStatusVariant,
} from "@/components/admin/labels";
import { OrderNote, OrderStatusSelect } from "@/components/admin/order-controls";
import { ConfirmButton } from "@/components/admin/ui";

export const metadata = { title: "Buyurtmalar" };

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function OrdersPage({ searchParams }: Props) {
  const raw = (await searchParams).status;
  const status = (ORDER_STATUSES as readonly string[]).includes(String(raw)) ? (raw as OrderStatusValue) : null;

  const [orders, counts] = await Promise.all([
    prisma.order.findMany({
      where: status ? { status } : undefined,
      orderBy: { createdAt: "desc" },
      take: 200,
    }),
    prisma.order.groupBy({ by: ["status"], _count: { _all: true } }),
  ]);
  const countOf = (s: OrderStatusValue) => counts.find((c) => c.status === s)?._count._all ?? 0;
  const total = counts.reduce((sum, c) => sum + c._count._all, 0);

  const tab = (href: string, label: string, count: number, active: boolean) => (
    <Link
      key={href}
      href={href}
      className={cn(
        "inline-flex shrink-0 items-center gap-2 rounded-full border px-3.5 py-1.5 text-sm font-medium transition",
        active ? "border-ink bg-ink text-white" : "border-line bg-card hover:border-ink/30",
      )}
    >
      {label} <span className={cn("text-xs", active ? "text-white/60" : "text-muted")}>{count}</span>
    </Link>
  );

  return (
    <>
      <AdminPageHeader
        title="Buyurtmalar"
        description="Konfigurator va mahsulot sahifalaridan kelgan buyurtmalar. Statusni o‘zgartiring va izoh qoldiring."
      />
      <div className="mb-6 flex gap-2 overflow-x-auto pb-1">
        {tab("/admin/orders", "Barchasi", total, !status)}
        {ORDER_STATUSES.map((s) => tab(`/admin/orders?status=${s}`, ORDER_STATUS_LABELS[s], countOf(s), status === s))}
      </div>

      {orders.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line bg-card p-12 text-center text-sm text-muted">
          Bu bo‘limda buyurtma yo‘q.
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((o) => (
            <article key={o.id} className="rounded-2xl border border-line bg-card p-5 shadow-soft">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-lg font-bold">#{o.number}</h2>
                    <Badge variant={orderStatusVariant(o.status)}>{ORDER_STATUS_LABELS[o.status]}</Badge>
                    <Badge variant="outline">{o.source === "PRODUCT" ? "Mahsulotdan" : "Konfigurator"}</Badge>
                    <span className="text-xs text-muted">{formatDate(o.createdAt)}</span>
                  </div>
                  <p className="mt-2 text-sm">
                    <b>{o.customerName}</b> ·{" "}
                    <a href={phoneHref(o.phone)} className="inline-flex items-center gap-1 text-wood-dark hover:underline">
                      <Phone className="size-3.5" /> {o.phone}
                    </a>{" "}
                    · <span className="uppercase text-muted">{o.locale}</span>
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <OrderStatusSelect id={o.id} status={o.status} />
                  <ConfirmButton action={deleteOrderAction.bind(null, o.id)} confirmText="Buyurtmani o‘chirasizmi?" title="O‘chirish" />
                </div>
              </div>

              <dl className="mt-4 grid gap-x-6 gap-y-2 rounded-xl bg-sand/50 p-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
                <Item label="Mahsulot" value={o.productName ?? "Maxsus o‘lcham"} />
                <Item label="O‘lcham (mm)" value={formatDimensions(o.lengthMm, o.widthMm, o.heightMm) ?? "—"} />
                <Item label="Soni" value={`${o.quantity} dona`} />
                <Item
                  label="Yog‘och / holati"
                  value={`${o.woodType ? MATERIAL_LABELS[o.woodType] : "—"} / ${o.condition ? CONDITION_LABELS[o.condition] : "—"}`}
                />
              </dl>
              {o.notes && (
                <p className="mt-3 whitespace-pre-line rounded-xl border border-line px-4 py-3 text-sm">
                  <span className="mb-1 block text-xs text-muted">Mijoz izohi</span>
                  {o.notes}
                </p>
              )}
              <OrderNote id={o.id} note={o.adminNote} />
            </article>
          ))}
        </div>
      )}
    </>
  );
}

function Item({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="font-medium">{value}</dd>
    </div>
  );
}
