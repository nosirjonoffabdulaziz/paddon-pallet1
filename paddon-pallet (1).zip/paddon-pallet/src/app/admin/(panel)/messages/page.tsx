import { Phone } from "lucide-react";
import { deleteMessageAction } from "@/actions/admin";
import { prisma } from "@/lib/db";
import { cn, phoneHref } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { AdminPageHeader } from "@/components/admin/page-header";
import { formatDate } from "@/components/admin/labels";
import { MarkReadButton } from "@/components/admin/mark-read-button";
import { ConfirmButton } from "@/components/admin/ui";

export const metadata = { title: "Xabarlar" };

export default async function MessagesPage() {
  const messages = await prisma.contactMessage.findMany({ orderBy: { createdAt: "desc" }, take: 200 });

  return (
    <>
      <AdminPageHeader title="Xabarlar" description="“Bog‘lanish” sahifasidagi forma orqali kelgan murojaatlar." />
      {messages.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line bg-card p-12 text-center text-sm text-muted">
          Hozircha xabarlar yo‘q.
        </div>
      ) : (
        <div className="space-y-3">
          {messages.map((m) => (
            <article
              key={m.id}
              className={cn(
                "rounded-2xl border bg-card p-5 shadow-soft",
                m.isRead ? "border-line" : "border-wood/40 ring-4 ring-wood/5",
              )}
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-semibold">{m.name}</h2>
                    {!m.isRead && <Badge variant="wood">Yangi</Badge>}
                    <span className="text-xs text-muted">{formatDate(m.createdAt)}</span>
                    <span className="text-xs uppercase text-muted">{m.locale}</span>
                  </div>
                  <a href={phoneHref(m.phone)} className="mt-1 inline-flex items-center gap-1 text-sm text-wood-dark hover:underline">
                    <Phone className="size-3.5" /> {m.phone}
                  </a>
                </div>
                <div className="flex items-center gap-1">
                  <MarkReadButton id={m.id} isRead={m.isRead} />
                  <ConfirmButton action={deleteMessageAction.bind(null, m.id)} confirmText="Xabarni o‘chirasizmi?" title="O‘chirish" />
                </div>
              </div>
              <p className="mt-3 whitespace-pre-line text-sm leading-relaxed">{m.message}</p>
            </article>
          ))}
        </div>
      )}
    </>
  );
}
