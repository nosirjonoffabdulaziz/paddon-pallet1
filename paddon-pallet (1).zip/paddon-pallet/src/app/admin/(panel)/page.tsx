import Link from "next/link";
import { AlertTriangle, ArrowRight, CheckCircle2, Mail, Package, ShoppingCart } from "lucide-react";
import { prisma } from "@/lib/db";
import { isBlobConfigured } from "@/lib/storage";
import { isTelegramConfigured } from "@/lib/telegram";
import { getSettings } from "@/lib/settings";
import { formatDimensions } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { AdminPageHeader } from "@/components/admin/page-header";
import { ORDER_STATUS_LABELS, orderStatusVariant } from "@/components/admin/labels";

export default async function AdminDashboard() {
  const [products, demoProducts, newOrders, totalOrders, unread, recent, settings] = await Promise.all([
    prisma.product.count(),
    prisma.product.count({ where: { isDemo: true } }),
    prisma.order.count({ where: { status: "NEW" } }),
    prisma.order.count(),
    prisma.contactMessage.count({ where: { isRead: false } }),
    prisma.order.findMany({ orderBy: { createdAt: "desc" }, take: 6 }),
    getSettings(),
  ]);

  const checklist = [
    { ok: Boolean(settings.phone || settings.telegram), label: "Kontaktlar (telefon / Telegram) kiritilgan", href: "/admin/settings" },
    { ok: Boolean(settings.address_uz), label: "Kompaniya manzili kiritilgan", href: "/admin/settings" },
    { ok: demoProducts === 0, label: "Demo mahsulotlar haqiqiy ma’lumot bilan almashtirilgan", href: "/admin/products" },
    { ok: isTelegramConfigured(), label: "Telegram xabarnomalar ulangan (TELEGRAM_BOT_TOKEN)", href: "/admin/settings" },
    { ok: isBlobConfigured() || !process.env.VERCEL, label: "Rasm saqlash xizmati (Vercel Blob) ulangan", href: "/admin/settings" },
  ];

  const stats = [
    { label: "Yangi buyurtmalar", value: newOrders, icon: ShoppingCart, href: "/admin/orders?status=NEW" },
    { label: "Jami buyurtmalar", value: totalOrders, icon: ShoppingCart, href: "/admin/orders" },
    { label: "O‘qilmagan xabarlar", value: unread, icon: Mail, href: "/admin/messages" },
    { label: "Mahsulotlar", value: products, icon: Package, href: "/admin/products" },
  ];

  return (
    <>
      <AdminPageHeader title="Boshqaruv paneli" description="Buyurtmalar, mahsulotlar va sayt sozlamalari bir joyda." />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map(({ label, value, icon: Icon, href }) => (
          <Link
            key={label}
            href={href}
            className="group rounded-2xl border border-line bg-card p-5 shadow-soft transition hover:-translate-y-0.5 hover:shadow-lift"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted">{label}</span>
              <Icon className="size-4 text-wood" />
            </div>
            <p className="mt-3 font-display text-3xl font-bold">{value}</p>
          </Link>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <section className="rounded-2xl border border-line bg-card shadow-soft">
          <div className="flex items-center justify-between border-b border-line px-5 py-4">
            <h2 className="font-display font-bold">So‘nggi buyurtmalar</h2>
            <Link href="/admin/orders" className="inline-flex items-center gap-1 text-sm font-medium text-wood-dark">
              Barchasi <ArrowRight className="size-3.5" />
            </Link>
          </div>
          {recent.length === 0 ? (
            <p className="px-5 py-10 text-center text-sm text-muted">Hozircha buyurtmalar yo‘q.</p>
          ) : (
            <ul className="divide-y divide-line">
              {recent.map((o) => (
                <li key={o.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 text-sm">
                  <div>
                    <p className="font-semibold">
                      #{o.number} · {o.customerName}
                    </p>
                    <p className="text-xs text-muted">
                      {o.productName ?? "Maxsus o‘lcham"} · {formatDimensions(o.lengthMm, o.widthMm, o.heightMm) ?? "—"} mm ·{" "}
                      {o.quantity} dona
                    </p>
                  </div>
                  <Badge variant={orderStatusVariant(o.status)}>{ORDER_STATUS_LABELS[o.status]}</Badge>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-2xl border border-line bg-card p-5 shadow-soft">
          <h2 className="font-display font-bold">Saytni ishga tayyorlash</h2>
          <p className="mt-1 text-sm text-muted">Haqiqiy ma’lumotlar to‘liq kiritilganini tekshiring.</p>
          <ul className="mt-5 space-y-3">
            {checklist.map((item) => (
              <li key={item.label}>
                <Link href={item.href} className="flex items-start gap-3 text-sm hover:text-wood-dark">
                  {item.ok ? (
                    <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" />
                  ) : (
                    <AlertTriangle className="mt-0.5 size-4 shrink-0 text-warning" />
                  )}
                  <span className={item.ok ? "text-muted" : "font-medium"}>{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </>
  );
}
