import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getAdminSession } from "@/lib/auth";
import { LogoMark } from "@/components/site/logo";
import { LoginForm } from "@/components/admin/login-form";

export const metadata: Metadata = { title: "Admin — kirish", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const admin = await getAdminSession().catch(() => null);
  if (admin) redirect("/admin");

  return (
    <main className="bg-blueprint flex min-h-dvh items-center justify-center px-5 py-12">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <LogoMark className="size-12" />
          <h1 className="mt-5 font-display text-2xl font-bold">Admin panel</h1>
          <p className="mt-1 text-sm text-muted">PALLET boshqaruv paneliga kirish</p>
        </div>
        <LoginForm />
      </div>
    </main>
  );
}
