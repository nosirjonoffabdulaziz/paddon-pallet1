import Link from "next/link";

// Til prefiksi bo‘lmagan noma’lum manzillar uchun (masalan, /admin/xyz).
export default function RootNotFound() {
  return (
    <section className="flex min-h-dvh flex-col items-center justify-center px-6 text-center">
      <p className="font-display text-[120px] font-extrabold leading-none tracking-tighter text-wood/25">404</p>
      <h1 className="mt-4 font-display text-2xl font-bold">Sahifa topilmadi</h1>
      <Link href="/" className="mt-6 rounded-full bg-ink px-6 py-3 text-sm font-medium text-white">
        Bosh sahifa
      </Link>
    </section>
  );
}
