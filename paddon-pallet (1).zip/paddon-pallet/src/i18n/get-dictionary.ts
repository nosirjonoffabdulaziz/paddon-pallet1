import "server-only";
import { cache } from "react";
import { prisma } from "@/lib/db";
import type { Locale } from "@/lib/i18n";
import en from "./dictionaries/en";
import ru from "./dictionaries/ru";
import uz, { type Dictionary } from "./dictionaries/uz";
import { setPath, type Tree } from "./flatten";

export const baseDictionaries: Record<Locale, Dictionary> = { uz, ru, en };

/**
 * Joriy til lug‘ati: fayldagi standart matn + admin panelda tahrirlangan matnlar.
 * Ma’lumotlar bazasi ishlamasa ham sayt standart matnlar bilan ochiladi.
 */
export const getDictionary = cache(async (locale: Locale): Promise<Dictionary> => {
  const dict = structuredClone(baseDictionaries[locale]) as Dictionary;
  try {
    const overrides = await prisma.siteText.findMany();
    for (const row of overrides) {
      const value = row[locale];
      if (value && value.trim()) setPath(dict as unknown as Tree, row.key, value);
    }
  } catch (error) {
    console.error("Site text overrides could not be loaded:", error);
  }
  return dict;
});

export type { Dictionary };
