// Lug‘atni "hero.title" kabi kalitlarga yoyish va qayta yig‘ish yordamchilari.
type Tree = { [key: string]: string | Tree };

export function flatten(tree: Tree, prefix = ""): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [key, value] of Object.entries(tree)) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (typeof value === "string") out[path] = value;
    else Object.assign(out, flatten(value, path));
  }
  return out;
}

export function setPath(tree: Tree, path: string, value: string) {
  const parts = path.split(".");
  let node: Tree = tree;
  for (let i = 0; i < parts.length - 1; i++) {
    const next = node[parts[i]!];
    if (typeof next !== "object" || next === null) return; // noma’lum kalit — e’tiborsiz
    node = next;
  }
  const last = parts[parts.length - 1]!;
  if (typeof node[last] === "string") node[last] = value;
}

export type { Tree };
