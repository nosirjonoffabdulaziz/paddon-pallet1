import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** "{count} ta" kabi shablonlarga qiymat qo‘yadi. */
export function format(template: string, vars: Record<string, string | number>) {
  return template.replace(/\{(\w+)\}/g, (_, key: string) =>
    key in vars ? String(vars[key]) : `{${key}}`,
  );
}

const numberFormatter = new Intl.NumberFormat("ru-RU");

export function formatNumber(value: number) {
  // ru-RU formati bo‘sh joy bilan ajratadi: 1 200 000
  return numberFormatter.format(value).replace(/ /g, " ");
}

export function formatDimensions(length?: number | null, width?: number | null, height?: number | null) {
  if (!length || !width) return null;
  return height ? `${length} × ${width} × ${height}` : `${length} × ${width}`;
}

export function slugify(input: string) {
  const map: Record<string, string> = {
    "‘": "", "’": "", "ʻ": "", "ʼ": "", "'": "",
    а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "yo", ж: "j", з: "z", и: "i", й: "y",
    к: "k", л: "l", м: "m", н: "n", о: "o", п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f",
    х: "x", ц: "ts", ч: "ch", ш: "sh", щ: "sh", ъ: "", ы: "i", ь: "", э: "e", ю: "yu", я: "ya",
    ў: "o", қ: "q", ғ: "g", ҳ: "h",
  };
  return input
    .toLowerCase()
    .split("")
    .map((ch) => map[ch] ?? ch)
    .join("")
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

/** Telefon raqamini "tel:" havolasi uchun tozalaydi. */
export function phoneHref(phone: string) {
  return `tel:${phone.replace(/[^\d+]/g, "")}`;
}

/** "@username", "t.me/username" yoki to‘liq havolani https://t.me/... ko‘rinishiga keltiradi. */
export function telegramHref(value: string) {
  const v = value.trim();
  if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  const username = v.replace(/^@/, "").replace(/^(t\.me|telegram\.me)\//i, "");
  return `https://t.me/${username}`;
}

export function telegramLabel(value: string) {
  const v = value.trim();
  const match = v.match(/(?:t\.me|telegram\.me)\/([\w\d_]+)/i);
  if (match) return `@${match[1]}`;
  return v.startsWith("@") ? v : `@${v}`;
}
