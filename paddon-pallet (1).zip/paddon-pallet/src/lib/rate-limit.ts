import "server-only";
import { headers } from "next/headers";

/**
 * Oddiy xotiradagi so‘rov cheklagichi (spam va parol tanlashdan himoya).
 * Serverless muhitda har bir instansiya alohida hisoblaydi — kichik sayt uchun yetarli.
 * Katta trafik uchun Upstash Redis kabi tashqi xizmatga almashtirish mumkin.
 */
const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    if (buckets.size > 5000) {
      for (const [k, v] of buckets) if (v.resetAt < now) buckets.delete(k);
    }
    return { ok: true };
  }
  bucket.count += 1;
  return { ok: bucket.count <= limit };
}

export async function getClientIp() {
  const h = await headers();
  const forwarded = h.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]!.trim();
  return h.get("x-real-ip") ?? "unknown";
}
