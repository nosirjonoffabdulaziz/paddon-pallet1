import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { SESSION_COOKIE, SESSION_MAX_AGE, signSession, verifySession } from "@/lib/session";

export async function getAdminSession() {
  const store = await cookies();
  const session = await verifySession(store.get(SESSION_COOKIE)?.value);
  if (!session) return null;
  // Foydalanuvchi o‘chirilgan bo‘lsa, sessiya ham yaroqsiz.
  const user = await prisma.adminUser.findUnique({
    where: { id: session.sub },
    select: { id: true, email: true },
  });
  return user;
}

/** Server komponent va server action'larda chaqiriladi. Kirmagan bo‘lsa — login sahifasiga. */
export async function requireAdmin() {
  const admin = await getAdminSession();
  if (!admin) redirect("/admin/login");
  return admin;
}

export async function createSessionCookie(user: { id: string; email: string }) {
  const token = await signSession({ sub: user.id, email: user.email });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}
