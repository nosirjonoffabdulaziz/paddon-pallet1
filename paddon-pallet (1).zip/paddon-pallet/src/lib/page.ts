import "server-only";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { isLocale, locales, type Locale } from "@/lib/i18n";

export type LocaleParams = { params: Promise<{ locale: string }> };

export async function resolveLocale(params: Promise<{ locale: string }>): Promise<Locale> {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return locale;
}

/** Har bir til uchun hreflang havolalari (SEO). path — "/products" kabi, til prefiksisiz. */
export function pageMetadata(locale: Locale, path: string, title: string, description?: string): Metadata {
  const languages = Object.fromEntries(locales.map((l) => [l, `/${l}${path}`]));
  return {
    title,
    description,
    alternates: { canonical: `/${locale}${path}`, languages: { ...languages, "x-default": `/uz${path}` } },
    openGraph: { title, description, url: `/${locale}${path}`, locale, type: "website" },
  };
}
