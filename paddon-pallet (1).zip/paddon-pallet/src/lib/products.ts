import "server-only";
import type { Prisma, Product, ProductImage } from "@prisma/client";
import { prisma } from "@/lib/db";
import {
  AVAILABILITIES,
  CONDITIONS,
  MATERIALS,
  type AvailabilityValue,
  type ConditionValue,
  type MaterialValue,
} from "@/lib/catalog-options";
import { localizedField, type Locale } from "@/lib/i18n";
import type { ProductDTO } from "@/lib/types";

type ProductWithImages = Product & { images: ProductImage[] };

export function toProductDTO(product: ProductWithImages, locale: Locale): ProductDTO {
  const name = localizedField(product, "name", locale);
  return {
    id: product.id,
    slug: product.slug,
    name,
    description: localizedField(product, "description", locale),
    lengthMm: product.lengthMm,
    widthMm: product.widthMm,
    heightMm: product.heightMm,
    isStandard: product.isStandard,
    isCustomSize: product.isCustomSize,
    material: product.material,
    condition: product.condition,
    loadCapacityKg: product.loadCapacityKg,
    availability: product.availability,
    price: product.price,
    isDemo: product.isDemo,
    images: [...product.images]
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map((img) => ({ url: img.url, alt: img.alt || name })),
  };
}

// ------------------------------------------------------------------
// Katalog filtrlari (URL query parametrlaridan o‘qiladi)
// ------------------------------------------------------------------
export const SORT_OPTIONS = ["default", "price_asc", "price_desc", "size_asc", "size_desc"] as const;
export type SortOption = (typeof SORT_OPTIONS)[number];

export type CatalogFilters = {
  q: string;
  size: string; // "1200x800" yoki "custom"
  sizeType: "" | "standard" | "custom";
  condition: ConditionValue | "";
  materials: MaterialValue[];
  capacity: number | null;
  priceMin: number | null;
  priceMax: number | null;
  availability: AvailabilityValue | "";
  sort: SortOption;
};

type RawParams = Record<string, string | string[] | undefined>;

const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";
const toInt = (v: string) => {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) && n >= 0 ? n : null;
};
const oneOf = <T extends string>(list: readonly T[], v: string): T | "" =>
  (list as readonly string[]).includes(v) ? (v as T) : "";

export function parseCatalogFilters(params: RawParams): CatalogFilters {
  const materials = first(params.material)
    .split(",")
    .filter((m): m is MaterialValue => (MATERIALS as readonly string[]).includes(m));
  const sizeType = first(params.type);
  const sort = first(params.sort);
  return {
    q: first(params.q).trim().slice(0, 80),
    size: /^(\d{2,5}x\d{2,5}|custom)$/.test(first(params.size)) ? first(params.size) : "",
    sizeType: sizeType === "standard" || sizeType === "custom" ? sizeType : "",
    condition: oneOf(CONDITIONS, first(params.condition)),
    materials,
    capacity: toInt(first(params.capacity)),
    priceMin: toInt(first(params.min)),
    priceMax: toInt(first(params.max)),
    availability: oneOf(AVAILABILITIES, first(params.availability)),
    sort: (SORT_OPTIONS as readonly string[]).includes(sort) ? (sort as SortOption) : "default",
  };
}

function buildWhere(f: CatalogFilters): Prisma.ProductWhereInput {
  const and: Prisma.ProductWhereInput[] = [{ published: true }];

  if (f.q) {
    const dims = f.q.match(/(\d{3,4})\s*[x×*хX]\s*(\d{3,4})/);
    const or: Prisma.ProductWhereInput[] = [
      { nameUz: { contains: f.q, mode: "insensitive" } },
      { nameRu: { contains: f.q, mode: "insensitive" } },
      { nameEn: { contains: f.q, mode: "insensitive" } },
      { descriptionUz: { contains: f.q, mode: "insensitive" } },
      { descriptionRu: { contains: f.q, mode: "insensitive" } },
      { descriptionEn: { contains: f.q, mode: "insensitive" } },
    ];
    if (dims) {
      const a = Number(dims[1]);
      const b = Number(dims[2]);
      or.push({ lengthMm: a, widthMm: b }, { lengthMm: b, widthMm: a });
    } else if (/^\d{3,4}$/.test(f.q)) {
      const n = Number(f.q);
      or.push({ lengthMm: n }, { widthMm: n }, { heightMm: n });
    }
    and.push({ OR: or });
  }

  if (f.size === "custom") and.push({ isCustomSize: true });
  else if (f.size) {
    const [l, w] = f.size.split("x").map(Number);
    and.push({ lengthMm: l, widthMm: w });
  }
  if (f.sizeType === "standard") and.push({ isStandard: true });
  if (f.sizeType === "custom") and.push({ isStandard: false });
  if (f.condition) and.push({ condition: f.condition });
  if (f.materials.length) and.push({ material: { in: f.materials } });
  if (f.capacity) and.push({ loadCapacityKg: { gte: f.capacity } });
  if (f.priceMin !== null) and.push({ price: { gte: f.priceMin } });
  if (f.priceMax !== null) and.push({ price: { lte: f.priceMax } });
  if (f.availability) and.push({ availability: f.availability });

  return { AND: and };
}

function buildOrder(sort: SortOption): Prisma.ProductOrderByWithRelationInput[] {
  switch (sort) {
    case "price_asc":
      return [{ price: { sort: "asc", nulls: "last" } }, { sortOrder: "asc" }];
    case "price_desc":
      return [{ price: { sort: "desc", nulls: "last" } }, { sortOrder: "asc" }];
    case "size_asc":
      return [{ lengthMm: { sort: "asc", nulls: "last" } }, { widthMm: { sort: "asc", nulls: "last" } }];
    case "size_desc":
      return [{ lengthMm: { sort: "desc", nulls: "last" } }, { widthMm: { sort: "desc", nulls: "last" } }];
    default:
      return [{ featured: "desc" }, { sortOrder: "asc" }, { createdAt: "desc" }];
  }
}

export async function getCatalog(filters: CatalogFilters, locale: Locale) {
  const products = await prisma.product.findMany({
    where: buildWhere(filters),
    orderBy: buildOrder(filters.sort),
    include: { images: true },
  });
  return products.map((p) => toProductDTO(p, locale));
}

/** Filtr panelida faqat mavjud qiymatlar ko‘rsatiladi. */
export async function getCatalogFacets() {
  const all = await prisma.product.findMany({
    where: { published: true },
    select: {
      lengthMm: true,
      widthMm: true,
      isCustomSize: true,
      material: true,
      loadCapacityKg: true,
      price: true,
    },
  });
  const sizes = new Map<string, { l: number; w: number }>();
  let hasCustom = false;
  for (const p of all) {
    if (p.isCustomSize || !p.lengthMm || !p.widthMm) hasCustom ||= p.isCustomSize;
    else sizes.set(`${p.lengthMm}x${p.widthMm}`, { l: p.lengthMm, w: p.widthMm });
  }
  const prices = all.map((p) => p.price).filter((v): v is number => v !== null);
  return {
    sizes: [...sizes.entries()]
      .sort((a, b) => a[1].l * a[1].w - b[1].l * b[1].w)
      .map(([key, v]) => ({ key, label: `${v.l} × ${v.w}` })),
    hasCustom,
    materials: MATERIALS.filter((m) => all.some((p) => p.material === m)),
    hasCapacity: all.some((p) => p.loadCapacityKg !== null),
    priceRange: prices.length ? { min: Math.min(...prices), max: Math.max(...prices) } : null,
  };
}

export async function getFeaturedProducts(locale: Locale, take = 4) {
  const products = await prisma.product.findMany({
    where: { published: true },
    orderBy: [{ featured: "desc" }, { sortOrder: "asc" }],
    include: { images: true },
    take,
  });
  return products.map((p) => toProductDTO(p, locale));
}

export async function getProductBySlug(slug: string, locale: Locale) {
  const product = await prisma.product.findFirst({
    where: { slug, published: true },
    include: { images: true },
  });
  return product ? toProductDTO(product, locale) : null;
}

export async function getRelatedProducts(excludeId: string, locale: Locale, take = 3) {
  const products = await prisma.product.findMany({
    where: { published: true, id: { not: excludeId } },
    orderBy: [{ featured: "desc" }, { sortOrder: "asc" }],
    include: { images: true },
    take,
  });
  return products.map((p) => toProductDTO(p, locale));
}

/** O‘lchamlar bo‘limi uchun: mahsulotlardagi barcha o‘lchamlar (standart / maxsus). */
export async function getSizePresets() {
  const rows = await prisma.product.findMany({
    where: { published: true, isCustomSize: false, lengthMm: { not: null }, widthMm: { not: null } },
    select: { lengthMm: true, widthMm: true, heightMm: true, isStandard: true },
    orderBy: [{ sortOrder: "asc" }],
  });
  const seen = new Set<string>();
  const presets: { length: number; width: number; height: number; standard: boolean }[] = [];
  for (const r of rows) {
    const key = `${r.lengthMm}x${r.widthMm}`;
    if (seen.has(key) || !r.lengthMm || !r.widthMm) continue;
    seen.add(key);
    presets.push({ length: r.lengthMm, width: r.widthMm, height: r.heightMm ?? 144, standard: r.isStandard });
  }
  return presets;
}
