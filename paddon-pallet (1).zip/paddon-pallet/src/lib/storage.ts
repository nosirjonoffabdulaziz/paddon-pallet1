import "server-only";
import { randomBytes } from "node:crypto";
import { mkdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { del, put } from "@vercel/blob";

export const ALLOWED_IMAGE_TYPES: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/avif": "avif",
};
export const MAX_IMAGE_BYTES = 4 * 1024 * 1024; // 4 MB (Vercel limiti 4.5 MB)

/** Lokal yuklamalar papkasi (faqat Vercel Blob sozlanmaganda ishlatiladi). */
export const LOCAL_UPLOAD_DIR = path.join(process.cwd(), "uploads");

export class StorageError extends Error {
  constructor(public code: "type" | "size" | "not_configured" | "failed") {
    super(code);
  }
}

export function isBlobConfigured() {
  return Boolean(process.env.BLOB_READ_WRITE_TOKEN);
}

/**
 * Rasmni saqlaydi va ommaviy URL qaytaradi.
 *  - BLOB_READ_WRITE_TOKEN bo‘lsa → Vercel Blob (production uchun doimiy saqlash)
 *  - aks holda → ./uploads papkasi, /media/... orqali beriladi (lokal ishlab chiqish)
 */
export async function saveImage(file: File, folder: "products" | "site") {
  const ext = ALLOWED_IMAGE_TYPES[file.type];
  if (!ext) throw new StorageError("type");
  if (file.size > MAX_IMAGE_BYTES) throw new StorageError("size");

  const name = `${Date.now()}-${randomBytes(6).toString("hex")}.${ext}`;

  if (isBlobConfigured()) {
    try {
      const blob = await put(`${folder}/${name}`, file, {
        access: "public",
        contentType: file.type,
      });
      return blob.url;
    } catch (error) {
      console.error("Blob upload failed:", error);
      throw new StorageError("failed");
    }
  }

  // Vercel'da fayl tizimi vaqtinchalik — Blob'siz saqlab bo‘lmaydi.
  if (process.env.VERCEL) throw new StorageError("not_configured");

  const dir = path.join(LOCAL_UPLOAD_DIR, folder);
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, name), Buffer.from(await file.arrayBuffer()));
  return `/media/${folder}/${name}`;
}

/** Saqlangan rasmni o‘chiradi (statik /images/... fayllariga tegmaydi). */
export async function deleteImage(url: string) {
  try {
    if (url.includes(".blob.vercel-storage.com")) {
      if (isBlobConfigured()) await del(url);
      return;
    }
    if (url.startsWith("/media/")) {
      const relative = url.replace(/^\/media\//, "");
      const target = path.join(LOCAL_UPLOAD_DIR, relative);
      if (target.startsWith(LOCAL_UPLOAD_DIR)) await unlink(target);
    }
  } catch (error) {
    console.warn("Image delete skipped:", error);
  }
}
