export const locales = ["uz", "ru", "en"] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = "uz";
export const LOCALE_COOKIE = "NEXT_LOCALE";

export const localeLabels: Record<Locale, string> = {
  uz: "O‘zbekcha",
  ru: "Русский",
  en: "English",
};

export function isLocale(value: unknown): value is Locale {
  return typeof value === "string" && (locales as readonly string[]).includes(value);
}

/** Mahsulot kabi obyektdan joriy tildagi maydonni oladi: pick(p, "name", "ru") → p.nameRu */
export function localizedField<T extends Record<string, unknown>>(
  obj: T,
  base: string,
  locale: Locale,
): string {
  const suffix = locale.charAt(0).toUpperCase() + locale.slice(1);
  const value = obj[`${base}${suffix}`];
  if (typeof value === "string" && value.trim()) return value;
  const fallback = obj[`${base}Uz`];
  return typeof fallback === "string" ? fallback : "";
}
