import type { ProductDTO } from "@/lib/types";

/** Server va client komponentlarda birdek ishlatiladigan yordamchilar. */
export function availabilityVariant(a: ProductDTO["availability"]) {
  return a === "IN_STOCK" ? "success" : a === "ON_ORDER" ? "warning" : "danger";
}

export function productDims(p: Pick<ProductDTO, "lengthMm" | "widthMm" | "heightMm">) {
  if (!p.lengthMm || !p.widthMm) return null;
  return { length: p.lengthMm, width: p.widthMm, height: p.heightMm ?? 144 };
}
