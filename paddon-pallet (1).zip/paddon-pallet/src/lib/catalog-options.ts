// Prisma enum qiymatlari bilan bir xil bo‘lishi kerak (prisma/schema.prisma)
export const MATERIALS = ["PINE", "SPRUCE", "BIRCH", "HARDWOOD", "MIXED", "OTHER"] as const;
export const CONDITIONS = ["NEW", "USED"] as const;
export const AVAILABILITIES = ["IN_STOCK", "ON_ORDER", "OUT_OF_STOCK"] as const;
export const ORDER_STATUSES = ["NEW", "CONFIRMED", "IN_PRODUCTION", "DELIVERED", "CANCELLED"] as const;

export type MaterialValue = (typeof MATERIALS)[number];
export type ConditionValue = (typeof CONDITIONS)[number];
export type AvailabilityValue = (typeof AVAILABILITIES)[number];
export type OrderStatusValue = (typeof ORDER_STATUSES)[number];

/** Katalogdagi "yuk ko‘tarish quvvati" filtri uchun pog‘onalar (kg). */
export const CAPACITY_STEPS = [500, 1000, 1500, 2000] as const;

/** Konfigurator va o‘lchamlar bo‘limi chegaralari (mm). */
export const SIZE_LIMITS = {
  length: { min: 300, max: 3000, default: 1200 },
  width: { min: 300, max: 3000, default: 800 },
  height: { min: 80, max: 400, default: 144 },
  quantity: { min: 1, max: 100000, default: 50 },
} as const;
