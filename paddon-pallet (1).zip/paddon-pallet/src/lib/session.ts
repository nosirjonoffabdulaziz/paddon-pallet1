// Edge (middleware) va Node muhitida ishlaydigan sessiya yordamchilari.
import { SignJWT, jwtVerify } from "jose";

export const SESSION_COOKIE = "pallet_admin_session";
export const SESSION_MAX_AGE = 60 * 60 * 24 * 7; // 7 kun

export type SessionPayload = { sub: string; email: string };

function getSecret() {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 32) return null;
  return new TextEncoder().encode(secret);
}

export function isAuthConfigured() {
  return getSecret() !== null;
}

export async function signSession(payload: SessionPayload) {
  const secret = getSecret();
  if (!secret) throw new Error("AUTH_SECRET is missing or shorter than 32 characters");
  return new SignJWT({ email: payload.email })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(payload.sub)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_MAX_AGE}s`)
    .sign(secret);
}

export async function verifySession(token: string | undefined): Promise<SessionPayload | null> {
  const secret = getSecret();
  if (!token || !secret) return null;
  try {
    const { payload } = await jwtVerify(token, secret, { algorithms: ["HS256"] });
    if (typeof payload.sub !== "string" || typeof payload.email !== "string") return null;
    return { sub: payload.sub, email: payload.email };
  } catch {
    return null;
  }
}
