import "server-only";
import { cache } from "react";
import { prisma } from "@/lib/db";
import type { Locale } from "@/lib/i18n";

/**
 * Admin panel → "Sozlamalar" orqali kiritiladigan qiymatlar.
 * Hech qanday qiymat kodda yozilmaydi — bo‘sh bo‘lsa saytda ko‘rsatilmaydi.
 */
export const SETTING_KEYS = [
  "phone",
  "phone2",
  "telegram",
  "email",
  "address_uz",
  "address_ru",
  "address_en",
  "hours_uz",
  "hours_ru",
  "hours_en",
  "mapEmbedUrl",
  "heroImage",
  "aboutImage1",
  "aboutImage2",
  "aboutImage3",
] as const;

export type SettingKey = (typeof SETTING_KEYS)[number];
export type Settings = Record<SettingKey, string>;

export const IMAGE_SETTING_KEYS = ["heroImage", "aboutImage1", "aboutImage2", "aboutImage3"] as const;
export type ImageSettingKey = (typeof IMAGE_SETTING_KEYS)[number];

/** Sayt rasmlarining standart (admin almashtirmagan) qiymatlari. */
export const DEFAULT_SITE_IMAGES: Record<ImageSettingKey, string> = {
  heroImage: "/images/site/hero-pallet.webp",
  aboutImage1: "/images/site/warehouse.webp",
  aboutImage2: "/images/products/euro-pallet-1200x800.webp",
  aboutImage3: "/images/products/industrial-pallet-1200x1000.webp",
};

export function isSettingKey(value: string): value is SettingKey {
  return (SETTING_KEYS as readonly string[]).includes(value);
}

export const getSettings = cache(async (): Promise<Settings> => {
  const empty = Object.fromEntries(SETTING_KEYS.map((k) => [k, ""])) as Settings;
  try {
    const rows = await prisma.setting.findMany();
    for (const row of rows) if (isSettingKey(row.key)) empty[row.key] = row.value;
  } catch (error) {
    console.error("Settings could not be loaded:", error);
  }
  return empty;
});

export function siteImage(settings: Settings, key: ImageSettingKey) {
  return settings[key] || DEFAULT_SITE_IMAGES[key];
}

export type ContactInfo = {
  phone: string;
  phone2: string;
  telegram: string;
  email: string;
  address: string;
  hours: string;
  mapEmbedUrl: string;
};

/** Joriy tildagi kontakt ma’lumotlari. Tarjima bo‘lmasa, o‘zbekchasi olinadi. */
export function getContactInfo(settings: Settings, locale: Locale): ContactInfo {
  const address = settings[`address_${locale}`] || settings.address_uz;
  const hours = settings[`hours_${locale}`] || settings.hours_uz;
  let mapEmbedUrl = settings.mapEmbedUrl;
  if (!mapEmbedUrl && address) {
    mapEmbedUrl = `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`;
  }
  return {
    phone: settings.phone,
    phone2: settings.phone2,
    telegram: settings.telegram,
    email: settings.email,
    address,
    hours,
    mapEmbedUrl,
  };
}
