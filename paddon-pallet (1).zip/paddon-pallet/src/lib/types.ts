import type { AvailabilityValue, ConditionValue, MaterialValue } from "@/lib/catalog-options";

/** Mijoz tomoniga (brauzerga) yuboriladigan mahsulot ma’lumoti — joriy tilda. */
export type ProductDTO = {
  id: string;
  slug: string;
  name: string;
  description: string;
  lengthMm: number | null;
  widthMm: number | null;
  heightMm: number | null;
  isStandard: boolean;
  isCustomSize: boolean;
  material: MaterialValue;
  condition: ConditionValue;
  loadCapacityKg: number | null;
  availability: AvailabilityValue;
  price: number | null;
  isDemo: boolean;
  images: { url: string; alt: string }[];
};
