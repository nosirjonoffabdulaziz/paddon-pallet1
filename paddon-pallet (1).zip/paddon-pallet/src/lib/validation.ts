import { z } from "zod";
import { CONDITIONS, MATERIALS, SIZE_LIMITS } from "@/lib/catalog-options";

/**
 * Xatolik xabarlari kod sifatida qaytariladi ("required", "invalidPhone"...),
 * mijoz tomonida esa lug‘atdagi (errors.*) tarjimaga almashtiriladi.
 */
export type ErrorCode =
  | "required"
  | "invalidPhone"
  | "tooShort"
  | "tooLong"
  | "tooSmall"
  | "tooLarge"
  | "invalidNumber";

const text = (max: number, min = 0) =>
  z
    .string({ required_error: "required", invalid_type_error: "required" })
    .trim()
    .min(min, min > 0 ? (min === 1 ? "required" : "tooShort") : undefined)
    .max(max, "tooLong");

/** +998 90 123 45 67, 901234567, +7 ... — 7 dan 15 gacha raqam */
export const phoneSchema = z
  .string({ required_error: "required" })
  .trim()
  .min(1, "required")
  .max(25, "tooLong")
  .refine((v) => /^\+?[\d\s()-]+$/.test(v) && v.replace(/\D/g, "").length >= 7 && v.replace(/\D/g, "").length <= 15, "invalidPhone");

const intIn = (min: number, max: number) =>
  z.coerce
    .number({ invalid_type_error: "invalidNumber", required_error: "required" })
    .int("invalidNumber")
    .min(min, "tooSmall")
    .max(max, "tooLarge");

export const orderSchema = z.object({
  productSlug: z.string().trim().max(120).optional().or(z.literal("")),
  lengthMm: intIn(SIZE_LIMITS.length.min, SIZE_LIMITS.length.max),
  widthMm: intIn(SIZE_LIMITS.width.min, SIZE_LIMITS.width.max),
  heightMm: intIn(SIZE_LIMITS.height.min, SIZE_LIMITS.height.max),
  quantity: intIn(SIZE_LIMITS.quantity.min, SIZE_LIMITS.quantity.max),
  woodType: z.enum(MATERIALS, { errorMap: () => ({ message: "required" }) }),
  condition: z.enum(CONDITIONS, { errorMap: () => ({ message: "required" }) }),
  notes: text(1500),
  customerName: text(80, 2),
  phone: phoneSchema,
  locale: z.enum(["uz", "ru", "en"]).default("uz"),
  website: z.string().max(0).optional().or(z.literal("")), // honeypot (botlar uchun tuzoq)
});
export type OrderInput = z.infer<typeof orderSchema>;

export const contactSchema = z.object({
  name: text(80, 2),
  phone: phoneSchema,
  message: text(2000, 5),
  locale: z.enum(["uz", "ru", "en"]).default("uz"),
  website: z.string().max(0).optional().or(z.literal("")),
});
export type ContactInput = z.infer<typeof contactSchema>;

/** Zod xatolarini { maydon: kod } ko‘rinishiga keltiradi. */
export function fieldErrors(error: z.ZodError): Record<string, ErrorCode> {
  const out: Record<string, ErrorCode> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "form");
    if (!out[key]) out[key] = (issue.message as ErrorCode) || "required";
  }
  return out;
}
