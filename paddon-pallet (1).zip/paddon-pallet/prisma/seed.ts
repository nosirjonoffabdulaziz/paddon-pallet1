/**
 * Boshlang‘ich ma’lumotlar.
 *
 *  - Admin foydalanuvchini .env dagi ADMIN_EMAIL / ADMIN_PASSWORD asosida yaratadi.
 *  - 7 ta DEMO mahsulotni qo‘shadi (faqat shu slug'li mahsulot hali yo‘q bo‘lsa).
 *    Demo mahsulotlar saytda "Demo" belgisi bilan ko‘rinadi. Haqiqiy ma’lumotlarni
 *    admin panelda kiriting va "Demo" belgisini olib tashlang.
 *
 *  Kontakt ma’lumotlari (telefon, manzil...) ataylab qo‘shilmaydi — ularni admin
 *  panelning "Sozlamalar" bo‘limida o‘zingiz kiritasiz.
 */
import { PrismaClient, type Prisma } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

type DemoProduct = Omit<Prisma.ProductCreateInput, "images" | "orders"> & {
  image?: string;
};

const demoProducts: DemoProduct[] = [
  {
    slug: "yevropallet-1200x800",
    nameUz: "Yevropallet",
    nameRu: "Европаллет",
    nameEn: "Euro pallet",
    descriptionUz:
      "Logistika va omborlarda eng ko‘p ishlatiladigan standart o‘lchamdagi pallet. Har to‘rt tomondan yuklagich bilan olish mumkin.",
    descriptionRu:
      "Паллет стандартного размера, наиболее распространённый в логистике и на складах. Захват погрузчиком с четырёх сторон.",
    descriptionEn:
      "The most common standard-size pallet for logistics and warehousing. Four-way forklift entry.",
    lengthMm: 1200,
    widthMm: 800,
    heightMm: 144,
    isStandard: true,
    material: "PINE",
    condition: "NEW",
    loadCapacityKg: null,
    availability: "IN_STOCK",
    featured: true,
    sortOrder: 1,
    image: "/images/products/euro-pallet-1200x800.webp",
  },
  {
    slug: "sanoat-palleti-1200x1000",
    nameUz: "Sanoat palleti",
    nameRu: "Промышленный паллет",
    nameEn: "Industrial pallet",
    descriptionUz:
      "Og‘ir va katta hajmli yuklar uchun keng maydonli pallet. Ishlab chiqarish va qurilish materiallari uchun qulay.",
    descriptionRu:
      "Паллет увеличенной площади для тяжёлых и объёмных грузов. Подходит для производства и стройматериалов.",
    descriptionEn:
      "A wider pallet for heavy and bulky loads. Well suited for manufacturing and building materials.",
    lengthMm: 1200,
    widthMm: 1000,
    heightMm: 144,
    isStandard: true,
    material: "PINE",
    condition: "USED",
    availability: "IN_STOCK",
    featured: true,
    sortOrder: 2,
    image: "/images/products/industrial-pallet-1200x1000.webp",
  },
  {
    slug: "yarim-pallet-800x600",
    nameUz: "Yarim pallet",
    nameRu: "Полупаллет",
    nameEn: "Half pallet",
    descriptionUz:
      "Kichik partiyalar, chakana savdo va do‘kon ichidagi ko‘rgazmalar uchun ixcham pallet.",
    descriptionRu:
      "Компактный паллет для небольших партий, розницы и выкладки в торговом зале.",
    descriptionEn: "A compact pallet for small batches, retail and in-store displays.",
    lengthMm: 800,
    widthMm: 600,
    heightMm: 144,
    isStandard: true,
    material: "PINE",
    condition: "NEW",
    availability: "IN_STOCK",
    featured: true,
    sortOrder: 3,
    image: "/images/products/half-pallet-800x600.webp",
  },
  {
    slug: "kvadrat-pallet-1140x1140",
    nameUz: "Kvadrat pallet",
    nameRu: "Квадратный паллет",
    nameEn: "Square pallet",
    descriptionUz: "Bochka, qop va kimyoviy mahsulotlar uchun kvadrat shakldagi pallet.",
    descriptionRu: "Квадратный паллет для бочек, мешков и химической продукции.",
    descriptionEn: "A square pallet for drums, bags and chemical products.",
    lengthMm: 1140,
    widthMm: 1140,
    heightMm: 150,
    isStandard: true,
    material: "SPRUCE",
    condition: "NEW",
    availability: "ON_ORDER",
    featured: true,
    sortOrder: 4,
  },
  {
    slug: "maxsus-pallet-1000x1000",
    nameUz: "Maxsus pallet",
    nameRu: "Специальный паллет",
    nameEn: "Special pallet",
    descriptionUz: "Mijoz talabiga ko‘ra kuchaytirilgan konstruksiyadagi 1000 × 1000 mm pallet.",
    descriptionRu: "Паллет 1000 × 1000 мм с усиленной конструкцией по требованию клиента.",
    descriptionEn: "A 1000 × 1000 mm pallet with a reinforced build to customer specification.",
    lengthMm: 1000,
    widthMm: 1000,
    heightMm: 150,
    isStandard: false,
    material: "BIRCH",
    condition: "NEW",
    availability: "ON_ORDER",
    sortOrder: 5,
  },
  {
    slug: "katta-pallet-1100x1100",
    nameUz: "Katta pallet",
    nameRu: "Большой паллет",
    nameEn: "Large pallet",
    descriptionUz: "Konteyner tashuvlari uchun mos keladigan katta kvadrat pallet.",
    descriptionRu: "Большой квадратный паллет, удобный для контейнерных перевозок.",
    descriptionEn: "A large square pallet suited to container shipping.",
    lengthMm: 1100,
    widthMm: 1100,
    heightMm: 150,
    isStandard: true,
    material: "MIXED",
    condition: "USED",
    availability: "IN_STOCK",
    sortOrder: 6,
  },
  {
    slug: "buyurtma-asosidagi-pallet",
    nameUz: "Buyurtma asosidagi pallet",
    nameRu: "Паллет на заказ",
    nameEn: "Made-to-order pallet",
    descriptionUz:
      "Sizning yukingiz uchun alohida o‘lchamda tayyorlanadigan pallet. O‘lchamlarni konfiguratorda kiriting.",
    descriptionRu:
      "Паллет, изготавливаемый по индивидуальным размерам под ваш груз. Укажите размеры в конфигураторе.",
    descriptionEn:
      "A pallet built to individual dimensions for your load. Enter the sizes in the configurator.",
    lengthMm: null,
    widthMm: null,
    heightMm: null,
    isStandard: false,
    isCustomSize: true,
    material: "PINE",
    condition: "NEW",
    availability: "ON_ORDER",
    sortOrder: 7,
  },
];

async function seedAdmin() {
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password) {
    console.warn("⚠️  ADMIN_EMAIL yoki ADMIN_PASSWORD kiritilmagan — admin yaratilmadi.");
    return;
  }
  if (password.length < 8) {
    throw new Error("ADMIN_PASSWORD kamida 8 belgidan iborat bo‘lishi kerak.");
  }
  const existing = await prisma.adminUser.findUnique({ where: { email } });
  if (existing) {
    console.log(`ℹ️  Admin allaqachon mavjud: ${email}`);
    return;
  }
  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.adminUser.create({ data: { email, passwordHash } });
  console.log(`✅ Admin yaratildi: ${email}`);
}

async function seedProducts() {
  for (const { image, ...data } of demoProducts) {
    const exists = await prisma.product.findUnique({ where: { slug: data.slug } });
    if (exists) continue;
    await prisma.product.create({
      data: {
        ...data,
        isDemo: true,
        published: true,
        images: image ? { create: [{ url: image, alt: data.nameUz, sortOrder: 0 }] } : undefined,
      },
    });
    console.log(`✅ Demo mahsulot qo‘shildi: ${data.nameUz}`);
  }
}

async function main() {
  await seedAdmin();
  await seedProducts();
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
